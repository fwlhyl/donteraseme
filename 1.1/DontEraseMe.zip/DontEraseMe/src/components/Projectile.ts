import { Component } from '../core/Component';
import type { WeaponType } from './Weapon';

export class Projectile extends Component {
    constructor(
        public type: WeaponType = 'standard',
        public damage: number = 10,
        public ownerId: string = '', // ID of the entity that fired this
        public life: number = 0 // For shotgun/gravity
    ) {
        super();
    }
}
