import { Component } from '../core/Component';

export class PlayerControl extends Component {
    // Marker component for player
    constructor(
        public speed: number = 3
    ) {
        super();
    }
}
