import { Component } from '../core/Component';

export type EnemyType = 'chaser' | 'eraser' | 'shield' | 'shooter' | 'summoner' | 'boss';

export class EnemyBehavior extends Component {
    constructor(
        public type: EnemyType = 'chaser',
        public shield: number = 0,
        public maxShield: number = 0,
        public shootCooldown: number = 0,
        public summonCooldown: number = 0,
        public bossTimer: number = 0,
        public bossPhase: number = 0
    ) {
        super();
    }
}
