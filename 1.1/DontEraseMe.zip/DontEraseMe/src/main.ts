import './style.css'
import { Game } from './core/Game';

// Initialize game
const game = new Game();

// Start game loop
game.start();

console.log('Game initialized');
