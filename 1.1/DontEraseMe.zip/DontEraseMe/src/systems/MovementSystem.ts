import { System } from '../core/System';
import { Transform } from '../components/Transform';
import { Velocity } from '../components/Velocity';
import { Projectile } from '../components/Projectile';
import { Renderable } from '../components/Renderable';
import { Skeleton } from '../components/Skeleton';

import { ParticleFactory } from '../entities/ParticleFactory';
import { Entity } from '../core/Entity';

export class MovementSystem extends System {
    constructor(
        private worldWidth: number, 
        private worldHeight: number,
        private addEntityCallback?: (entity: Entity) => void,
        private trailCtx?: CanvasRenderingContext2D
    ) {
        super();
    }

    public update(dt: number): void {
        const entitiesToRemove: Entity[] = [];
        const newEntities: Entity[] = [];

        for (const entity of this.entities) {
            const transform = entity.getComponent(Transform);
            const velocity = entity.getComponent(Velocity);
            const projectile = entity.getComponent(Projectile);
            const renderable = entity.getComponent(Renderable);

            if (transform && velocity) {
                // Gravity Bullet Logic
                if (projectile && projectile.type === 'gravity') {
                    // Check if this is already a deployed black hole
                    if (entity.tags.has('blackhole')) {
                        // This is a deployed black hole, just let the life countdown handle it
                    } else {
                        // This is a flying gravity bullet
                        velocity.x *= 0.95;
                        velocity.y *= 0.95;
                         
                        if (projectile.life <= 0 || (Math.abs(velocity.x) < 0.1 && Math.abs(velocity.y) < 0.1)) {
                            // Transform into Black Hole
                            if (this.addEntityCallback) {
                                // We don't have a BlackHole factory, but we can make a Particle that acts like one?
                                // Or just a stationary projectile with 'gravity' type but render as black hole?
                                // Demo: "particles.push({type: 'blackhole'...})"
                                // Let's create a special entity for BlackHole
                                const bh = new Entity();
                                bh.addComponent(new Transform(transform.x, transform.y));
                                // Black hole stays for 3 seconds (180 frames)
                               // We use Projectile component to identify it for collision (sucking)
                               bh.addComponent(new Projectile('gravity', 0.5, projectile.ownerId, 180)); 
                                bh.addComponent(new Renderable('black', 10, 0, 0, 'circle', 100)); // Render logic will handle effect?
                                // Add dummy velocity so MovementSystem iterates it and decreases life
                                bh.addComponent(new Velocity(0, 0, 0)); 
                                // Need a way to distinguish "flying gravity bullet" and "deployed black hole"
                                // Maybe 'deployed_gravity'?
                                // Let's use 'gravity' but with 0 velocity.
                                // Add a tag?
                                bh.tags.add('blackhole'); // Use tag for rendering effect
                                 
                                newEntities.push(bh);
                            }
                            entitiesToRemove.push(entity);
                            continue;
                        }
                    }
                }
                
                if (projectile && this.trailCtx) {
                    if (projectile.type === 'eraser') {
                        this.trailCtx.save();
                        this.trailCtx.globalCompositeOperation = 'destination-out';
                        this.trailCtx.beginPath();
                        this.trailCtx.arc(transform.x, transform.y, 10, 0, Math.PI * 2);
                        this.trailCtx.fillStyle = 'rgba(0,0,0,1)';
                        this.trailCtx.fill();
                        this.trailCtx.restore();
                    } else if (projectile.type === 'ribbon' && renderable) {
                        this.trailCtx.save();
                        this.trailCtx.globalAlpha = 0.8;
                        this.trailCtx.fillStyle = renderable.color;
                        const t = (projectile.life % 60) / 60;
                        const off = Math.sin(t * Math.PI * 2) * 8;
                        this.trailCtx.beginPath();
                        this.trailCtx.arc(transform.x - velocity.y * 0.2 + off, transform.y + velocity.x * 0.2, renderable.radius + 1, 0, Math.PI * 2);
                        this.trailCtx.fill();
                        this.trailCtx.restore();
                    }
                }

                // Shotgun Trail Logic
                if (projectile && projectile.type === 'shotgun' && this.trailCtx && renderable) {
                    if (Math.random() < 0.2) {
                        this.trailCtx.beginPath();
                        this.trailCtx.arc(transform.x, transform.y, renderable.radius + Math.random()*2, 0, Math.PI * 2);
                        this.trailCtx.fillStyle = renderable.color;
                        this.trailCtx.globalAlpha = 0.1;
                        this.trailCtx.fill();
                        this.trailCtx.globalAlpha = 1.0;
                    }
                }

                transform.x += velocity.x;
                transform.y += velocity.y;

                // Boundary check for Player
                if (entity.tags.has('player')) {
                    transform.x = Math.max(0, Math.min(this.worldWidth, transform.x));
                    transform.y = Math.max(0, Math.min(this.worldHeight, transform.y));
                }

                if (renderable && (entity.tags.has('player') || entity.tags.has('enemy')) && !entity.hasComponent(Skeleton)) {
                    const speed = Math.hypot(velocity.x, velocity.y);
                    if (speed > 0.1) {
                        // Stretch in direction of movement, squash perpendicular
                        const stretch = 1 + (speed * 0.05); // Adjust multiplier for effect strength
                        const squash = 1 / stretch; // Maintain volume roughly
                        
                        // We need to smoothly interpolate this
                        renderable.scaleX = renderable.scaleX + (stretch - renderable.scaleX) * 0.2;
                        renderable.scaleY = renderable.scaleY + (squash - renderable.scaleY) * 0.2;
                        
                        // Note: For this to work perfectly, we need to rotate the canvas to align with velocity before scaling.
                        // Currently RenderSystem rotates to `transform.rotation` which for player/enemy is aim direction, not velocity direction.
                        // For a pure soft-body look, we might want to decouple movement rotation from aim rotation later.
                    } else {
                        // Return to normal shape smoothly
                        renderable.scaleX = renderable.scaleX + (1.0 - renderable.scaleX) * 0.1;
                        renderable.scaleY = renderable.scaleY + (1.0 - renderable.scaleY) * 0.1;
                    }
                }
                
                // Boundary check for Projectiles?
                // The original code removed bullets if they went off screen.
                // Here "screen" means "world".
                if (projectile) {
                     if (transform.x < 0 || transform.x > this.worldWidth || 
                         transform.y < 0 || transform.y > this.worldHeight) {
                         entitiesToRemove.push(entity);
                     }
                }
            }
            
            // Handle projectile lifetime
            if (projectile && projectile.life > 0) {
                projectile.life--;
                if (projectile.life <= 0) {
                    entitiesToRemove.push(entity);
                }
            } else if (projectile && projectile.type === 'sniper') {
                 // Sniper beam auto-cleanup
                 entitiesToRemove.push(entity);
            }
        }

        // Add new entities
        if (this.addEntityCallback) {
            for (const e of newEntities) {
                this.addEntityCallback(e);
            }
        }

        // Cleanup expired entities
        for (const entity of entitiesToRemove) {
            if (entity.tags.has('player')) continue;
            // Hack: we don't have access to game.removeEntity directly, but we can mark inactive?
            // System doesn't have removeEntity method on itself usually.
            // But we can set active = false, and Game loop cleans it up.
            entity.active = false;
        }
    }
}
