import { System } from '../core/System';
import { Weapon } from '../components/Weapon';
import { PlayerControl } from '../components/PlayerControl';
import { Health } from '../components/Health'; // Import Health
import { Skill } from '../components/Skill';
import { Score } from '../components/Score'; // Import Score
import { Renderable } from '../components/Renderable';
import { Trail } from '../components/Trail';
import { Transform } from '../components/Transform'; // Import Transform
import { Experience } from '../components/Experience';

export class UISystem extends System {
    private uiContainer: HTMLElement;
    private weaponDisplay: HTMLElement;
    private statsDisplay: HTMLElement; // Add Stats Display
    private skillDisplay: HTMLElement;
    private scoreDisplay: HTMLElement;
    private perkModal: HTMLElement | null = null;
    private perkButtons: HTMLButtonElement[] = [];
    private announceEl: HTMLElement | null = null;

    private pauseBtn: HTMLElement;
    private pauseMenu: HTMLElement;
    private resumeBtn: HTMLElement;
    private colorPalette: HTMLElement;
    private settingSize: HTMLInputElement;
    private settingAlpha: HTMLInputElement;
    private sizeVal: HTMLElement;
    private alphaVal: HTMLElement;

    private isPaused: boolean = false;
    private toolWheel: HTMLElement | null = null;

    constructor() {
        super();
        this.uiContainer = document.getElementById('ui')!;
        
        // Score Display
        this.scoreDisplay = document.createElement('div');
        this.scoreDisplay.style.fontSize = '24px';
        this.scoreDisplay.style.fontWeight = 'bold';
        this.scoreDisplay.style.color = '#ffd700'; // Gold
        this.scoreDisplay.style.marginBottom = '10px';
        this.uiContainer.appendChild(this.scoreDisplay);

        // Stats Display (Wave, HP)
        this.statsDisplay = document.createElement('div');
        this.statsDisplay.style.fontSize = '18px';
        this.statsDisplay.style.marginBottom = '10px';
        this.uiContainer.appendChild(this.statsDisplay);

        // Create Weapon Display
        this.weaponDisplay = document.createElement('div');
        this.weaponDisplay.style.fontSize = '20px';
        this.weaponDisplay.style.fontWeight = 'bold';
        this.weaponDisplay.style.marginTop = '10px';
        this.weaponDisplay.style.color = 'white';
        this.uiContainer.appendChild(this.weaponDisplay);

        // Skill Display
        this.skillDisplay = document.createElement('div');
        this.skillDisplay.style.fontSize = '20px';
        this.skillDisplay.style.fontWeight = 'bold';
        this.skillDisplay.style.marginTop = '10px';
        this.skillDisplay.style.color = 'white';
        this.uiContainer.appendChild(this.skillDisplay);

        // Pause Menu Elements
        this.pauseBtn = document.getElementById('pause-btn')!;
        this.pauseMenu = document.getElementById('pause-menu')!;
        this.resumeBtn = document.getElementById('resume-btn')!;
        this.colorPalette = document.getElementById('color-palette')!;
        this.settingSize = document.getElementById('setting-size') as HTMLInputElement;
        this.settingAlpha = document.getElementById('setting-alpha') as HTMLInputElement;
        this.sizeVal = document.getElementById('size-val')!;
        this.alphaVal = document.getElementById('alpha-val')!;

        this.setupPauseMenu();
        this.setupPerkModal();
        this.setupAnnounce();
        this.setupToolWheel();
    }

    private setupPauseMenu() {
        // Toggle Pause
        this.pauseBtn.addEventListener('click', () => {
            this.togglePause();
        });

        this.resumeBtn.addEventListener('click', () => {
            this.togglePause();
        });

        // Colors
        const colors = ['#ffffff', '#ff0000', '#00ff00', '#0000ff', '#ffff00', '#ff00ff', '#00ffff', '#ffa500', '#000000'];
        colors.forEach(color => {
            const swatch = document.createElement('div');
            swatch.style.width = '30px';
            swatch.style.height = '30px';
            swatch.style.borderRadius = '50%';
            swatch.style.backgroundColor = color;
            swatch.style.cursor = 'pointer';
            swatch.style.border = '2px solid rgba(255,255,255,0.2)';
            
            swatch.addEventListener('click', () => {
                this.updatePlayerSettings('color', color);
                // Highlight selection
                Array.from(this.colorPalette.children).forEach((c: any) => c.style.borderColor = 'rgba(255,255,255,0.2)');
                swatch.style.borderColor = 'white';
            });
            this.colorPalette.appendChild(swatch);
        });

        // Size
        this.settingSize.addEventListener('input', (e: any) => {
            const val = parseInt(e.target.value);
            this.sizeVal.innerText = val.toString();
            this.updatePlayerSettings('size', val);
        });

        // Alpha
        this.settingAlpha.addEventListener('input', (e: any) => {
            const val = parseInt(e.target.value);
            this.alphaVal.innerText = val + '%';
            this.updatePlayerSettings('alpha', val / 100);
        });
    }

    private setupAnnounce() {
        const el = document.createElement('div');
        el.style.position = 'fixed';
        el.style.left = '50%';
        el.style.top = '80px';
        el.style.transform = 'translateX(-50%)';
        el.style.padding = '10px 20px';
        el.style.background = 'rgba(0,0,0,0.6)';
        el.style.color = '#ffd700';
        el.style.fontSize = '28px';
        el.style.fontWeight = 'bold';
        el.style.borderRadius = '6px';
        el.style.display = 'none';
        el.style.zIndex = '9999';
        document.body.appendChild(el);
        this.announceEl = el;
        window.addEventListener('announce', (e: any) => {
            const text = e.detail?.text || '';
            if (!this.announceEl) return;
            this.announceEl.textContent = text;
            this.announceEl.style.display = 'block';
            this.announceEl.style.opacity = '1';
            setTimeout(() => {
                if (!this.announceEl) return;
                this.announceEl.style.transition = 'opacity 0.6s';
                this.announceEl.style.opacity = '0';
                setTimeout(() => {
                    if (this.announceEl) {
                        this.announceEl.style.display = 'none';
                        this.announceEl.style.transition = '';
                    }
                }, 700);
            }, 1600);
        });
    }

    private setupToolWheel() {
        const overlay = document.createElement('div');
        overlay.style.position = 'fixed';
        overlay.style.left = '0';
        overlay.style.top = '0';
        overlay.style.width = '100%';
        overlay.style.height = '100%';
        overlay.style.display = 'none';
        overlay.style.alignItems = 'center';
        overlay.style.justifyContent = 'center';
        overlay.style.background = 'rgba(0,0,0,0.5)';
        overlay.style.zIndex = '9999';
        const wheel = document.createElement('div');
        wheel.style.position = 'relative';
        wheel.style.width = '320px';
        wheel.style.height = '320px';
        wheel.style.borderRadius = '50%';
        wheel.style.border = '2px solid rgba(255,255,255,0.2)';
        wheel.style.boxShadow = '0 0 24px rgba(0,0,0,0.6) inset';
        const items: { id: 'curve'|'symmetry'|'eraser'|'pin'; label: string; angle: number }[] = [
            { id: 'curve', label: '锚点曲线', angle: -90 },
            { id: 'symmetry', label: '对称镜像', angle: 0 },
            { id: 'eraser', label: '橡皮盾', angle: 90 },
            { id: 'pin', label: '定点钉住', angle: 180 },
        ];
        const getUnlock = (id: 'curve'|'symmetry'|'eraser'|'pin'|'explosion') => {
            if (id === 'curve') return 10;
            if (id === 'pin') return 15;
            if (id === 'symmetry') return 20;
            if (id === 'eraser') return 25;
            return 30;
        };
        const getLevel = () => {
            for (const e of this.entities) {
                if (!e.tags.has('player')) continue;
                const exp = e.getComponent(Experience);
                return exp ? exp.level : 0;
            }
            return 0;
        };
        items.forEach(it => {
            const btn = document.createElement('button');
            btn.textContent = it.label;
            btn.style.position = 'absolute';
            btn.style.width = '110px';
            btn.style.height = '110px';
            btn.style.borderRadius = '50%';
            btn.style.border = '2px solid rgba(255,255,255,0.2)';
            btn.style.background = '#222';
            btn.style.color = '#fff';
            btn.style.cursor = 'pointer';
            const r = 110;
            const rad = (it.angle * Math.PI) / 180;
            const cx = 160 + Math.cos(rad) * r - 55;
            const cy = 160 + Math.sin(rad) * r - 55;
            btn.style.left = `${cx}px`;
            btn.style.top = `${cy}px`;
            btn.addEventListener('mouseenter', () => {
                btn.style.borderColor = '#fff';
                btn.style.background = '#333';
            });
            btn.addEventListener('mouseleave', () => {
                btn.style.borderColor = 'rgba(255,255,255,0.2)';
                btn.style.background = '#222';
            });
            btn.addEventListener('click', () => {
                const lvl = getLevel();
                const need = getUnlock(it.id);
                if (lvl < need) {
                    window.dispatchEvent(new CustomEvent('announce', { detail: { text: `未解锁：${it.label} Lv${need}` } }));
                    return;
                }
                window.dispatchEvent(new CustomEvent('tool-select', { detail: { id: it.id as any } }));
                overlay.style.display = 'none';
                window.dispatchEvent(new CustomEvent('game-pause', { detail: { paused: false } }));
            });
            wheel.appendChild(btn);
        });
        // Center button for Explosion
        const center = document.createElement('button');
        center.textContent = '爆炸';
        center.style.position = 'absolute';
        center.style.left = '50%';
        center.style.top = '50%';
        center.style.transform = 'translate(-50%, -50%)';
        center.style.width = '100px';
        center.style.height = '100px';
        center.style.borderRadius = '50%';
        center.style.border = '2px solid rgba(255,255,255,0.6)';
        center.style.background = '#551a1a';
        center.style.color = '#fff';
        center.style.cursor = 'pointer';
        center.addEventListener('mouseenter', () => {
            center.style.borderColor = '#fff';
            center.style.background = '#7a2424';
        });
        center.addEventListener('mouseleave', () => {
            center.style.borderColor = 'rgba(255,255,255,0.6)';
            center.style.background = '#551a1a';
        });
        center.addEventListener('click', () => {
            const lvl = getLevel();
            const need = getUnlock('explosion');
            if (lvl < need) {
                window.dispatchEvent(new CustomEvent('announce', { detail: { text: `未解锁：爆炸 Lv${need}` } }));
                return;
            }
            window.dispatchEvent(new CustomEvent('tool-select', { detail: { id: 'explosion' } }));
            overlay.style.display = 'none';
            window.dispatchEvent(new CustomEvent('game-pause', { detail: { paused: false } }));
        });
        wheel.appendChild(center);
        overlay.appendChild(wheel);
        document.body.appendChild(overlay);
        this.toolWheel = overlay;
        window.addEventListener('keydown', (e: KeyboardEvent) => {
            if (e.key === 'Tab') {
                e.preventDefault();
                if (!this.toolWheel) return;
                const showing = this.toolWheel.style.display === 'flex';
                if (!showing) {
                    // Update lock visuals based on current level
                    const lvl = getLevel();
                    const wheelBtns = this.toolWheel.querySelectorAll('button');
                    wheelBtns.forEach((b: any) => {
                        const text = b.textContent || '';
                        let id: 'curve'|'symmetry'|'eraser'|'pin'|'explosion' | null = null;
                        if (text.includes('锚点曲线')) id = 'curve';
                        else if (text.includes('对称镜像')) id = 'symmetry';
                        else if (text.includes('橡皮盾')) id = 'eraser';
                        else if (text.includes('定点钉住')) id = 'pin';
                        else if (text.includes('爆炸')) id = 'explosion';
                        if (id) {
                            const need = getUnlock(id);
                            const locked = lvl < need;
                            const map: any = { curve: '锚点曲线', symmetry: '对称镜像', eraser: '橡皮盾', pin: '定点钉住', explosion: '爆炸' };
                            const base = map[id];
                            if (locked) {
                                b.textContent = `${base}（未解锁Lv${need}）`;
                                b.style.borderColor = 'rgba(255,255,255,0.15)';
                                b.style.background = '#111';
                                b.style.color = '#888';
                                b.style.cursor = 'not-allowed';
                            } else {
                                b.textContent = base;
                                b.style.borderColor = 'rgba(255,255,255,0.2)';
                                b.style.background = '#222';
                                b.style.color = '#fff';
                                b.style.cursor = 'pointer';
                            }
                        }
                    });
                    this.toolWheel.style.display = 'flex';
                    window.dispatchEvent(new CustomEvent('game-pause', { detail: { paused: true } }));
                } else {
                    this.toolWheel.style.display = 'none';
                    window.dispatchEvent(new CustomEvent('game-pause', { detail: { paused: false } }));
                }
            }
        });
    }

    private setupPerkModal() {
        const modal = document.createElement('div');
        modal.style.position = 'fixed';
        modal.style.left = '0';
        modal.style.top = '0';
        modal.style.width = '100%';
        modal.style.height = '100%';
        modal.style.backgroundColor = 'rgba(0,0,0,0.6)';
        modal.style.display = 'none';
        modal.style.alignItems = 'center';
        modal.style.justifyContent = 'center';
        modal.style.zIndex = '9999';
        const panel = document.createElement('div');
        panel.style.background = '#111';
        panel.style.padding = '20px';
        panel.style.borderRadius = '8px';
        panel.style.display = 'flex';
        panel.style.gap = '12px';
        for (let i = 0; i < 3; i++) {
            const btn = document.createElement('button');
            btn.style.padding = '12px 16px';
            btn.style.fontSize = '16px';
            btn.style.cursor = 'pointer';
            panel.appendChild(btn);
            this.perkButtons.push(btn);
        }
        modal.appendChild(panel);
        document.body.appendChild(modal);
        this.perkModal = modal;
        window.addEventListener('choose-perk', (e: any) => {
            const picks: string[] = e.detail?.picks || [];
            if (!this.perkModal) return;
            for (let i = 0; i < this.perkButtons.length; i++) {
                const btn = this.perkButtons[i];
                const label = picks[i] || '';
                btn.textContent = label;
                btn.onclick = () => {
                    this.applyPerk(label);
                    this.perkModal!.style.display = 'none';
                    window.dispatchEvent(new CustomEvent('game-pause', { detail: { paused: false } }));
                };
            }
            this.perkModal.style.display = 'flex';
        });
    }

    private applyPerk(label: string) {
        for (const e of this.entities) {
            if (!e.tags.has('player')) continue;
            const pc = e.getComponent(PlayerControl);
            const weapon = e.getComponent(Weapon);
            const hp = e.getComponent(Health);
            const skill = e.getComponent(Skill);
            if (label.includes('移速') && pc) {
                pc.speed *= 1.1;
                if (weapon) {
                    weapon.speedMul *= 1.05;
                }
            } else if (label.includes('射速') && weapon) {
                weapon.fireRateMul = Math.max(0.5, weapon.fireRateMul * 0.9);
            } else if (label.includes('散布') && weapon) {
                weapon.spreadMul = Math.max(0.5, weapon.spreadMul * 0.8);
            } else if (label.includes('生命') && hp) {
                hp.max += 30;
                hp.current += 30;
            } else if (label.includes('冷却') && skill) {
                skill.maxCooldown = Math.floor(skill.maxCooldown * 0.85);
            }
        }
    }

    private togglePause() {
        this.isPaused = !this.isPaused;
        if (this.isPaused) {
            this.pauseMenu.style.display = 'flex';
            window.dispatchEvent(new CustomEvent('game-pause', { detail: { paused: true } }));
        } else {
            this.pauseMenu.style.display = 'none';
            window.dispatchEvent(new CustomEvent('game-pause', { detail: { paused: false } }));
        }
    }

    private updatePlayerSettings(key: string, value: any) {
        for (const entity of this.entities) {
            if (entity.tags.has('player')) {
                if (key === 'color') {
                    const renderable = entity.getComponent(Renderable);
                    if (renderable) renderable.color = value;
                    const trail = entity.getComponent(Trail);
                    if (trail) trail.color = value;
                } else if (key === 'size') {
                    const renderable = entity.getComponent(Renderable);
                    if (renderable) renderable.radius = value;
                    const trail = entity.getComponent(Trail);
                    if (trail) trail.width = value * 1.5; // Trail slightly larger
                } else if (key === 'alpha') {
                    const trail = entity.getComponent(Trail);
                    if (trail) trail.alpha = value;
                }
            }
        }
    }

    public update(dt: number): void {
        for (const entity of this.entities) {
            if (entity.tags.has('player')) {
                const weapon = entity.getComponent(Weapon);
                const health = entity.getComponent(Health); // Get Player Health
                const skill = entity.getComponent(Skill);
                const score = entity.getComponent(Score);
                
                if (score) {
                    this.scoreDisplay.textContent = `SCORE: ${score.value}`;
                }

                // Update Stats (Wave is tricky to get here without reference to WaveSystem)
                // Let's just show HP for now. 
                // To get Wave, we might need a global GameState component or similar.
                const exp = entity.getComponent(Experience);
                if (health) {
                    const lvlTxt = exp ? ` LVL: ${exp.level} (${exp.xp}/${exp.next})` : '';
                    this.statsDisplay.textContent = `HP: ${Math.ceil(health.current)} / ${health.max}${lvlTxt}`;
                }

                if (weapon) {
                    const config = weapon.config;
                    const ammo = weapon.ammo[weapon.currentWeaponIndex] ?? 0;
                    const reloadTxt = weapon.reloading ? ' (reloading...)' : '';
                    this.weaponDisplay.textContent = `WEAPON: ${config.name}  ${ammo}/${config.magSize}${reloadTxt}`;
                    this.weaponDisplay.style.color = config.color;
                }

                if (skill) {
                    const toolNameMap: any = { curve: '画圆', symmetry: '对称镜像', eraser: '橡皮盾', pin: '定点钉住', explosion: '爆炸' };
                    const toolName = toolNameMap[skill.activeTool] || '直线尺';
                    const toolTxt = skill.toolCooldown > 0 ? `${toolName}: ${(skill.toolCooldown/60).toFixed(1)}s (F)` : `${toolName}: READY (F)`;
                    this.skillDisplay.textContent = toolTxt;
                    this.skillDisplay.style.color = skill.toolCooldown > 0 ? 'gray' : 'lime';
                }
            }
        }
    }
}
