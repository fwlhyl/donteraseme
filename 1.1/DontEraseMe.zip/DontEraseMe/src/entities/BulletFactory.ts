import { Entity } from '../core/Entity';
import { Transform } from '../components/Transform';
import { Velocity } from '../components/Velocity';
import { Renderable } from '../components/Renderable';
import { Projectile } from '../components/Projectile';
import type { WeaponConfig } from '../components/Weapon';

export class BulletFactory {
    public static create(
        config: WeaponConfig, 
        ownerX: number, 
        ownerY: number, 
        angle: number,
        bulletColor: string, // Renamed from ownerColor to be clear it's the final color
        ownerId: string,
        speedMul: number = 1.0
    ): Entity {
        const bullet = new Entity();
        
        bullet.addComponent(new Transform(ownerX, ownerY, angle));
        
        const effSpeed = config.speed * speedMul;
        const velocity = new Velocity(
            Math.cos(angle) * effSpeed,
            Math.sin(angle) * effSpeed
        );
        bullet.addComponent(velocity);
        
        // Use the passed color
        let color = bulletColor;
        
        bullet.addComponent(new Renderable(color, config.radius, 0, 0, 'circle', 5));
        
        let life = 0;
        if (config.type === 'gravity') {
            life = 120;
        } else if (config.type === 'sniper') {
            life = 0; // sniper handled as beam elsewhere
        } else {
            life = Math.ceil((config.range || 600) / effSpeed);
        }
        
        bullet.addComponent(new Projectile(config.type, config.damage, ownerId, life));
        
        bullet.tags.add('projectile');
        
        return bullet;
    }
}
