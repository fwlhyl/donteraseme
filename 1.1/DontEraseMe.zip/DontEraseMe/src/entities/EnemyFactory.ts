import { Entity } from '../core/Entity';
import { Transform } from '../components/Transform';
import { Velocity } from '../components/Velocity';
import { Renderable } from '../components/Renderable';
import { Health } from '../components/Health';
import { EnemyBehavior } from '../components/EnemyBehavior';
import type { EnemyType } from '../components/EnemyBehavior';

export class EnemyFactory {
    public static create(type: EnemyType, x: number, y: number): Entity {
        const enemy = new Entity();
        
        enemy.addComponent(new Transform(x, y));
        
        if (type === 'chaser') {
            const radius = 10 + Math.random() * 15; // 10-25
            const color = `hsl(${Math.random() * 360}, 70%, 50%)`; // Random color
            const hp = Math.floor(radius); // HP proportional to size
            
            enemy.addComponent(new Velocity(0, 0, 3)); // Speed 3
            enemy.addComponent(new Renderable(color, radius, 0, 0, 'circle', 5));
            enemy.addComponent(new Health(hp, hp));
        } else if (type === 'eraser') {
            const radius = 25 + Math.random() * 5; // 25-30
            enemy.addComponent(new Velocity(0, 0, 2)); // Slower
            enemy.addComponent(new Renderable('#ffffff', radius, radius * 2, radius * 2, 'rect', 5)); // White square
            enemy.addComponent(new Health(50, 50));
        } else if (type === 'shield') {
            const radius = 22;
            enemy.addComponent(new Velocity(0, 0, 2.2));
            enemy.addComponent(new Renderable('#66ccff', radius, 0, 0, 'circle', 5));
            enemy.addComponent(new Health(90, 90));
            enemy.addComponent(new EnemyBehavior('shield', 80, 80, 0, 0, 0, 0));
        } else if (type === 'shooter') {
            const radius = 18;
            enemy.addComponent(new Velocity(0, 0, 2.4));
            enemy.addComponent(new Renderable('#ff66aa', radius, 0, 0, 'circle', 5));
            enemy.addComponent(new Health(60, 60));
            enemy.addComponent(new EnemyBehavior('shooter', 0, 0, 0, 0, 0, 0));
        } else if (type === 'summoner') {
            const radius = 20;
            enemy.addComponent(new Velocity(0, 0, 1.8));
            enemy.addComponent(new Renderable('#bb88ff', radius, 0, 0, 'circle', 5));
            enemy.addComponent(new Health(80, 80));
            enemy.addComponent(new EnemyBehavior('summoner', 0, 0, 0, 0, 0, 0));
        } else if (type === 'boss') {
            const radius = 40;
            enemy.addComponent(new Velocity(0, 0, 1.6));
            enemy.addComponent(new Renderable('#ffcc00', radius, 0, 0, 'triangle', 5));
            enemy.addComponent(new Health(600, 600));
            enemy.addComponent(new EnemyBehavior('boss', 120, 120, 0, 0, 0, 0));
        }
        
        if (!enemy.getComponent(EnemyBehavior)) {
            enemy.addComponent(new EnemyBehavior(type));
        }
        enemy.tags.add('enemy');
        
        return enemy;
    }
}
