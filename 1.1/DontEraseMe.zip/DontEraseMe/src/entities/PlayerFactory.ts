import { Entity } from '../core/Entity';
import { Transform } from '../components/Transform';
import { Velocity } from '../components/Velocity';
import { Renderable } from '../components/Renderable';
import { PlayerControl } from '../components/PlayerControl';
import { Trail } from '../components/Trail';
import { Weapon } from '../components/Weapon';
import { Skill } from '../components/Skill';

import { Health } from '../components/Health'; // Import Health
import { Score } from '../components/Score';
import { Skeleton, Bone } from '../components/Skeleton';
import { SpriteAttachments } from '../components/SpriteAttachments';
import { Experience } from '../components/Experience';

export class PlayerFactory {
    public static create(x: number, y: number): Entity {
        const player = new Entity();
        
        // Debug: Log creation pos
        console.log('Creating player at', x, y);
        
        player.addComponent(new Transform(x, y));
        player.addComponent(new Velocity());
        
        const renderable = new Renderable('white', 20, 40, 40, 'circle', 10);
        
        // Load custom skin if exists
        const savedSkin = localStorage.getItem('player_custom_skin');
        if (savedSkin) {
            renderable.shape = 'sprite';
            const img = new Image();
            img.src = savedSkin;
            renderable.attachmentBone = 'spine';
            renderable.offsetX = 0;
            renderable.offsetY = 0;
            renderable.attachmentRotationOffset = 0;
            img.onerror = () => {
                renderable.shape = 'circle';
                renderable.image = undefined;
            };
            img.onload = () => {
                if (img.naturalWidth === 0) {
                    renderable.shape = 'circle';
                    renderable.image = undefined;
                }
            };
            renderable.image = img;
        }
        
        player.addComponent(renderable);
        
        const attachments = new SpriteAttachments();
        const partKeys = [
            { key: 'player_part_head', bone: 'spine', w: 28, h: 28, ox: 0, oy: -26, ro: 0, z: 2 },
            { key: 'player_part_body', bone: 'spine', w: 46, h: 46, ox: 0, oy: 0, ro: 0, z: 1 },
            { key: 'player_part_arm_r', bone: 'arm_r', w: 18, h: 18, ox: 10, oy: 0, ro: 0, z: 3 },
            { key: 'player_part_forearm_r', bone: 'forearm_r', w: 16, h: 16, ox: 10, oy: 0, ro: 0, z: 4 }
        ];
        let hasParts = false;
        for (const p of partKeys) {
            const url = localStorage.getItem(p.key);
            if (url) {
                const i = new Image();
                i.src = url;
                attachments.addPart({
                    image: i,
                    bone: p.bone,
                    width: p.w,
                    height: p.h,
                    offsetX: p.ox,
                    offsetY: p.oy,
                    rotationOffset: p.ro,
                    z: p.z
                });
                hasParts = true;
            }
        }
        if (hasParts) {
            player.addComponent(attachments);
        }
        
        player.addComponent(new PlayerControl(5)); // Increased player speed from 3 to 6
        player.addComponent(new Trail('rgba(255, 255, 255, 0.5)', 30, 0.2)); // Visible trail
        player.addComponent(new Weapon(0)); // Start with Pistol
        player.addComponent(new Skill()); // Add Skill component
        player.addComponent(new Health(100, 100)); // Add 100 HP to player
        player.addComponent(new Score(0)); // Initialize score
        player.addComponent(new Experience(1, 0, 100)); // Level 1
        
        const bones = [
            new Bone('root', 0, 0, 0, 20),
            new Bone('spine', 0, 0, 0, 24, 'root'),
            new Bone('arm_r', 24, 0, 0, 22, 'spine'),
            new Bone('forearm_r', 22, 0, 0, 18, 'arm_r')
        ];
        player.addComponent(new Skeleton(bones, 'root'));
        
        player.tags.add('player');
        
        return player;
    }
}
