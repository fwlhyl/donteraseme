import { System } from '../core/System';
import { Entity } from '../core/Entity';
import { Transform } from '../components/Transform';
import { Weapon } from '../components/Weapon';
import { InputManager } from '../core/InputManager';
import { PlayerControl } from '../components/PlayerControl';
import { Renderable } from '../components/Renderable';
import { BulletFactory } from '../entities/BulletFactory';
import { WEAPONS } from '../components/Weapon';
import { Projectile } from '../components/Projectile';
import { Skill } from '../components/Skill';
import { EnemyBehavior } from '../components/EnemyBehavior';
import { Health } from '../components/Health';

export class WeaponSystem extends System {
    constructor(
        private input: InputManager,
        private addEntityCallback: (entity: Entity) => void,
        private trailCtx?: CanvasRenderingContext2D
    ) {
        super();
    }

    public update(dt: number): void {
        for (const entity of this.entities) {
            const weapon = entity.getComponent(Weapon);
            const transform = entity.getComponent(Transform);
            const renderable = entity.getComponent(Renderable);
            
            if (weapon && transform && renderable) {
                // Handle cooldown
                if (weapon.cooldown > 0) {
                    weapon.cooldown -= 1; // Assuming 60fps frame based cooldown
                }

                // Only player controls weapon for now
                if (entity.tags.has('player')) {
                    this.handlePlayerInput(entity, weapon, transform, renderable);
                }
            }
        }
    }

    private handlePlayerInput(player: Entity, weapon: Weapon, transform: Transform, renderable: Renderable): void {
        // Weapon switching
        if (this.input.isKeyDown('1')) this.switchWeapon(weapon, 0);
        if (this.input.isKeyDown('2')) this.switchWeapon(weapon, 1);
        if (this.input.isKeyDown('3')) this.switchWeapon(weapon, 2);
        if (this.input.isKeyDown('4')) this.switchWeapon(weapon, 3);
        if (this.input.isKeyDown('5')) this.switchWeapon(weapon, 4);
        if (this.input.isKeyDown('6')) this.switchWeapon(weapon, 5);
        if (this.input.isKeyDown('7')) this.switchWeapon(weapon, 6);
        if (this.input.isKeyDown('8')) this.switchWeapon(weapon, 7);
        if (this.input.isKeyDown('9')) this.switchWeapon(weapon, 8);
        if (this.input.isKeyDown('0')) {
            // Find the last weapon in the array, assuming 0 equips the newest fused weapon
            const lastWeaponId = Math.max(...Array.from(weapon.unlocked));
            if (lastWeaponId >= 9) {
                this.switchWeapon(weapon, lastWeaponId);
            }
        }
        
        // Reload
        if (this.input.isKeyDown('r') || this.input.isKeyDown('R')) {
            this.startReload(weapon);
        }

        // Update attacking state based on mouse input
        player.attacking = this.input.mouse.down;

        // Handle reloading timer
        if (weapon.reloading) {
            if (weapon.reloadTimer > 0) {
                weapon.reloadTimer -= 1;
            } else {
                const cfg = weapon.config;
                weapon.ammo[weapon.currentWeaponIndex] = cfg.magSize;
                weapon.reloading = false;
            }
        }
        
        // Special continuous tool: Roller
        if (this.input.mouse.down && weapon.config.type === 'roller' && this.trailCtx) {
            weapon.cooldown = 2;
            this.trailCtx.save();
            this.trailCtx.fillStyle = renderable.color;
            this.trailCtx.globalAlpha = 0.8;
            this.trailCtx.beginPath();
            this.trailCtx.arc(transform.x, transform.y, 28, 0, Math.PI * 2);
            this.trailCtx.fill();
            this.trailCtx.restore();
        }
        // Shooting
        if (this.input.mouse.down && weapon.cooldown <= 0 && !weapon.reloading) {
            const idx = weapon.currentWeaponIndex;
            const cfg = weapon.config;
            if (cfg.type === 'melee') {
                this.shoot(player, weapon, transform, renderable.color);
                // Melee不消耗子弹
            } else {
                if (weapon.ammo[idx] > 0) {
                    this.shoot(player, weapon, transform, renderable.color);
                    weapon.ammo[idx] -= 1;
                    if (weapon.ammo[idx] <= 0) {
                        this.startReload(weapon);
                    }
                } else {
                    this.startReload(weapon);
                }
            }
        }
    }

    private switchWeapon(weapon: Weapon, index: number): void {
        if (!weapon.unlocked.has(index)) return;
        if (weapon.currentWeaponIndex !== index) {
            weapon.currentWeaponIndex = index;
            weapon.cooldown = 20; // Reset cooldown on switch
            console.log(`Switched to weapon: ${WEAPONS[index].name}`);
        }
    }

    private shoot(owner: Entity, weapon: Weapon, transform: Transform, ownerColor: string): void {
        const config = weapon.config;
        weapon.cooldown = Math.max(1, Math.round(config.fireRate * weapon.fireRateMul));
        
        // Set attack state for player
        if (owner.tags.has('player')) {
            // We now update attack state based on mouse down in handlePlayerInput
            // rather than a timeout here.
        }
        
        // Determine bullet color
        let bulletColor = config.color;
        // All weapons except Pistol (0) should use player color
        if (config.id !== 0) {
            bulletColor = ownerColor;
        }

        // Ruler gun draws a direct line
        if (config.type === 'ruler' && this.trailCtx) {
            const len = 600;
            const endX = transform.x + Math.cos(transform.rotation) * len;
            const endY = transform.y + Math.sin(transform.rotation) * len;
            this.trailCtx.save();
            this.trailCtx.strokeStyle = ownerColor;
            this.trailCtx.lineWidth = 8;
            this.trailCtx.beginPath();
            this.trailCtx.moveTo(transform.x, transform.y);
            this.trailCtx.lineTo(endX, endY);
            this.trailCtx.stroke();
            this.trailCtx.restore();
            // Damage enemies along the line
            const ax = transform.x, ay = transform.y;
            const bx = endX, by = endY;
            const thickness = 12;
            for (const e of this.entities) {
                if (!e.active || e === owner) continue;
                const eb = e.getComponent(EnemyBehavior);
                const tt = e.getComponent(Transform);
                const hp = e.getComponent(Health);
                if (!eb || !tt || !hp) continue;
                const dx = bx - ax, dy = by - ay;
                const t = Math.max(0, Math.min(1, ((tt.x - ax) * dx + (tt.y - ay) * dy) / (dx*dx + dy*dy + 1e-6)));
                const px = ax + dx * t, py = ay + dy * t;
                const d = Math.hypot(tt.x - px, tt.y - py);
                if (d <= thickness) {
                    hp.current -= 18;
                    if (hp.current <= 0) e.active = false;
                }
            }
            return;
        }

        // Ruler skill: one-shot straight line
        const sk = owner.getComponent(Skill);
        if (sk && sk.rulerArmed && this.trailCtx) {
            const len = 600;
            const endX = transform.x + Math.cos(transform.rotation) * len;
            const endY = transform.y + Math.sin(transform.rotation) * len;
            this.trailCtx.save();
            this.trailCtx.strokeStyle = ownerColor;
            this.trailCtx.lineWidth = 6;
            this.trailCtx.beginPath();
            this.trailCtx.moveTo(transform.x, transform.y);
            this.trailCtx.lineTo(endX, endY);
            this.trailCtx.stroke();
            this.trailCtx.restore();
            sk.rulerArmed = false;
            return;
        }

        // Sniper special logic (Raycast)
        if (config.type === 'sniper') {
            // Create a visual beam entity
            const beam = new Entity();
            
            // Calculate beam end point (very far away)
            const range = config.range || 1200;
            const angle = transform.rotation; // Use rotation directly
            const endX = transform.x + Math.cos(angle) * range;
            const endY = transform.y + Math.sin(angle) * range;
            
            // We use Transform for start point, and Renderable width/height for end point (as per RenderSystem logic)
            beam.addComponent(new Transform(transform.x, transform.y));
            // Store end coordinates in width/height for line drawing
            beam.addComponent(new Renderable(bulletColor, 0, endX, endY, 'line', 5)); // Use bulletColor
            
            beam.addComponent(new Projectile('sniper', config.damage, owner.id, 5));
            const beamProj = beam.getComponent(Projectile);
            if (beamProj) {
                const idx = weapon.currentWeaponIndex;
                const bonus = weapon.damageBonus[idx] || 0;
                let dmg = beamProj.damage + bonus;
                if (Math.random() < weapon.critChance) {
                    dmg = Math.floor(dmg * weapon.critMultiplier);
                }
                beamProj.damage = dmg;
            }
            
            this.addEntityCallback(beam);
            
            // Draw Trail Line
            // Delay drawing the sniper trail line slightly so it happens AFTER the eraser 
            // has processed its death and stopped erasing.
            if (this.trailCtx) {
                // By deferring this to the end of the current event loop or next frame,
                // we ensure all CollisionSystem deaths are processed first.
                // Using setTimeout(..., 0) pushes this to the macro-task queue, 
                // which runs after the current frame's systems finish updating.
                setTimeout(() => {
                    if (this.trailCtx) {
                        this.trailCtx.save();
                        this.trailCtx.globalCompositeOperation = 'source-over';
                        this.trailCtx.beginPath();
                        this.trailCtx.moveTo(transform.x, transform.y);
                        this.trailCtx.lineTo(endX, endY);
                        this.trailCtx.strokeStyle = bulletColor;
                        this.trailCtx.lineWidth = 2;
                        this.trailCtx.stroke();
                        this.trailCtx.restore();
                    }
                }, 0);
            }
            
            return;
        }

        // Melee：前方扇形近战打击
        if (config.type === 'melee') {
            const reach = config.range || 80;
            const halfArc = Math.PI * 0.35; // 约40度扇形
            const base = transform.rotation;
            const idx = weapon.currentWeaponIndex;
            const bonus = weapon.damageBonus[idx] || 0;
            let dmg = config.damage + bonus;
            if (Math.random() < weapon.critChance) {
                dmg = Math.floor(dmg * weapon.critMultiplier);
            }
            // 视觉：在轨迹层画出短暂的弧线
            if (this.trailCtx) {
                this.trailCtx.save();
                this.trailCtx.strokeStyle = ownerColor;
                this.trailCtx.globalAlpha = 0.6;
                this.trailCtx.lineWidth = 6;
                this.trailCtx.beginPath();
                this.trailCtx.arc(transform.x, transform.y, reach, base - halfArc, base + halfArc);
                this.trailCtx.stroke();
                this.trailCtx.restore();
            }
            // 命中判定
            for (const e of this.entities) {
                if (!e.active || e === owner) continue;
                const eb = e.getComponent(EnemyBehavior);
                const tt = e.getComponent(Transform);
                const hp = e.getComponent(Health);
                if (!eb || !tt || !hp) continue;
                const dx = tt.x - transform.x;
                const dy = tt.y - transform.y;
                const dist = Math.hypot(dx, dy);
                if (dist > reach) continue;
                const ang = Math.atan2(dy, dx);
                let diff = ang - base;
                while (diff > Math.PI) diff -= Math.PI * 2;
                while (diff < -Math.PI) diff += Math.PI * 2;
                if (Math.abs(diff) <= halfArc) {
                    hp.current -= dmg;
                    // 轻微击退
                    const kb = 8;
                    tt.x += Math.cos(ang) * kb;
                    tt.y += Math.sin(ang) * kb;
                    if (hp.current <= 0) {
                        e.active = false;
                    }
                }
            }
            return;
        }

        for (let i = 0; i < config.count; i++) {
            const spread = (Math.random() - 0.5) * config.spread * weapon.spreadMul;
            const angle = transform.rotation + spread;
            
            // Create bullet entity
            const bullet = BulletFactory.create(
                config,
                transform.x,
                transform.y,
                angle,
                bulletColor, // Use bulletColor
                owner.id,
                weapon.speedMul
            );
            const proj = bullet.getComponent(Projectile);
            if (proj) {
                const idx = weapon.currentWeaponIndex;
                const bonus = weapon.damageBonus[idx] || 0;
                let dmg = proj.damage + bonus;
                if (Math.random() < weapon.critChance) {
                    dmg = Math.floor(dmg * weapon.critMultiplier);
                }
                proj.damage = dmg;
                proj.pierceCount = weapon.pierceCount;
                if (config.type === 'rocket') {
                    proj.explosionRadiusScale = weapon.explosionRadiusScale;
                }
                if (config.type === 'chain') {
                    proj.pierceCount = 3;
                }
            }
            
            this.addEntityCallback(bullet);
        }
    }
    
    private startReload(weapon: Weapon) {
        if (weapon.reloading) return;
        const cfg = weapon.config;
        weapon.reloading = true;
        const rt = Math.max(1, Math.floor(cfg.reloadTime * weapon.reloadTimeMul));
        weapon.reloadTimer = rt;
        weapon.cooldown = rt;
    }
}
