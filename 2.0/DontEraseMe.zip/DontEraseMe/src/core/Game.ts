import { Entity } from './Entity';
import { System } from './System';
import { InputManager } from './InputManager';
import { InputSystem } from '../systems/InputSystem';
import { MovementSystem } from '../systems/MovementSystem';
import { RenderSystem } from '../systems/RenderSystem';
import { TrailSystem } from '../systems/TrailSystem';
import { WeaponSystem } from '../systems/WeaponSystem';
import { UISystem } from '../systems/UISystem';
import { EnemySystem } from '../systems/EnemySystem';
import { CollisionSystem } from '../systems/CollisionSystem';
import { ParticleSystem } from '../systems/ParticleSystem';
import { WaveSystem } from '../systems/WaveSystem';
import { MinimapSystem } from '../systems/MinimapSystem';
import { SkillSystem } from '../systems/SkillSystem';
import { QuestSystem } from '../systems/QuestSystem';
import { PlayerFactory } from '../entities/PlayerFactory';
import { EnemyFactory } from '../entities/EnemyFactory';
import { SkeletonSystem } from '../systems/SkeletonSystem';
import { ObjectiveSystem } from '../systems/ObjectiveSystem';
import { LevelSystem } from '../systems/LevelSystem';
import { Experience } from '../components/Experience';
import { Weapon } from '../components/Weapon';
import { Transform } from '../components/Transform';
import { Health } from '../components/Health';
import { Velocity } from '../components/Velocity';
import { Score } from '../components/Score';
import { Quest } from '../components/Quest';
import { StoryState } from '../components/StoryState';
import { Renderable } from '../components/Renderable';

export enum GameState {
    MENU,
    PLAYING,
    GAMEOVER,
    STUDIO
}

type PlayMode = 'story' | 'endless';

export class Game {
    public entities: Map<string, Entity> = new Map();
    public systems: System[] = [];
    public lastTime: number = 0;
    public isRunning: boolean = false;
    public state: GameState = GameState.MENU; // Default state
    
    public gameCanvas: HTMLCanvasElement;
    public gameCtx: CanvasRenderingContext2D;
    public trailCanvas: HTMLCanvasElement;
    public trailCtx: CanvasRenderingContext2D;
    public minimapCanvas: HTMLCanvasElement;
    public minimapCtx: CanvasRenderingContext2D;
    
    // UI Elements
    private mainMenu: HTMLElement;
    private gameOverMenu: HTMLElement;
    private gameUI: HTMLElement;
    private scoreDisplay: HTMLElement;

    public width: number = window.innerWidth;
    public height: number = window.innerHeight;
    public worldWidth: number = 2000;  //max 4000
    public worldHeight: number = 2000;
    public camera: { x: number, y: number, shakeX: number, shakeY: number, shakeTimer: number } = { x: 0, y: 0, shakeX: 0, shakeY: 0, shakeTimer: 0 };

    // Systems references
    private waveSystem!: WaveSystem;

    public inputManager: InputManager;
    public currentMode: PlayMode = 'endless';
    private studioTimeLeft: number = 0;
    private lastRatingTick: number = 0;
    private lastBuffTime: number = 0;
    private lastEliteTime: number = 0;
    private ratingCanvas: HTMLCanvasElement;
    private ratingCtx: CanvasRenderingContext2D;
    private ratingInterval: number = 1;

    constructor() {
        // Setup canvases
        this.gameCanvas = document.getElementById('gameCanvas') as HTMLCanvasElement;
        this.trailCanvas = document.getElementById('trailCanvas') as HTMLCanvasElement;
        this.minimapCanvas = document.getElementById('minimapCanvas') as HTMLCanvasElement;
        
        // Setup UI
        this.mainMenu = document.getElementById('main-menu')!;
        this.gameOverMenu = document.getElementById('game-over')!;
        this.gameUI = document.getElementById('ui')!;
        this.scoreDisplay = document.getElementById('final-score')!;

        if (!this.gameCanvas || !this.trailCanvas || !this.minimapCanvas) {
            throw new Error('Canvas elements not found');
        }

        this.gameCtx = this.gameCanvas.getContext('2d')!;
        this.trailCtx = this.trailCanvas.getContext('2d')!;
        this.minimapCtx = this.minimapCanvas.getContext('2d')!;
        this.ratingCanvas = document.createElement('canvas');
        this.ratingCanvas.width = 64;
        this.ratingCanvas.height = 64;
        this.ratingCtx = this.ratingCanvas.getContext('2d')!;

        // Debug: Log canvas sizes and z-indexes
        console.log('GameCanvas:', this.gameCanvas.width, this.gameCanvas.height, this.gameCanvas.style.zIndex);
        console.log('TrailCanvas:', this.trailCanvas.width, this.trailCanvas.height, this.trailCanvas.style.zIndex);
        
        // Ensure gameCanvas is on top
        this.gameCanvas.style.zIndex = '10';
        this.trailCanvas.style.zIndex = '1';

        this.inputManager = new InputManager();

        this.resize();
        window.addEventListener('resize', () => this.resize());

        this.setupSystems();
        // Entities are setup on Start Game now
        // this.setupEntities();

        // Bind Buttons
        const storyBtn = document.getElementById('story-btn');
        if (storyBtn) storyBtn.addEventListener('click', () => this.startGame('story'));
        
        const endlessBtn = document.getElementById('endless-btn');
        if (endlessBtn) endlessBtn.addEventListener('click', () => this.startGame('endless'));
        
        const editorBtn = document.getElementById('editor-btn');
        if (editorBtn) editorBtn.addEventListener('click', () => {
            window.location.href = '/editor.html';
        });

        const restartBtn = document.getElementById('restart-btn');
        if (restartBtn) restartBtn.addEventListener('click', () => this.startGame(this.currentMode));

        // Save Button
        const saveBtn = document.getElementById('save-btn');
        if (saveBtn) saveBtn.addEventListener('click', () => this.saveImage());

        // Pause Listener
        window.addEventListener('game-pause', (e: any) => {
            if (e.detail.paused) {
                this.isRunning = false; // Pause loop
            } else {
                this.isRunning = true;
                this.lastTime = performance.now();
                this.loop(this.lastTime);
            }
        });
        window.addEventListener('game-over', (e: any) => this.gameOver(e.detail?.score));
        
        const backBtn = document.createElement('button');
        backBtn.textContent = 'Back to Main Menu';
        backBtn.id = 'back-main-btn';
        if (this.gameOverMenu) {
            this.gameOverMenu.appendChild(backBtn);
            const restartBtnEl = document.getElementById('restart-btn') as HTMLElement | null;
            if (restartBtnEl) {
                backBtn.className = restartBtnEl.className;
                backBtn.style.cssText = restartBtnEl.getAttribute('style') || backBtn.style.cssText;
            }
            backBtn.addEventListener('click', () => {
                this.stop();
                this.state = GameState.MENU;
                if (this.mainMenu) this.mainMenu.style.display = 'flex';
                if (this.gameOverMenu) this.gameOverMenu.style.display = 'none';
                if (this.gameUI) this.gameUI.style.display = 'none';
                if (this.minimapCanvas) this.minimapCanvas.style.display = 'none';
            });
        }
        
        const exitBtn = document.createElement('button');
        exitBtn.textContent = 'Exit Game';
        exitBtn.id = 'exit-btn';
        if (this.mainMenu) {
            this.mainMenu.appendChild(exitBtn);
            const storyBtnEl = document.getElementById('story-btn') as HTMLElement | null;
            if (storyBtnEl) {
                exitBtn.className = storyBtnEl.className;
                exitBtn.style.cssText = storyBtnEl.getAttribute('style') || exitBtn.style.cssText;
            }
            exitBtn.addEventListener('click', () => {
                try {
                    window.close();
                } catch {}
                setTimeout(() => {
                    window.location.href = 'about:blank';
                }, 0);
            });
        }
        
        
        
        // Frames grid disabled per new design
        
        // ESC modal bridge events
        window.addEventListener('save-art-local', () => this.saveImage());
        window.addEventListener('save-art-to-frame', (e: any) => {
            const idx = e.detail?.index;
            if (typeof idx !== 'number') return;
            this.saveImageToFrame(idx);
        });
        window.addEventListener('exit-run', () => {
            this.stop();
            this.state = GameState.MENU;
            if (this.mainMenu) this.mainMenu.style.display = 'flex';
            if (this.gameUI) this.gameUI.style.display = 'none';
            if (this.minimapCanvas) this.minimapCanvas.style.display = 'none';
        });
    }

    private setupSystems(): void {
        this.addSystem(new InputSystem(this.inputManager, this.camera));
        this.addSystem(new MovementSystem(this.worldWidth, this.worldHeight, (e) => this.addEntity(e), this.trailCtx));
        this.addSystem(new WeaponSystem(this.inputManager, (entity) => this.addEntity(entity), this.trailCtx));
        this.addSystem(new EnemySystem((entity) => this.addEntity(entity), this.trailCtx));
        this.addSystem(new CollisionSystem((entity) => this.addEntity(entity), this.trailCtx));
        
        this.waveSystem = new WaveSystem((entity) => this.addEntity(entity), this.camera);
        this.addSystem(this.waveSystem);
        
        this.addSystem(new SkillSystem(this.inputManager, this.trailCtx, this.camera, (entity) => this.addEntity(entity)));
        this.addSystem(new ParticleSystem());
        this.addSystem(new TrailSystem(this.trailCtx, this.camera));
        this.addSystem(new SkeletonSystem());
        this.addSystem(new ObjectiveSystem(this.worldWidth, this.worldHeight, (e) => this.addEntity(e)));
        this.addSystem(new LevelSystem(() => this.currentMode));
        this.addSystem(new RenderSystem(this.gameCtx, this.camera, this.worldWidth, this.worldHeight));
        this.addSystem(new MinimapSystem(this.minimapCtx, this.worldWidth, this.worldHeight, this.camera));
        this.addSystem(new UISystem());
        this.addSystem(new QuestSystem());
    }

    private setupEntities(): void {
        const player = PlayerFactory.create(this.width / 2, this.height / 2);
        this.configurePlayerForMode(player);
        this.addEntity(player);

        // Test Enemies
        this.addEntity(EnemyFactory.create('chaser', 100, 100));
        this.addEntity(EnemyFactory.create('eraser', this.width - 100, 100));
    }

    public resize(): void {
        this.width = window.innerWidth;
        this.height = window.innerHeight;
        
        const dpr = window.devicePixelRatio || 1;
        
        this.gameCanvas.width = this.width * dpr;
        this.gameCanvas.height = this.height * dpr;
        this.gameCanvas.style.width = `${this.width}px`;
        this.gameCanvas.style.height = `${this.height}px`;
        this.gameCtx.scale(dpr, dpr); // Restore scale

        this.trailCanvas.width = this.worldWidth;
        this.trailCanvas.height = this.worldHeight;
        this.trailCanvas.style.width = `${this.worldWidth}px`;
        this.trailCanvas.style.height = `${this.worldHeight}px`;
        // No scale needed for trailCtx if it's 1:1 with world, but for high DPI screens we might want scaling.
        // Let's keep it simple: World pixels = Screen pixels at scale 1.
        // If we want high DPI, we'd need a larger canvas and scale ctx.
        // For performance on large canvas, let's stick to 1x for now or use dpr if performant.
        this.trailCtx.scale(1, 1); 

        // Minimap
        this.minimapCanvas.width = 150 * dpr;
        this.minimapCanvas.height = 150 * dpr;
        this.minimapCtx.scale(dpr, dpr);
    }

    public addEntity(entity: Entity): void {
        this.entities.set(entity.id, entity);
        for (const system of this.systems) {
            system.addEntity(entity);
        }
    }

    public removeEntity(entityId: string): void {
        const entity = this.entities.get(entityId);
        if (entity) {
            for (const system of this.systems) {
                system.removeEntity(entity);
            }
            this.entities.delete(entityId);
        }
    }

    public addSystem(system: System): void {
        this.systems.push(system);
    }

    private configurePlayerForMode(player: Entity): void {
        const exp = player.getComponent(Experience);
        const weapon = player.getComponent(Weapon);
        const quest = player.getComponent(Quest);
        const story = player.getComponent(StoryState);

        if (weapon) {
            weapon.currentWeaponIndex = 0;
            weapon.cooldown = 0;
            weapon.reloading = false;
            weapon.reloadTimer = 0;
            weapon.unlocked = new Set([0]);
        }

        if (quest) {
            quest.index = 0;
            for (const step of quest.steps) {
                step.done = false;
            }
        }

        if (this.currentMode === 'story') {
            if (exp) {
                exp.level = 1;
                exp.xp = 0;
                exp.next = Number.MAX_SAFE_INTEGER;
            }
            if (quest) {
                quest.active = true;
                quest.steps = [
                    { type: 'announce', text: '【第一幕：未竟的草图】' },
                    { type: 'announce', text: '保护地图中心的“画眼”！抵御擦除教团的进攻！' },
                    { type: 'defend', duration: 120, text: '防守成功！画眼已被激活！' }, // 撑过120秒
                    { type: 'announce', text: '本测试关卡已通关，你可以继续体验融合技能。' }
                ];
                quest.index = 0;
            }
            if (story) {
                story.chapter = 'Prologue';
                story.flags = {};
            }
            
            // Create the "Canvas Eye" (The sketch to defend)
            const canvasEye = new Entity();
            canvasEye.tags.add('canvas_eye');
            canvasEye.addComponent(new Transform(this.worldWidth / 2, this.worldHeight / 2, 0));
            // Add a renderable to make it visible
            const eyeRenderable = new Renderable('rgba(255, 255, 255, 0.8)', 40, 80, 80, 'circle');
            eyeRenderable.zIndex = 5;
            canvasEye.addComponent(eyeRenderable);
            // Add health to the eye
            canvasEye.addComponent(new Health(1000));
            
            this.addEntity(canvasEye);
            
        } else {
            if (exp) {
                exp.level = 1;
                exp.xp = 0;
                exp.next = 100;
            }
            if (quest) {
                quest.active = false;
            }
            if (story) {
                story.chapter = 'Endless';
                story.flags = {};
            }
        }
    }

    public startGame(mode: PlayMode = 'endless'): void {
        this.currentMode = mode;
        const savedSkin = localStorage.getItem('player_custom_skin');
        if (!savedSkin) {
            const goEditor = window.confirm('检测到你还没有绘制角色皮肤。是否现在去绘制？选择“取消”将使用默认外观进入游戏。');
            if (goEditor) {
                window.location.href = '/editor.html';
                return;
            }
        }
        this.reset();
        this.setupEntities();
        this.state = GameState.PLAYING;
        
        if (this.mainMenu) this.mainMenu.style.display = 'none';
        if (this.gameOverMenu) this.gameOverMenu.style.display = 'none';
        if (this.gameUI) this.gameUI.style.display = 'block';
        if (this.minimapCanvas) this.minimapCanvas.style.display = 'block';
        
        // Show Pause Button
        const pauseBtn = document.getElementById('pause-btn');
        if (pauseBtn) pauseBtn.style.display = 'block';

        window.dispatchEvent(new CustomEvent('announce', {
            detail: {
                text: mode === 'story' ? '已进入故事模式' : '已进入无尽模式'
            }
        }));

        if (!this.isRunning) {
            this.start();
        }
    }
    
    public gameOver(score: number = 0): void {
        this.state = GameState.GAMEOVER;
        if (this.scoreDisplay) this.scoreDisplay.innerText = `Final Score: ${score}`;
        
        if (this.gameUI) this.gameUI.style.display = 'none';
        if (this.minimapCanvas) this.minimapCanvas.style.display = 'none';
        
        // Hide Pause Button
        const pauseBtn = document.getElementById('pause-btn');
        if (pauseBtn) pauseBtn.style.display = 'none';
        
        if (this.gameOverMenu) this.gameOverMenu.style.display = 'flex';
    }

    public saveImage(): void {
        const level = (() => {
            for (const [, e] of this.entities) {
                if (!e.tags.has('player')) continue;
                const ex = e.getComponent(Experience);
                return ex ? ex.level : 0;
            }
            return 0;
        })();
        try {
            const dataUrl = this.trailCanvas.toDataURL('image/png');
            const b64 = dataUrl.replace(/^data:image\/png;base64,/, '');
            const bytes = base64ToBytes(b64);
            const out = injectTextChunks(bytes, [
                ['Software', 'DontEraseMe'],
                ['Version', '1'],
                ['CreationTime', new Date().toISOString()],
                ['Level', String(level)],
                ['WorldSize', `${this.worldWidth}x${this.worldHeight}`]
            ]);
            const ab = out.buffer.slice(out.byteOffset, out.byteOffset + out.byteLength) as ArrayBuffer;
            const blob = new Blob([ab], { type: 'image/png' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `art-${Date.now()}.png`;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
        } catch (err) {
            try {
                const fallback = this.trailCanvas.toDataURL('image/png');
                const a = document.createElement('a');
                a.href = fallback;
                a.download = `art-${Date.now()}.png`;
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
            } catch {}
        }
        
        function base64ToBytes(b64: string): Uint8Array {
            const bin = atob(b64);
            const arr = new Uint8Array(bin.length);
            for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
            return arr;
        }
        function injectTextChunks(png: Uint8Array, pairs: [string, string][]): Uint8Array {
            const sig = png.slice(0, 8);
            let pos = 8;
            const ihdrLen = readUint32(png, pos);
            const ihdrType = readType(png, pos + 4);
            const ihdrEnd = pos + 8 + ihdrLen + 4;
            const head = png.slice(0, ihdrEnd);
            const rest = png.slice(ihdrEnd);
            const chunks: Uint8Array[] = [head];
            for (const [key, val] of pairs) {
                chunks.push(makeTextChunk(key, val));
            }
            chunks.push(rest);
            return concat(chunks);
        }
        function makeTextChunk(keyword: string, text: string): Uint8Array {
            const enc = (s: string) => new TextEncoder().encode(s);
            const keyBytes = enc(keyword);
            const textBytes = enc(text);
            const data = new Uint8Array(keyBytes.length + 1 + textBytes.length);
            data.set(keyBytes, 0);
            data[keyBytes.length] = 0;
            data.set(textBytes, keyBytes.length + 1);
            const type = enc('tEXt');
            const crcInput = new Uint8Array(type.length + data.length);
            crcInput.set(type, 0);
            crcInput.set(data, type.length);
            const crc = crc32(crcInput);
            const chunk = new Uint8Array(4 + 4 + data.length + 4);
            writeUint32(chunk, 0, data.length);
            chunk.set(type, 4);
            chunk.set(data, 8);
            writeUint32(chunk, 8 + data.length, crc);
            return chunk;
        }
        function readUint32(b: Uint8Array, i: number): number {
            return (b[i] << 24) | (b[i + 1] << 16) | (b[i + 2] << 8) | (b[i + 3]);
        }
        function writeUint32(b: Uint8Array, i: number, v: number) {
            b[i] = (v >>> 24) & 0xff;
            b[i + 1] = (v >>> 16) & 0xff;
            b[i + 2] = (v >>> 8) & 0xff;
            b[i + 3] = v & 0xff;
        }
        function readType(b: Uint8Array, i: number): string {
            return String.fromCharCode(b[i], b[i + 1], b[i + 2], b[i + 3]);
        }
        function concat(parts: Uint8Array[]): Uint8Array {
            let total = 0;
            for (const p of parts) total += p.length;
            const out = new Uint8Array(total);
            let offset = 0;
            for (const p of parts) {
                out.set(p, offset);
                offset += p.length;
            }
            return out;
        }
        function crc32(bytes: Uint8Array): number {
            let crc = 0xffffffff;
            for (let i = 0; i < bytes.length; i++) {
                crc = (crc >>> 8) ^ table[(crc ^ bytes[i]) & 0xff];
            }
            return (crc ^ 0xffffffff) >>> 0;
        }
        const table = (function makeTable() {
            const t = new Uint32Array(256);
            for (let i = 0; i < 256; i++) {
                let c = i;
                for (let k = 0; k < 8; k++) {
                    c = c & 1 ? 0xedb88320 ^ (c >>> 1) : (c >>> 1);
                }
                t[i] = c >>> 0;
            }
            return t;
        })();
    }
    
    private saveImageToFrame(index: number): void {
        const frames = this.getFrames();
        if (!frames[index]) return;
        if (!frames[index].unlocked) {
            window.dispatchEvent(new CustomEvent('announce', { detail: { text: `未解锁画框 #${index + 1}` } }));
            return;
        }
        try {
            const dataUrl = this.trailCanvas.toDataURL('image/png');
            frames[index].hasArt = true;
            frames[index].dataUrl = dataUrl;
            this.setFrames(frames);
            window.dispatchEvent(new CustomEvent('announce', { detail: { text: `已保存到画框 #${index + 1}` } }));
            this.renderFrameGrid();
        } catch (e) {
            window.dispatchEvent(new CustomEvent('announce', { detail: { text: `保存失败` } }));
        }
    }

    private reset(): void {
        // Clear all entities
        this.entities.clear();
        for (const system of this.systems) {
            system.entities.clear();
        }
        
        // Reset Wave System
        if (this.waveSystem) {
            this.waveSystem.reset();
        }

        // Clear canvases
        this.trailCtx.clearRect(0, 0, this.worldWidth, this.worldHeight);
        this.minimapCtx.clearRect(0, 0, this.minimapCanvas.width, this.minimapCanvas.height);
        
        // Reset Camera
        this.camera.x = 0;
        this.camera.y = 0;
    }

    public start(): void {
        if (this.isRunning) return;
        this.isRunning = true;
        this.lastTime = performance.now();
        requestAnimationFrame((time) => this.loop(time));
    }

    public stop(): void {
        this.isRunning = false;
        // Legacy stop, now handled by gameOver()
    }

    private loop(time: number): void {
        if (!this.isRunning) return;

        let dt = (time - this.lastTime) / 1000;
        this.lastTime = time;
        
        // Cap dt to prevent huge jumps (e.g. tab switch)
        if (dt > 0.1) dt = 0.1;

        // 1. Clear canvas first
        // Effect: Trail / Afterimage
        // Instead of clearRect, we fill with semi-transparent background
        // Wait, if we want persistent trails on the GAME canvas (e.g. bullet trails), we use this.
        // But the user said "player movement trail and attack effect... not leaving traces on canvas".
        // The TrailSystem draws to trailCtx (trailCanvas).
        // The RenderSystem draws to gameCtx (gameCanvas).
        
        // If trailCanvas is not showing up, maybe it's the CSS transform?
        // Or maybe it's being cleared somewhere?
        // We only clear trailCtx in reset().
        
        // Let's check the loop.
        // 1. Clear canvas first
        this.gameCtx.clearRect(0, 0, this.gameCanvas.width, this.gameCanvas.height);
        
        if (this.state === GameState.PLAYING) {
            this.update(dt);
        } else if (this.state === GameState.STUDIO) {
            this.updateStudio(dt);
        }
        
        // 3. Update Trail Canvas Position (Camera + Shake)
        const shakeX = this.camera.shakeX || 0;
        const shakeY = this.camera.shakeY || 0;
        // Use translate3d for performance
        this.trailCanvas.style.transform = `translate3d(${-this.camera.x + shakeX}px, ${-this.camera.y + shakeY}px, 0)`;

        // 4. Request next frame
        requestAnimationFrame((t) => this.loop(t));
    }

    private update(dt: number): void {
        try {
            for (const system of this.systems) {
                // console.log('Running system:', system.constructor.name);
                system.update(dt);
            }
        } catch (e) {
            console.error('System update failed:', e);
        }
        
        // Global cleanup of inactive entities
        // Iterate through all entities and remove those marked as inactive
        for (const [id, entity] of this.entities) {
            if (!entity.active) {
                this.removeEntity(id);
            }
        }
        
        this.lastRatingTick += dt;
        const activeEnemies = (() => {
            let c = 0;
            for (const [, e] of this.entities) if (e.tags.has('enemy')) c++;
            return c;
        })();
        this.ratingInterval = (activeEnemies > 40 || dt > 0.02) ? 3 : 1;
        if (this.lastRatingTick >= this.ratingInterval) {
            this.lastRatingTick = 0;
            this.evaluateRating();
        }
    }

    private render(): void {
        // Clear game canvas
        this.gameCtx.clearRect(0, 0, this.width, this.height);
        
        // Update Trail Canvas Position (Camera + Shake)
        const shakeX = this.camera.shakeX || 0;
        const shakeY = this.camera.shakeY || 0;
        this.trailCanvas.style.transform = `translate(${-this.camera.x + shakeX}px, ${-this.camera.y + shakeY}px)`;
        
        // Render logic will be handled by RenderSystem
    }
    
    private evaluateRating(): void {
        const x = Math.max(0, Math.min(this.worldWidth - this.width, this.camera.x));
        const y = Math.max(0, Math.min(this.worldHeight - this.height, this.camera.y));
        const w = Math.min(this.width, this.worldWidth - x);
        const h = Math.min(this.height, this.worldHeight - y);
        this.ratingCtx.clearRect(0, 0, 64, 64);
        this.ratingCtx.drawImage(this.trailCanvas, x, y, w, h, 0, 0, 64, 64);
        let density = 0;
        let contrast = 0;
        let edges = 0;
        const img = this.ratingCtx.getImageData(0, 0, 64, 64);
        const data = img.data;
        let prev = 0;
        for (let i = 0; i < data.length; i += 4) {
            const r = data[i], g = data[i + 1], b = data[i + 2], a = data[i + 3];
            if (a > 10) density++;
            const lum = (r * 0.2126 + g * 0.7152 + b * 0.0722);
            contrast += Math.abs(lum - 128);
            const diff = Math.abs(lum - prev);
            if (diff > 25) edges++;
            prev = lum;
        }
        const totalPixels = (data.length / 4) || 1;
        const dScore = Math.min(100, (density / totalPixels) * 120);
        const cScore = Math.min(100, (contrast / totalPixels) * 0.8);
        const eScore = Math.min(100, (edges / totalPixels) * 1.2);
        const rating = Math.floor((dScore * 0.4) + (cScore * 0.3) + (eScore * 0.3));
        for (const [, e] of this.entities) {
            if (!e.tags.has('player')) continue;
            const sc = e.getComponent(Score);
            if (sc) sc.rating = rating;
        }
        if (rating >= 70 && (performance.now() - this.lastBuffTime > 10000)) {
            this.lastBuffTime = performance.now();
            for (const [, e] of this.entities) {
                if (!e.tags.has('player')) continue;
                const wpn = e.getComponent(Weapon);
                if (wpn) {
                    wpn.critChance = Math.min(0.8, wpn.critChance + 0.15);
                    setTimeout(() => {
                        wpn.critChance = Math.max(0, wpn.critChance - 0.15);
                    }, 8000);
                }
            }
            window.dispatchEvent(new CustomEvent('announce', { detail: { text: `评分加成：暴击提升` } }));
        }
        if (rating >= 85 && (performance.now() - this.lastEliteTime > 15000)) {
            this.lastEliteTime = performance.now();
            let px = 0, py = 0;
            for (const [, e] of this.entities) {
                if (!e.tags.has('player')) continue;
                const t = e.getComponent(Transform);
                if (t) { px = t.x; py = t.y; }
            }
            const elite = EnemyFactory.create('shield', px + 120, py);
            const hp = elite.getComponent(Health);
            const vel = elite.getComponent(Velocity);
            if (hp) { hp.max = Math.floor(hp.max * 1.5); hp.current = hp.max; }
            if (vel) { vel.speed *= 1.3; }
            this.addEntity(elite);
            window.dispatchEvent(new CustomEvent('announce', { detail: { text: `精英出现` } }));
        }
    }
    
    private buyStudioTime(sec: number): void {
        let coins = 0;
        for (const [, e] of this.entities) {
            if (!e.tags.has('player')) continue;
            const sc = e.getComponent(Score);
            if (sc) coins = sc.coins;
        }
        if (coins < sec) {
            window.dispatchEvent(new CustomEvent('announce', { detail: { text: `金币不足` } }));
            return;
        }
        for (const [, e] of this.entities) {
            if (!e.tags.has('player')) continue;
            const sc = e.getComponent(Score);
            if (sc) sc.coins -= sec;
        }
        this.studioTimeLeft += sec;
        this.enterStudio();
    }
    
    private enterStudio(): void {
        this.state = GameState.STUDIO;
        for (const [, e] of this.entities) {
            if (e.tags.has('enemy')) e.active = false;
        }
        if (this.gameOverMenu) this.gameOverMenu.style.display = 'none';
        if (this.gameUI) this.gameUI.style.display = 'block';
        if (!this.isRunning) {
            this.start();
        }
    }
    
    private updateStudio(dt: number): void {
        const allow = new Set(['InputSystem','MovementSystem','SkillSystem','TrailSystem','RenderSystem','UISystem','MinimapSystem']);
        try {
            for (const system of this.systems) {
                const name = (system as any).constructor.name;
                if (allow.has(name)) system.update(dt);
            }
        } catch (e) {
            console.error('System update failed:', e);
        }
        this.studioTimeLeft -= dt;
        if (this.studioTimeLeft <= 0) {
            this.studioTimeLeft = 0;
            for (const [, e] of this.entities) {
                if (!e.tags.has('player')) continue;
                const sc = e.getComponent(Score);
                if (sc) sc.coins = 0;
            }
            window.dispatchEvent(new CustomEvent('announce', { detail: { text: `创作时间结束` } }));
            window.dispatchEvent(new CustomEvent('open-esc'));
        }
        
        const shakeX = this.camera.shakeX || 0;
        const shakeY = this.camera.shakeY || 0;
        this.trailCanvas.style.transform = `translate3d(${-this.camera.x + shakeX}px, ${-this.camera.y + shakeY}px, 0)`;
    }
    
    private initFrames(): void {
        const existing = localStorage.getItem('art_frames');
        if (existing) return;
        const frames = [];
        for (let i = 0; i < 10; i++) {
            frames.push({
                unlocked: i < 3,
                hasArt: false,
                dataUrl: ''
            });
        }
        localStorage.setItem('art_frames', JSON.stringify(frames));
    }
    
    private getFrames(): { unlocked: boolean, hasArt: boolean, dataUrl: string }[] {
        try {
            const raw = localStorage.getItem('art_frames') || '[]';
            const arr = JSON.parse(raw);
            if (Array.isArray(arr)) return arr;
        } catch {}
        return [];
    }
    
    private setFrames(frames: { unlocked: boolean, hasArt: boolean, dataUrl: string }[]): void {
        localStorage.setItem('art_frames', JSON.stringify(frames));
    }
    
    private renderFrameGrid(): void {
        if (!this.mainMenu) return;
        let grid = this.mainMenu.querySelector('.frame-grid') as HTMLElement | null;
        if (!grid) {
            grid = document.createElement('div');
            grid.className = 'frame-grid';
            grid.style.display = 'grid';
            grid.style.gridTemplateColumns = 'repeat(5, 160px)';
            grid.style.gap = '12px';
            grid.style.marginTop = '12px';
            this.mainMenu.appendChild(grid);
        }
        const frames = this.getFrames();
        grid.innerHTML = '';
        for (let i = 0; i < 10; i++) {
            const slot = frames[i] || { unlocked: false, hasArt: false, dataUrl: '' };
            const cell = document.createElement('div');
            cell.style.width = '160px';
            cell.style.height = '140px';
            cell.style.border = '2px solid rgba(255,255,255,0.2)';
            cell.style.borderRadius = '6px';
            cell.style.background = '#111';
            cell.style.display = 'flex';
            cell.style.flexDirection = 'column';
            cell.style.alignItems = 'center';
            cell.style.justifyContent = 'center';
            const title = document.createElement('div');
            title.textContent = `画框 #${i + 1}`;
            title.style.color = '#fff';
            title.style.marginBottom = '6px';
            const status = document.createElement('div');
            status.style.color = slot.unlocked ? '#0f0' : '#f55';
            status.textContent = slot.unlocked ? '已解锁' : '未解锁';
            const saveStatus = document.createElement('div');
            saveStatus.style.color = slot.hasArt ? '#ffd700' : '#ccc';
            saveStatus.textContent = slot.hasArt ? '已存储作品' : '未存储作品';
            if (slot.hasArt && slot.dataUrl) {
                const img = document.createElement('img');
                img.src = slot.dataUrl;
                img.style.width = '120px';
                img.style.height = '60px';
                img.style.objectFit = 'cover';
                img.style.marginTop = '6px';
                cell.appendChild(img);
            }
            cell.appendChild(title);
            cell.appendChild(status);
            cell.appendChild(saveStatus);
            if (slot.unlocked) {
                cell.style.cursor = 'pointer';
                cell.addEventListener('click', () => {
                    window.dispatchEvent(new CustomEvent('announce', { detail: { text: slot.hasArt ? `预览：画框 #${i + 1}` : `空画框 #${i + 1}` } }));
                });
            }
            grid.appendChild(cell);
        }
    }
}
