import { System } from '../core/System';
import { Entity } from '../core/Entity';
import { Transform } from '../components/Transform';
import { Velocity } from '../components/Velocity';
import { EnemyBehavior } from '../components/EnemyBehavior';

import { Renderable } from '../components/Renderable';
import { Health } from '../components/Health';
import { BulletFactory } from '../entities/BulletFactory';
import { Projectile } from '../components/Projectile';
import { Stunned } from '../components/Stunned';

export class EnemySystem extends System {
    private player: Entity | null = null;

    constructor(
        private addEntityCallback: (entity: Entity) => void,
        private trailCtx?: CanvasRenderingContext2D
    ) {
        super();
    }

    // We need to find the player to chase
    public update(dt: number): void {
        // Debug: Log entity count occasionally
        // if (Math.random() < 0.01) console.log('EnemySystem entities:', this.entities.size);

        // Find player if not cached (or re-find if lost)
        if (!this.player || !this.player.active) {
            this.player = null;
            // Search for player in current entities
            for (const entity of this.entities) {
                if (entity.tags.has('player')) {
                    this.player = entity;
                    // console.log('EnemySystem found player!');
                    break;
                }
            }
        }

        if (!this.player) {
            // console.warn('EnemySystem: No player found!');
            return;
        }

        const pTransform = this.player.getComponent(Transform);
        if (!pTransform) return;

        for (const entity of this.entities) {
            const enemy = entity.getComponent(EnemyBehavior);
            const transform = entity.getComponent(Transform);
            const velocity = entity.getComponent(Velocity);

            if (enemy && transform && velocity) {
                const st = entity.getComponent(Stunned);
                if (st && st.frames > 0) {
                    st.frames -= 1;
                    velocity.x = 0;
                    velocity.y = 0;
                    continue;
                }
                if (enemy.type === 'chaser') {
                    // Simple chase logic
                    const dx = pTransform.x - transform.x;
                    const dy = pTransform.y - transform.y;
                    const dist = Math.sqrt(dx*dx + dy*dy);
                    
                    if (dist > 0) {
                        velocity.x = (dx / dist) * velocity.speed;
                        velocity.y = (dy / dist) * velocity.speed;
                        transform.rotation = Math.atan2(dy, dx);
                    }
                } else if (enemy.type === 'eraser') {
                    // Eraser logic: Move randomly or towards nearest trail?
                    // For MVP: Chase player slowly
                    const dx = pTransform.x - transform.x;
                    const dy = pTransform.y - transform.y;
                    const dist = Math.sqrt(dx*dx + dy*dy);
                    
                    if (dist > 0) {
                        velocity.x = (dx / dist) * velocity.speed;
                        velocity.y = (dy / dist) * velocity.speed;
                    }

                    // Erase trail
                    if (this.trailCtx) {
                        // Only erase if it's active and alive
                        if (entity.active) {
                            const renderable = entity.getComponent(Renderable);
                            const radius = renderable ? renderable.radius : 30;
                            
                            this.trailCtx.save();
                            this.trailCtx.globalCompositeOperation = 'destination-out';
                            this.trailCtx.beginPath();
                            this.trailCtx.arc(transform.x, transform.y, radius + 5, 0, Math.PI * 2);
                            this.trailCtx.fillStyle = 'rgba(0,0,0,1)';
                            this.trailCtx.fill();
                            this.trailCtx.restore();
                        }
                    }
                } else if (enemy.type === 'shield') {
                    const dx = pTransform.x - transform.x;
                    const dy = pTransform.y - transform.y;
                    const dist = Math.sqrt(dx*dx + dy*dy);
                    if (dist > 0) {
                        velocity.x = (dx / dist) * velocity.speed;
                        velocity.y = (dy / dist) * velocity.speed;
                        transform.rotation = Math.atan2(dy, dx);
                    }
                } else if (enemy.type === 'shooter') {
                    const dx = pTransform.x - transform.x;
                    const dy = pTransform.y - transform.y;
                    const dist = Math.sqrt(dx*dx + dy*dy);
                    const desired = 550;
                    if (dist > desired + 50) {
                        velocity.x = (dx / dist) * velocity.speed;
                        velocity.y = (dy / dist) * velocity.speed;
                    } else if (dist < desired - 50) {
                        velocity.x = -(dx / dist) * velocity.speed;
                        velocity.y = -(dy / dist) * velocity.speed;
                    } else {
                        velocity.x = 0;
                        velocity.y = 0;
                    }
                    transform.rotation = Math.atan2(dy, dx);
                    if (enemy.shootCooldown > 0) enemy.shootCooldown -= 1;
                    if (enemy.shootCooldown <= 0 && dist < 1200) {
                        const angle = Math.atan2(dy, dx);
                        const bullet = new Entity();
                        const spawnOffset = 14;
                        const bx = transform.x + Math.cos(angle) * spawnOffset;
                        const by = transform.y + Math.sin(angle) * spawnOffset;
                        bullet.addComponent(new Transform(bx, by, angle));
                        const speed = 3;
                        bullet.addComponent(new Renderable('#ffffff', 5, 0, 0, 'circle', 10));
                        bullet.addComponent(new Projectile('standard', 50, entity.id, Math.ceil(800 / speed)));
                        bullet.addComponent(new Velocity(Math.cos(angle) * speed, Math.sin(angle) * speed, speed));
                        this.addEntityCallback(bullet);
                        enemy.shootCooldown = 75;
                    }
                } else if (enemy.type === 'summoner') {
                    const dx = pTransform.x - transform.x;
                    const dy = pTransform.y - transform.y;
                    const dist = Math.sqrt(dx*dx + dy*dy);
                    if (dist > 800) {
                        velocity.x = (dx / dist) * velocity.speed;
                        velocity.y = (dy / dist) * velocity.speed;
                    } else {
                        velocity.x = 0;
                        velocity.y = 0;
                    }
                    transform.rotation = Math.atan2(dy, dx);
                    if (enemy.summonCooldown > 0) enemy.summonCooldown -= 1;
                    if (enemy.summonCooldown <= 0) {
                    for (let i = 0; i < 2; i++) {
                            const ox = (Math.random() - 0.5) * 120;
                            const oy = (Math.random() - 0.5) * 120;
                            const minion = new Entity();
                            minion.addComponent(new Transform(transform.x + ox, transform.y + oy));
                            minion.addComponent(new Velocity(0, 0, 3));
                            minion.addComponent(new Renderable('#66ff66', 12, 0, 0, 'circle', 5));
                            minion.addComponent(new Health(30, 30));
                            minion.addComponent(new EnemyBehavior('chaser'));
                            minion.tags.add('enemy');
                            this.addEntityCallback(minion);
                        }
                        enemy.summonCooldown = 360;
                        if (this.trailCtx) {
                            this.trailCtx.save();
                            this.trailCtx.globalAlpha = 0.5;
                            this.trailCtx.strokeStyle = '#bb88ff';
                            this.trailCtx.lineWidth = 3;
                            this.trailCtx.beginPath();
                            this.trailCtx.arc(transform.x, transform.y, 30, 0, Math.PI * 2);
                            this.trailCtx.stroke();
                            this.trailCtx.restore();
                        }
                    }
                } else if (enemy.type === 'boss') {
                    const dx = pTransform.x - transform.x;
                    const dy = pTransform.y - transform.y;
                    const dist = Math.sqrt(dx*dx + dy*dy);
                    if (dist > 700) {
                        velocity.x = (dx / dist) * velocity.speed;
                        velocity.y = (dy / dist) * velocity.speed;
                    } else {
                        velocity.x = 0;
                        velocity.y = 0;
                    }
                    transform.rotation = Math.atan2(dy, dx);
                    enemy.bossTimer += 1;
                    if (enemy.bossTimer % 180 === 0) {
                        for (let i = 0; i < 12; i++) {
                            const ang = (Math.PI * 2 * i) / 12;
                            const bullet = new Entity();
                            bullet.addComponent(new Transform(transform.x, transform.y, ang));
                            const speed = 5;
                            bullet.addComponent(new Renderable('#ffcc00', 4, 0, 0, 'circle', 5));
                            bullet.addComponent(new Projectile('standard', 50, entity.id, Math.ceil(900 / speed)));
                            bullet.addComponent(new Velocity(Math.cos(ang) * speed, Math.sin(ang) * speed, speed));
                            this.addEntityCallback(bullet);
                        }
                    }
                    if (enemy.bossTimer % 420 === 0) {
                        for (let i = 0; i < 4; i++) {
                            const minion = new Entity();
                            const ang = (Math.PI / 2) * i;
                            minion.addComponent(new Transform(transform.x + Math.cos(ang) * 180, transform.y + Math.sin(ang) * 180));
                            minion.addComponent(new Velocity(0, 0, 2.5));
                            minion.addComponent(new Renderable('#ffaa00', 16, 0, 0, 'circle', 5));
                            minion.addComponent(new Health(60, 60));
                            minion.addComponent(new EnemyBehavior('shooter'));
                            minion.tags.add('enemy');
                            this.addEntityCallback(minion);
                        }
                    }
                }
            }
        }
    }
}
