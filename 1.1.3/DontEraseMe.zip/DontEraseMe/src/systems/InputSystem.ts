import { System } from '../core/System';
import { Entity } from '../core/Entity';
import { Transform } from '../components/Transform';
import { Velocity } from '../components/Velocity';
import { PlayerControl } from '../components/PlayerControl';
import { InputManager } from '../core/InputManager';

export class InputSystem extends System {
    constructor(
        private input: InputManager,
        private camera: { x: number, y: number }
    ) {
        super();
    }

    public update(dt: number): void {
        for (const entity of this.entities) {
            if (!entity.hasComponent(PlayerControl)) continue;

            const velocity = entity.getComponent(Velocity)!;
            const control = entity.getComponent(PlayerControl)!;
            const transform = entity.getComponent(Transform)!;

            // Reset velocity
            velocity.x = 0;
            velocity.y = 0;

            // Keyboard input
            if (this.input.isKeyDown('w')) velocity.y -= control.speed;
            if (this.input.isKeyDown('s')) velocity.y += control.speed;
            if (this.input.isKeyDown('a')) velocity.x -= control.speed;
            if (this.input.isKeyDown('d')) velocity.x += control.speed;
            
            const mag = Math.hypot(velocity.x, velocity.y);
            if (mag > control.speed) {
                velocity.x = (velocity.x / mag) * control.speed;
                velocity.y = (velocity.y / mag) * control.speed;
            }

            // Update rotation based on mouse
            // Mouse is in screen coordinates, transform is in world coordinates.
            // We need to convert mouse to world coordinates.
            const mouseWorldX = this.input.mouse.x + this.camera.x;
            const mouseWorldY = this.input.mouse.y + this.camera.y;

            const dx = mouseWorldX - transform.x;
            const dy = mouseWorldY - transform.y;
            transform.rotation = Math.atan2(dy, dx);
        }
    }
}
