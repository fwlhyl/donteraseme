import { Component } from '../core/Component';

export type WeaponType = 'standard' | 'shotgun' | 'sniper' | 'rocket' | 'gravity';

export interface WeaponConfig {
    name: string;
    id: number;
    fireRate: number; // Frames between shots (or ms)
    speed: number;
    damage: number;
    count: number; // Bullets per shot
    spread: number; // Radians
    color: string;
    radius: number;
    type: WeaponType;
    range: number;      // Max travel distance
    magSize: number;    // Magazine size
    reloadTime: number; // Frames to reload
}

export const WEAPONS: WeaponConfig[] = [
    { name: "Pistol (Brush)", id: 0, fireRate: 20, speed: 7, damage: 10, count: 1, spread: 0, color: 'yellow', radius: 5, type: 'standard', range: 600, magSize: 12, reloadTime: 60 },
    { name: "Shotgun (Spray)", id: 1, fireRate: 80, speed: 9, damage: 8, count: 8, spread: 0.4, color: 'orange', radius: 3, type: 'shotgun', range: 350, magSize: 7, reloadTime: 90 },
    { name: "Sniper (Pen)", id: 2, fireRate: 100, speed: 18, damage: 50, count: 1, spread: 0, color: 'cyan', radius: 2, type: 'sniper', range: 1200, magSize: 5, reloadTime: 120 },
    { name: "Rocket (Bucket)", id: 3, fireRate: 150, speed: 6, damage: 0, count: 1, spread: 0, color: 'red', radius: 8, type: 'rocket', range: 900, magSize: 1, reloadTime: 150 },
    { name: "Vortex (Blender)", id: 4, fireRate: 350, speed: 4, damage: 0, count: 1, spread: 0, color: '#9900ff', radius: 10, type: 'gravity', range: 600, magSize: 1, reloadTime: 180 }
];

export class Weapon extends Component {
    public currentWeaponIndex: number = 0;
    public cooldown: number = 0;
    public ammo: number[];
    public reloading: boolean = false;
    public reloadTimer: number = 0;
    public unlocked: Set<number> = new Set([0]);
    public fireRateMul: number = 1.0;
    public spreadMul: number = 1.0;
    public speedMul: number = 1.0;

    constructor(
        public index: number = 0
    ) {
        super();
        this.currentWeaponIndex = index;
        this.ammo = WEAPONS.map(w => w.id === index ? w.magSize : w.magSize);
    }

    public get config(): WeaponConfig {
        return WEAPONS[this.currentWeaponIndex];
    }
}
