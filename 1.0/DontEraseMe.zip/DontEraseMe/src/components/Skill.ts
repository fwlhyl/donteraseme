import { Component } from '../core/Component';

export class Skill extends Component {
    constructor(
        public cooldown: number = 0,
        public maxCooldown: number = 300, // 5 seconds at 60fps
        public radius: number = 200,      // Damage radius
        public damage: number = 1000,     // High damage
        public active: boolean = false,
        public dashCooldown: number = 0,
        public dashMaxCooldown: number = 120,
        public dashDistance: number = 180
    ) {
        super();
    }
}
