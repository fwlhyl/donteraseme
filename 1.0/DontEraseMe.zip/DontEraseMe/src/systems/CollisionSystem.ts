import { System } from '../core/System';
import { Entity } from '../core/Entity';
import { Transform } from '../components/Transform';
import { Renderable } from '../components/Renderable';
import { Projectile } from '../components/Projectile';
import { EnemyBehavior } from '../components/EnemyBehavior';
import { Health } from '../components/Health';
import { PlayerControl } from '../components/PlayerControl';
import { ParticleFactory } from '../entities/ParticleFactory';
import { Velocity } from '../components/Velocity'; // Import Velocity
import { Score } from '../components/Score'; // Import Score
import { Experience } from '../components/Experience';

export class CollisionSystem extends System {
    constructor(
        private addEntityCallback?: (entity: Entity) => void,
        private trailCtx?: CanvasRenderingContext2D // Add trailCtx
    ) {
        super();
    }
    private frame: number = 0;
    private enemyContactCooldown: Map<string, number> = new Map();

    // Helper: Draw Blood / Splash
    private drawSplash(ctx: CanvasRenderingContext2D, x: number, y: number, color: string, radius: number) {
        // Only draw splash for explosions (Rocket or Skill) or if explicitly called for death?
        // User Requirement 1: "Only explosion effect (Weapon 4 and Explosion Skill) leaves traces on enemies."
        // Wait, "Weapon damage causes enemies to leave traces" -> User says "Actually should be ONLY explosion".
        // So regular bullets should NOT cause `drawSplash` on death?
        // Or maybe regular death doesn't leave a huge splash, just particles?
        // Re-reading: "Weapon damage causes enemies to leave traces, actually should only be explosion effect (Weapon 4 and Skill) that causes enemy to leave traces."
        // This implies:
        // 1. Regular bullet hit -> No trace (already true, drawSplash is on death).
        // 2. Regular bullet kill -> User says "Only explosion effect... causes enemy to leave traces".
        // So if I kill with pistol, NO splash on canvas?
        // If so, I should wrap `drawSplash` call in a check for weapon type.
        
        // But the code below calls `drawSplash` inside `if (eHealth.current <= 0)`.
        // I need to check `pData.type` there.
        
        const drops = 5 + Math.random() * 5;
        ctx.fillStyle = color;
        ctx.globalAlpha = 0.6;
        
        for(let i=0; i<drops; i++) {
            const angle = Math.random() * Math.PI * 2;
            const dist = Math.random() * radius;
            const r = 2 + Math.random() * (radius / 2);
            
            ctx.beginPath();
            ctx.arc(x + Math.cos(angle)*dist, y + Math.sin(angle)*dist, r, 0, Math.PI*2);
            ctx.fill();
        }
        ctx.globalAlpha = 1.0;
    }

    public update(dt: number): void {
        this.frame += 1;
        const projectiles: Entity[] = [];
        const enemies: Entity[] = [];
        let player: Entity | null = null;

        // 1. Filter entities into categories
        for (const entity of this.entities) {
            if (entity.getComponent(Projectile)) {
                projectiles.push(entity);
            } else if (entity.getComponent(EnemyBehavior)) {
                enemies.push(entity);
            } else if (entity.tags.has('player')) {
                player = entity;
            }
        }

        // 2. Projectile vs Enemy
        for (const projectile of projectiles) {
            const pTransform = projectile.getComponent(Transform)!;
            const pRender = projectile.getComponent(Renderable)!;
            const pData = projectile.getComponent(Projectile)!;
            const pVel = projectile.getComponent(Velocity);

            if (!pTransform || !pRender) continue;

            // Team check: only player's子弹参与“子弹 vs 敌人”判定，避免敌人被友军或自身子弹误伤
            if (player && pData.ownerId !== player.id) {
                continue;
            }

            for (const enemy of enemies) {
                if (!enemy.active) continue;

                const eTransform = enemy.getComponent(Transform)!;
                const eRender = enemy.getComponent(Renderable)!;
                const eHealth = enemy.getComponent(Health)!;
                const eBeh = enemy.getComponent(EnemyBehavior)!;

                if (!eTransform || !eRender || !eHealth) continue;

                // Check collision based on projectile shape
                let hit = false;

                // Gravity Gun: Check if enemy is in range of black hole
                if (pData.type === 'gravity') {
                    // Check if it's a deployed black hole (stationary)
                    // We can check if it has 'blackhole' tag or if life is set to 180 (initial life of deployed BH)
                    // Or just check velocity?
                    // In CollisionSystem we iterate projectiles.
                    // The deployed BH is a projectile.
                    
                    // Actually, let's check distance for pull effect regardless of hit
                    const dx = pTransform.x - eTransform.x;
                    const dy = pTransform.y - eTransform.y;
                    const dist = Math.sqrt(dx*dx + dy*dy);
                    const gravityRadius = 150; // Black hole range
                    
                    if (dist < gravityRadius) {
                        // Suck enemy in!
                        // User: "Weapon 5 no attraction effect".
                        // Logic seems correct: modify velocity.
                        // Issue might be:
                        // 1. Enemy doesn't have Velocity? (It does)
                        // 2. Velocity is overwritten by EnemySystem?
                        // EnemySystem sets velocity based on direction to player.
                        // `velocity.x = (dx / dist) * velocity.speed;`
                        // This OVERWRITES any changes made here.
                        
                        // Fix: EnemySystem should ADD to velocity or apply acceleration.
                        // OR: We apply a separate force that EnemySystem respects?
                        // OR: We modify Transform directly here? (Choppy)
                        // OR: We add a 'ExternalForce' component?
                        
                        // Simplest Fix: Modify Transform directly for "Suck" effect, 
                        // as it overrides movement logic.
                        const pullFactor = 2.0; // Stronger pull
                        eTransform.x += (dx / dist) * pullFactor;
                        eTransform.y += (dy / dist) * pullFactor;
                        
                        // Gravity also deals continuous damage near center
                        if (dist < 30) {
                            eHealth.current -= 0.5; // Damage per frame
                            // Don't set hit = true here, or it will destroy the black hole (if not handled)
                            // We want continuous damage.
                            
                            // Check death here for gravity kill
                            if (eHealth.current <= 0) {
                                hit = true; // Trigger death logic
                            }
                        }
                    }
                } 
                else if (pRender.shape === 'line') {
                    // raycast logic for sniper beam
                    // In RenderSystem, beam end point is stored in pRender.width and pRender.height
                    hit = this.lineCircleCollision(
                        pTransform.x, pTransform.y, 
                        pRender.width, pRender.height, 
                        eTransform.x, eTransform.y, 
                        eRender.radius || 15 
                    );
                }  
                // Normal Collision Logic
                else {
                    const dx = pTransform.x - eTransform.x;
                    const dy = pTransform.y - eTransform.y;
                    const dist = Math.sqrt(dx*dx + dy*dy);
                    const minDist = (pRender.radius || 5) + (eRender.radius || 15);
                    
                    if (dist < minDist) {
                        hit = true;
                    }
                }

                if (hit) {
                    if (eBeh && eBeh.type === 'shield' && eBeh.shield > 0 && pData.type !== 'gravity') {
                        let vx = 0, vy = 0;
                        if (pRender.shape === 'line') {
                            vx = pRender.width - pTransform.x;
                            vy = pRender.height - pTransform.y;
                            const d = Math.hypot(vx, vy) || 1;
                            vx /= d; vy /= d;
                        } else if (pVel) {
                            const d = Math.hypot(pVel.x, pVel.y) || 1;
                            vx = pVel.x / d; vy = pVel.y / d;
                        }
                        const fx = Math.cos(eTransform.rotation);
                        const fy = Math.sin(eTransform.rotation);
                        const dot = vx * fx + vy * fy;
                        if (dot > Math.cos(Math.PI / 3)) {
                            eBeh.shield -= pData.damage;
                            if (this.trailCtx) {
                                this.trailCtx.save();
                                this.trailCtx.globalAlpha = 0.6;
                                this.trailCtx.strokeStyle = '#66ccff';
                                this.trailCtx.beginPath();
                                this.trailCtx.arc(eTransform.x, eTransform.y, (eRender.radius || 20) + 6, eTransform.rotation - Math.PI/3, eTransform.rotation + Math.PI/3);
                                this.trailCtx.stroke();
                                this.trailCtx.restore();
                            }
                            if (pRender.shape !== 'line') {
                                projectile.active = false;
                            }
                            continue;
                        }
                    }
                    // Special logic for Rocket (AOE)
                    if (pData.type === 'rocket') {
                        // Explosion radius
                        const explosionRadius = 100;
                        const explosionDamage = 50;
                        
                        // Find all enemies in range
                        for (const otherEnemy of enemies) {
                            if (!otherEnemy.active) continue;
                            const t = otherEnemy.getComponent(Transform)!;
                            const h = otherEnemy.getComponent(Health)!;
                            
                            const ex = t.x - eTransform.x;
                            const ey = t.y - eTransform.y;
                            const edist = Math.sqrt(ex*ex + ey*ey);
                            
                            if (edist <= explosionRadius) {
                                h.current -= explosionDamage;
                                // Visuals handled below if dead
                                if (h.current <= 0) {
                                    // Let the main loop handle death or mark it here?
                                    // If we mark it inactive here, the outer loop might get confused if it's the current 'enemy'
                                    // But 'enemy' is safe. 'otherEnemy' might be next in loop.
                                    // Just deduct health, let next frame or current loop handle death logic if possible.
                                    // Actually, we need to check death immediately for particles
                                    if (otherEnemy.active) { // Check again to avoid double kill logic
                                        otherEnemy.active = false;
                                        if (this.addEntityCallback) {
                                            const particles = ParticleFactory.createExplosion(t.x, t.y, otherEnemy.getComponent(Renderable)!.color, 8);
                                            for (const p of particles) this.addEntityCallback(p);
                                        }
                                        if (this.trailCtx) {
                                            this.drawSplash(this.trailCtx, t.x, t.y, otherEnemy.getComponent(Renderable)!.color, otherEnemy.getComponent(Renderable)!.radius * 2);
                                        }
                                    }
                                }
                            }
                        }
                        
                        // Create big explosion effect
                        if (this.addEntityCallback) {
                            const particles = ParticleFactory.createExplosion(eTransform.x, eTransform.y, pRender.color, 20);
                            for (const p of particles) this.addEntityCallback(p);
                        }
                        
                        // Rocket Splash on Trail
                        if (this.trailCtx) {
                             // Add extra splash for rocket
                             // User: "Rocket didn't leave explosion splash on enemy".
                             // This block runs when Rocket hits (AOE).
                             // We are looping through enemies.
                             // But this block is OUTSIDE the enemy loop. It uses `eTransform` which is the PRIMARY target.
                             // We want to splash on ALL enemies hit? Or just the center?
                             // "Rocket didn't make enemy leave splash".
                             // The splash should be at the explosion center.
                             // And maybe splashes for all victims?
                              
                             // Let's draw a BIG splash at the center of explosion.
                             this.drawSplash(this.trailCtx, eTransform.x, eTransform.y, pRender.color, 60);
                        }

                        projectile.active = false; // Rocket destroyed on impact
                        break; // Stop checking other enemies for this rocket
                    }

                    // Apply damage (for non-AOE or direct hit)
                    eHealth.current -= pData.damage;
                    
                    // Shrink enemy if it's a chaser
                    if (enemy.getComponent(EnemyBehavior)?.type === 'chaser') {
                         if (eRender.shape === 'circle') {
                             eRender.radius = Math.max(5, eRender.radius - (pData.damage / 5));
                         }
                    }
                    
                    // Remove projectile (unless it's a penetrating sniper beam or special)
                    if (pData.type !== 'sniper' && pData.type !== 'gravity') {
                        projectile.active = false;
                    }

                    // Check enemy death
                    if (eHealth.current <= 0) {
                            enemy.active = false;
                            
                            // Increase Player Score and XP
                            if (player && player.active) {
                                const score = player.getComponent(Score);
                                if (score) {
                                    score.value += 10; // Default points
                                    if (enemy.getComponent(EnemyBehavior)?.type === 'eraser') {
                                        score.value += 40; // Bonus for eraser
                                    }
                                }
                                const exp = player.getComponent(Experience);
                                if (exp) {
                                    exp.xp += 20;
                                }
                            }
                            
                            // Splash effect on death
                            if (this.trailCtx) {
                                // Only Gravity(Blackhole?) causes splash on death here
                                if (pData.type === 'gravity') {
                                    // Draw Enemy Splash
                                    this.drawSplash(this.trailCtx, eTransform.x, eTransform.y, eRender.color, eRender.radius * 2);
                                }
                            }

                            // Spawn particles
                        if (this.addEntityCallback) {
                            const particles = ParticleFactory.createExplosion(eTransform.x, eTransform.y, eRender.color, 10);
                            for (const p of particles) {
                                this.addEntityCallback(p);
                            }
                        }
                    }
                    
                    // If projectile is not piercing, break loop (only hit one enemy)
                    if (pData.type !== 'sniper' && pData.type !== 'gravity') {
                        break; 
                    }
                }
            }
        }

        // 3. Enemy vs Player
        if (player && player.active) {
            const pTransform = player.getComponent(Transform)!;
            const pRender = player.getComponent(Renderable)!;

            for (const enemy of enemies) {
                if (!enemy.active) continue;

                const eTransform = enemy.getComponent(Transform)!;
                const eRender = enemy.getComponent(Renderable)!;

                const dx = pTransform.x - eTransform.x;
                const dy = pTransform.y - eTransform.y;
                const dist = Math.sqrt(dx*dx + dy*dy);
                const minDist = (pRender.radius || 20) + (eRender.radius || 15);

                if (dist < minDist) {
                    const nextAllowed = this.enemyContactCooldown.get(enemy.id) || 0;
                    if (this.frame < nextAllowed) {
                        continue;
                    }
                    this.enemyContactCooldown.set(enemy.id, this.frame + 30);
                    const pHealth = player.getComponent(Health);
                    if (pHealth) {
                        pHealth.current -= 50;
                        // Knockback
                        if (dist > 0) {
                            const nx = (pTransform.x - eTransform.x) / dist;
                            const ny = (pTransform.y - eTransform.y) / dist;
                            const kb = 22;
                            pTransform.x += nx * kb;
                            pTransform.y += ny * kb;
                        }
                        // Screen shake
                        window.dispatchEvent(new CustomEvent('shake', { detail: { mag: 12, frames: 10 } }));
                        if (pHealth.current <= 0) {
                            console.log('GAME OVER! Player died.');
                            player.active = false;
                            const score = player.getComponent(Score)?.value || 0;
                            window.dispatchEvent(new CustomEvent('game-over', { detail: { score } }));
                        }
                    }
                }
            }

            for (const projectile of projectiles) {
                const pData2 = projectile.getComponent(Projectile)!;
                if (!pData2) continue;
                if (pData2.ownerId === player.id) continue;
                const t2 = projectile.getComponent(Transform)!;
                const r2 = projectile.getComponent(Renderable)!;
                if (!t2 || !r2) continue;
                const dx = t2.x - pTransform.x;
                const dy = t2.y - pTransform.y;
                const dist = Math.sqrt(dx*dx + dy*dy);
                const minDist = (r2.radius || 5) + (pRender.radius || 20);
                if (dist < minDist) {
                    const pHealth = player.getComponent(Health);
                    if (pHealth) {
                        pHealth.current -= 50;
                        // Knockback from projectile
                        if (dist > 0) {
                            const nx = (pTransform.x - t2.x) / dist;
                            const ny = (pTransform.y - t2.y) / dist;
                            const kb = 18;
                            pTransform.x += nx * kb;
                            pTransform.y += ny * kb;
                        }
                        const ownerIsBoss = Array.from(this.entities).some(e => e.id === pData2.ownerId && e.getComponent(EnemyBehavior)?.type === 'boss');
                        window.dispatchEvent(new CustomEvent('shake', { detail: { mag: ownerIsBoss ? 18 : 10, frames: ownerIsBoss ? 12 : 8 } }));
                        if (pHealth.current <= 0) {
                            player.active = false;
                            const score = player.getComponent(Score)?.value || 0;
                            window.dispatchEvent(new CustomEvent('game-over', { detail: { score } }));
                        }
                    }
                    projectile.active = false;
                }
            }
        }
    }

    // Helper: Line Segment vs Circle collision
    private lineCircleCollision(x1: number, y1: number, x2: number, y2: number, cx: number, cy: number, r: number): boolean {
        // Vector from start to end
        const dx = x2 - x1;
        const dy = y2 - y1;
        
        // Vector from start to circle center
        const fx = cx - x1;
        const fy = cy - y1;
        
        const len2 = dx*dx + dy*dy;
        // Dot product to find projection of center onto line
        const dot = fx*dx + fy*dy;
        
        // Find closest point on line segment
        let t = dot / len2;
        
        // Clamp t to segment [0, 1]
        if (t < 0) t = 0;
        if (t > 1) t = 1;
        
        // Closest point coordinates
        const closestX = x1 + t * dx;
        const closestY = y1 + t * dy;
        
        // Distance from closest point to circle center
        const distX = closestX - cx;
        const distY = closestY - cy;
        const dist2 = distX*distX + distY*distY;
        
        return dist2 <= r*r;
    }
}
