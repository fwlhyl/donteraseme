import { System } from '../core/System';
import { Transform } from '../components/Transform';
import { Renderable } from '../components/Renderable';
import { Skeleton } from '../components/Skeleton';
import { SpriteAttachments } from '../components/SpriteAttachments';
import { ControlPoint } from '../components/ControlPoint';
import { EnemyBehavior } from '../components/EnemyBehavior';
import { Projectile } from '../components/Projectile';

export class RenderSystem extends System {
    constructor(
        private ctx: CanvasRenderingContext2D,
        private camera: { x: number, y: number },
        private worldWidth: number,
        private worldHeight: number
    ) {
        super();
        window.addEventListener('shake', (e: any) => {
            const mag = e.detail?.mag ?? 8;
            const frames = e.detail?.frames ?? 8;
            this.shakeMag = mag;
            this.shakeFrames = frames;
        });
    }

    private historyCache: Map<string, {x: number, y: number}[]> = new Map();
    private fogCircles: { x: number, y: number, r: number, reveal: number }[] | null = null;
    private shakeFrames: number = 0;
    private shakeMag: number = 0;

    public update(dt: number): void {
        this.ctx.save();

        // 1. Update Camera Position (Follow Player)
        const player = Array.from(this.entities).find(e => e.tags.has('player'));
        if (player) {
            const t = player.getComponent(Transform);
            if (t) {
                // Center camera on player
                this.camera.x = t.x - this.ctx.canvas.width / 2;
                this.camera.y = t.y - this.ctx.canvas.height / 2;

                // Clamp camera to world bounds
                this.camera.x = Math.max(0, Math.min(this.camera.x, this.worldWidth - this.ctx.canvas.width));
                this.camera.y = Math.max(0, Math.min(this.camera.y, this.worldHeight - this.ctx.canvas.height));
            }
        }

        // 2. Draw Background Grid
        this.drawGrid();

        // 3. Render Entities
        // Sort by z-index
        const renderList = Array.from(this.entities).sort((a, b) => {
            const ra = a.getComponent(Renderable);
            const rb = b.getComponent(Renderable);
            if (!ra || !rb) return 0;
            return ra.zIndex - rb.zIndex;
        });

        this.ctx.save();
        
        // Camera Transform with screenshake
        let shakeX = 0, shakeY = 0;
        if (this.shakeFrames > 0) {
            const decay = this.shakeFrames / Math.max(1, (this.shakeMag * 2));
            shakeX = (Math.random() - 0.5) * this.shakeMag * decay;
            shakeY = (Math.random() - 0.5) * this.shakeMag * decay;
            this.shakeFrames -= 1;
        }
        this.ctx.translate(-this.camera.x + shakeX, -this.camera.y + shakeY);
        
        // Draw World Boundary
        this.ctx.strokeStyle = '#444';
        this.ctx.lineWidth = 5;
        this.ctx.strokeRect(0, 0, this.worldWidth, this.worldHeight);

        for (const entity of renderList) {
            const transform = entity.getComponent(Transform);
            const renderable = entity.getComponent(Renderable);

            if (!transform || !renderable || !renderable.visible) continue;

            // If this is the player, we should probably update trail canvas here too?
            // No, TrailSystem handles that.

            this.ctx.save();
            
            if (renderable.shape === 'line') {
                this.ctx.beginPath();
                this.ctx.moveTo(transform.x, transform.y);
                this.ctx.lineTo(renderable.width, renderable.height); // width/height used as endX/endY for line
                this.ctx.strokeStyle = renderable.color;
                this.ctx.lineWidth = 2;
                this.ctx.stroke();
            } else {
                let drawX = transform.x;
                let drawY = transform.y;
                let rotation = transform.rotation;
                const sk = entity.getComponent(Skeleton);
                if (sk && renderable.attachmentBone) {
                    const bone = sk.getBone(renderable.attachmentBone);
                    if (bone) {
                        drawX = bone.worldX + renderable.offsetX;
                        drawY = bone.worldY + renderable.offsetY;
                        rotation = bone.worldRotation + renderable.attachmentRotationOffset;
                    }
                } else if (sk) {
                    const spine = sk.getBone('spine');
                    if (spine) rotation = spine.worldRotation;
                }
                this.ctx.translate(drawX, drawY);
                this.ctx.fillStyle = renderable.color;
                
                if (renderable.shape === 'sprite' && renderable.image) {
                    const img = renderable.image;
                    const ready = (img as any).complete && (img as any).naturalWidth > 0;
                    if (!ready) {
                        this.ctx.save();
                        this.ctx.scale(renderable.scaleX, renderable.scaleY);
                        this.ctx.beginPath();
                        this.ctx.arc(0, 0, renderable.radius, 0, Math.PI * 2);
                        this.ctx.fill();
                        this.ctx.restore();
                        if (entity.tags.has('player')) {
                            this.ctx.save();
                            this.ctx.rotate(rotation);
                            this.ctx.fillStyle = '#ff0000';
                            this.ctx.fillRect(renderable.radius * 0.5, -renderable.radius * 0.3, renderable.radius * 1.2, renderable.radius * 0.6);
                            this.ctx.restore();
                        }
                    } else {
                        const size = renderable.radius * 3;
                        this.ctx.save();
                        this.ctx.scale(renderable.scaleX, renderable.scaleY);
                        this.ctx.drawImage(img, -size/2, -size/2, size, size);
                        this.ctx.restore();
                        if (entity.tags.has('player')) {
                            this.ctx.save();
                            this.ctx.rotate(rotation);
                            this.ctx.fillStyle = '#ff0000';
                            this.ctx.fillRect(size * 0.3, -5, size * 0.5, 10);
                            this.ctx.restore();
                        }
                    }
                } else if (renderable.shape === 'circle') {
                    this.ctx.save();
                    this.ctx.scale(renderable.scaleX, renderable.scaleY);
                    this.ctx.beginPath();
                    this.ctx.arc(0, 0, renderable.radius, 0, Math.PI * 2);
                    this.ctx.fill();
                    this.ctx.restore();
                    
                    const eb = entity.getComponent(EnemyBehavior);
                    if (eb && eb.type === 'shield' && eb.shield > 0) {
                        this.ctx.save();
                        this.ctx.rotate(rotation);
                        this.ctx.strokeStyle = '#66ccff';
                        this.ctx.lineWidth = 4;
                        this.ctx.beginPath();
                        this.ctx.arc(0, 0, renderable.radius + 6, -Math.PI/3, Math.PI/3);
                        this.ctx.stroke();
                        this.ctx.restore();
                    }
                    
                    if (entity.tags.has('blackhole')) {
                        this.ctx.strokeStyle = '#9900ff';
                        this.ctx.lineWidth = 2;
                        this.ctx.stroke();
                        
                        const t = Date.now() / 100;
                        this.ctx.beginPath();
                        this.ctx.arc(0, 0, renderable.radius * 1.5 * (Math.sin(t)+1.2), 0, Math.PI * 2);
                        this.ctx.strokeStyle = `rgba(153, 0, 255, 0.2)`;
                        this.ctx.stroke();
                    }
                    
                    if (entity.tags.has('player')) {
                        this.ctx.save();
                        this.ctx.rotate(rotation);
                        this.ctx.fillStyle = '#ff0000';
                        this.ctx.fillRect(renderable.radius * 0.5, -renderable.radius * 0.3, renderable.radius * 1.2, renderable.radius * 0.6);
                        this.ctx.restore();
                    }
                } else if (renderable.shape === 'rect') {
                    this.ctx.save();
                    this.ctx.scale(renderable.scaleX, renderable.scaleY);
                    this.ctx.fillRect(-renderable.width / 2, -renderable.height / 2, renderable.width, renderable.height);
                    this.ctx.restore();
                } else if (renderable.shape === 'triangle') {
                    this.ctx.save();
                    this.ctx.rotate(rotation);
                    const r = renderable.radius;
                    this.ctx.beginPath();
                    this.ctx.moveTo(0, -r);
                    this.ctx.lineTo(r * 0.866, r * 0.5);
                    this.ctx.lineTo(-r * 0.866, r * 0.5);
                    this.ctx.closePath();
                    this.ctx.fill();
                    const eb = entity.getComponent(EnemyBehavior);
                    if (eb && eb.type === 'boss') {
                        const t = Date.now() / 250;
                        const scale = 1.08 + Math.sin(t) * 0.08;
                        const lw = 2 + Math.abs(Math.sin(t * 1.3)) * 3;
                        this.ctx.strokeStyle = '#ffe066';
                        this.ctx.lineWidth = lw;
                        this.ctx.beginPath();
                        this.ctx.moveTo(0, -r * scale);
                        this.ctx.lineTo(r * 0.866 * scale, r * 0.5 * scale);
                        this.ctx.lineTo(-r * 0.866 * scale, r * 0.5 * scale);
                        this.ctx.closePath();
                        this.ctx.stroke();
                        this.ctx.strokeStyle = 'rgba(255, 204, 0, 0.35)';
                        this.ctx.lineWidth = lw + 4;
                        this.ctx.beginPath();
                        this.ctx.moveTo(0, -r * (scale + 0.05));
                        this.ctx.lineTo(r * 0.866 * (scale + 0.05), r * 0.5 * (scale + 0.05));
                        this.ctx.lineTo(-r * 0.866 * (scale + 0.05), r * 0.5 * (scale + 0.05));
                        this.ctx.closePath();
                        this.ctx.stroke();
                    }
                    this.ctx.restore();
                }
            }

            this.ctx.restore();
            
            const attachments = entity.getComponent(SpriteAttachments);
            if (attachments) {
                for (const part of attachments.parts.sort((a, b) => a.z - b.z)) {
                    if (!(part.image as any).complete || (part.image as any).naturalWidth === 0) continue;
                    const sk3 = entity.getComponent(Skeleton);
                    if (!sk3) continue;
                    const bone = sk3.getBone(part.bone);
                    if (!bone) continue;
                    this.ctx.save();
                    this.ctx.translate(bone.worldX + part.offsetX, bone.worldY + part.offsetY);
                    this.ctx.rotate(bone.worldRotation + part.rotationOffset);
                    this.ctx.drawImage(part.image, -part.width/2, -part.height/2, part.width, part.height);
                    this.ctx.restore();
                }
            }
            
            const cp = entity.getComponent(ControlPoint);
            if (cp) {
                const t = entity.getComponent(Transform);
                if (t) {
                    this.ctx.save();
                    this.ctx.strokeStyle = 'rgba(0, 200, 255, 0.9)';
                    this.ctx.lineWidth = 4;
                    this.ctx.beginPath();
                    this.ctx.arc(t.x, t.y, cp.radius, 0, Math.PI * 2);
                    this.ctx.stroke();
                    const p = Math.max(0, Math.min(1, cp.progress / cp.required));
                    this.ctx.strokeStyle = 'rgba(0, 255, 180, 0.9)';
                    this.ctx.lineWidth = 6;
                    this.ctx.beginPath();
                    this.ctx.arc(t.x, t.y, cp.radius + 6, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * p);
                    this.ctx.stroke();
                    this.ctx.restore();
                }
            }
        }

        // Fog Patches (3-4 medium circles that fade when player approaches)
        if (!this.fogCircles) {
            const count = 3 + Math.floor(Math.random() * 2); // 3 or 4
            this.fogCircles = [];
            for (let i = 0; i < count; i++) {
                const margin = 300;
                const x = Math.random() * (this.worldWidth - margin * 2) + margin;
                const y = Math.random() * (this.worldHeight - margin * 2) + margin;
                const r = 600 + Math.random() * 200; // 600-800
                const reveal = r + 200; // start fading within this distance
                this.fogCircles.push({ x, y, r, reveal });
            }
        }
        if (player) {
            const pt = player.getComponent(Transform);
            if (pt && this.fogCircles && this.fogCircles.length > 0) {
                this.ctx.save();
                this.ctx.translate(-this.camera.x + shakeX, -this.camera.y + shakeY);
                for (const f of this.fogCircles) {
                    const dx = pt.x - f.x;
                    const dy = pt.y - f.y;
                    const d = Math.sqrt(dx * dx + dy * dy);
                    let alpha = 0.75;
                    if (d < f.reveal) {
                        alpha = Math.max(0, 0.75 * (d / f.reveal));
                    }
                    if (alpha > 0.01) {
                        this.ctx.save();
                        this.ctx.globalAlpha = alpha;
                        this.ctx.fillStyle = 'black';
                        this.ctx.beginPath();
                        this.ctx.arc(f.x, f.y, f.r, 0, Math.PI * 2);
                        this.ctx.fill();
                        this.ctx.restore();
                    }
                }
                this.ctx.restore();
            }
        }

        // Overlay pass: enemy bullets highlight on top of fog
        const playerId = player ? player.id : '';
        this.ctx.save();
        this.ctx.translate(-this.camera.x + shakeX, -this.camera.y + shakeY);
        for (const entity of renderList) {
            const proj = entity.getComponent(Projectile);
            if (!proj) continue;
            if (proj.ownerId === playerId) continue;
            const t = entity.getComponent(Transform);
            const r = entity.getComponent(Renderable);
            if (!t || !r) continue;
            if (r.shape !== 'circle') continue;
            this.ctx.save();
            this.ctx.beginPath();
            this.ctx.arc(t.x, t.y, r.radius + 1.5, 0, Math.PI * 2);
            this.ctx.strokeStyle = '#ffffff';
            this.ctx.lineWidth = 2;
            this.ctx.globalAlpha = 0.9;
            this.ctx.stroke();
            this.ctx.restore();
        }
        // Overlay pass: boss silhouette above fog
        for (const entity of renderList) {
            const eb = entity.getComponent(EnemyBehavior);
            if (!eb || eb.type !== 'boss') continue;
            const t = entity.getComponent(Transform);
            const r = entity.getComponent(Renderable);
            if (!t || !r) continue;
            this.ctx.save();
            this.ctx.translate(t.x, t.y);
            this.ctx.rotate(t.rotation);
            const R = r.radius * 1.15;
            const tPulse = Date.now() / 250;
            const scale = 1.15 + Math.sin(tPulse) * 0.1;
            const lw = 4 + Math.abs(Math.sin(tPulse * 1.3)) * 4;
            this.ctx.strokeStyle = '#ffe066';
            this.ctx.lineWidth = lw;
            this.ctx.beginPath();
            this.ctx.moveTo(0, -R * scale);
            this.ctx.lineTo(R * 0.866 * scale, R * 0.5 * scale);
            this.ctx.lineTo(-R * 0.866 * scale, R * 0.5 * scale);
            this.ctx.closePath();
            this.ctx.stroke();
            this.ctx.strokeStyle = 'rgba(255, 204, 0, 0.35)';
            this.ctx.lineWidth = lw + 6;
            this.ctx.beginPath();
            this.ctx.moveTo(0, -R * (scale + 0.06));
            this.ctx.lineTo(R * 0.866 * (scale + 0.06), R * 0.5 * (scale + 0.06));
            this.ctx.lineTo(-R * 0.866 * (scale + 0.06), R * 0.5 * (scale + 0.06));
            this.ctx.closePath();
            this.ctx.stroke();
            this.ctx.restore();
        }
        this.ctx.restore();

        this.ctx.restore();
    }

    private drawGrid() {
        this.ctx.save();
        this.ctx.strokeStyle = 'rgba(255, 255, 255, 0.1)';
        this.ctx.lineWidth = 1;

        const gridSize = 100;
        
        // Calculate visible grid range
        const startX = Math.floor(this.camera.x / gridSize) * gridSize;
        const startY = Math.floor(this.camera.y / gridSize) * gridSize;
        const endX = startX + this.ctx.canvas.width + gridSize;
        const endY = startY + this.ctx.canvas.height + gridSize;

        this.ctx.translate(-this.camera.x, -this.camera.y);

        this.ctx.beginPath();
        for (let x = startX; x <= endX; x += gridSize) {
            this.ctx.moveTo(x, startY);
            this.ctx.lineTo(x, endY);
        }
        for (let y = startY; y <= endY; y += gridSize) {
            this.ctx.moveTo(startX, y);
            this.ctx.lineTo(endX, y);
        }
        this.ctx.stroke();

        // Draw World Borders
        this.ctx.strokeStyle = 'rgba(255, 0, 0, 0.5)';
        this.ctx.lineWidth = 5;
        this.ctx.strokeRect(0, 0, this.worldWidth, this.worldHeight);

        this.ctx.restore();
    }
}
