import { System } from '../core/System';
import { Weapon } from '../components/Weapon';
import { PlayerControl } from '../components/PlayerControl';
import { Health } from '../components/Health'; // Import Health
import { Skill } from '../components/Skill';
import { Score } from '../components/Score'; // Import Score
import { Renderable } from '../components/Renderable';
import { Trail } from '../components/Trail';
import { Transform } from '../components/Transform'; // Import Transform
import { Experience } from '../components/Experience';

export class UISystem extends System {
    private uiContainer: HTMLElement;
    private weaponDisplay: HTMLElement;
    private statsDisplay: HTMLElement; // Add Stats Display
    private skillDisplay: HTMLElement;
    private scoreDisplay: HTMLElement;
    private perkModal: HTMLElement | null = null;
    private perkButtons: HTMLButtonElement[] = [];
    private announceEl: HTMLElement | null = null;

    private pauseBtn: HTMLElement;
    private pauseMenu: HTMLElement;
    private resumeBtn: HTMLElement;
    private colorPalette: HTMLElement;
    private settingSize: HTMLInputElement;
    private settingAlpha: HTMLInputElement;
    private sizeVal: HTMLElement;
    private alphaVal: HTMLElement;

    private isPaused: boolean = false;

    constructor() {
        super();
        this.uiContainer = document.getElementById('ui')!;
        
        // Score Display
        this.scoreDisplay = document.createElement('div');
        this.scoreDisplay.style.fontSize = '24px';
        this.scoreDisplay.style.fontWeight = 'bold';
        this.scoreDisplay.style.color = '#ffd700'; // Gold
        this.scoreDisplay.style.marginBottom = '10px';
        this.uiContainer.appendChild(this.scoreDisplay);

        // Stats Display (Wave, HP)
        this.statsDisplay = document.createElement('div');
        this.statsDisplay.style.fontSize = '18px';
        this.statsDisplay.style.marginBottom = '10px';
        this.uiContainer.appendChild(this.statsDisplay);

        // Create Weapon Display
        this.weaponDisplay = document.createElement('div');
        this.weaponDisplay.style.fontSize = '20px';
        this.weaponDisplay.style.fontWeight = 'bold';
        this.weaponDisplay.style.marginTop = '10px';
        this.weaponDisplay.style.color = 'white';
        this.uiContainer.appendChild(this.weaponDisplay);

        // Skill Display
        this.skillDisplay = document.createElement('div');
        this.skillDisplay.style.fontSize = '20px';
        this.skillDisplay.style.fontWeight = 'bold';
        this.skillDisplay.style.marginTop = '10px';
        this.skillDisplay.style.color = 'white';
        this.uiContainer.appendChild(this.skillDisplay);

        // Pause Menu Elements
        this.pauseBtn = document.getElementById('pause-btn')!;
        this.pauseMenu = document.getElementById('pause-menu')!;
        this.resumeBtn = document.getElementById('resume-btn')!;
        this.colorPalette = document.getElementById('color-palette')!;
        this.settingSize = document.getElementById('setting-size') as HTMLInputElement;
        this.settingAlpha = document.getElementById('setting-alpha') as HTMLInputElement;
        this.sizeVal = document.getElementById('size-val')!;
        this.alphaVal = document.getElementById('alpha-val')!;

        this.setupPauseMenu();
        this.setupPerkModal();
        this.setupAnnounce();
    }

    private setupPauseMenu() {
        // Toggle Pause
        this.pauseBtn.addEventListener('click', () => {
            this.togglePause();
        });

        this.resumeBtn.addEventListener('click', () => {
            this.togglePause();
        });

        // Colors
        const colors = ['#ffffff', '#ff0000', '#00ff00', '#0000ff', '#ffff00', '#ff00ff', '#00ffff', '#ffa500', '#000000'];
        colors.forEach(color => {
            const swatch = document.createElement('div');
            swatch.style.width = '30px';
            swatch.style.height = '30px';
            swatch.style.borderRadius = '50%';
            swatch.style.backgroundColor = color;
            swatch.style.cursor = 'pointer';
            swatch.style.border = '2px solid rgba(255,255,255,0.2)';
            
            swatch.addEventListener('click', () => {
                this.updatePlayerSettings('color', color);
                // Highlight selection
                Array.from(this.colorPalette.children).forEach((c: any) => c.style.borderColor = 'rgba(255,255,255,0.2)');
                swatch.style.borderColor = 'white';
            });
            this.colorPalette.appendChild(swatch);
        });

        // Size
        this.settingSize.addEventListener('input', (e: any) => {
            const val = parseInt(e.target.value);
            this.sizeVal.innerText = val.toString();
            this.updatePlayerSettings('size', val);
        });

        // Alpha
        this.settingAlpha.addEventListener('input', (e: any) => {
            const val = parseInt(e.target.value);
            this.alphaVal.innerText = val + '%';
            this.updatePlayerSettings('alpha', val / 100);
        });
    }

    private setupAnnounce() {
        const el = document.createElement('div');
        el.style.position = 'fixed';
        el.style.left = '50%';
        el.style.top = '80px';
        el.style.transform = 'translateX(-50%)';
        el.style.padding = '10px 20px';
        el.style.background = 'rgba(0,0,0,0.6)';
        el.style.color = '#ffd700';
        el.style.fontSize = '28px';
        el.style.fontWeight = 'bold';
        el.style.borderRadius = '6px';
        el.style.display = 'none';
        el.style.zIndex = '9999';
        document.body.appendChild(el);
        this.announceEl = el;
        window.addEventListener('announce', (e: any) => {
            const text = e.detail?.text || '';
            if (!this.announceEl) return;
            this.announceEl.textContent = text;
            this.announceEl.style.display = 'block';
            this.announceEl.style.opacity = '1';
            setTimeout(() => {
                if (!this.announceEl) return;
                this.announceEl.style.transition = 'opacity 0.6s';
                this.announceEl.style.opacity = '0';
                setTimeout(() => {
                    if (this.announceEl) {
                        this.announceEl.style.display = 'none';
                        this.announceEl.style.transition = '';
                    }
                }, 700);
            }, 1600);
        });
    }

    private setupPerkModal() {
        const modal = document.createElement('div');
        modal.style.position = 'fixed';
        modal.style.left = '0';
        modal.style.top = '0';
        modal.style.width = '100%';
        modal.style.height = '100%';
        modal.style.backgroundColor = 'rgba(0,0,0,0.6)';
        modal.style.display = 'none';
        modal.style.alignItems = 'center';
        modal.style.justifyContent = 'center';
        modal.style.zIndex = '9999';
        const panel = document.createElement('div');
        panel.style.background = '#111';
        panel.style.padding = '20px';
        panel.style.borderRadius = '8px';
        panel.style.display = 'flex';
        panel.style.gap = '12px';
        for (let i = 0; i < 3; i++) {
            const btn = document.createElement('button');
            btn.style.padding = '12px 16px';
            btn.style.fontSize = '16px';
            btn.style.cursor = 'pointer';
            panel.appendChild(btn);
            this.perkButtons.push(btn);
        }
        modal.appendChild(panel);
        document.body.appendChild(modal);
        this.perkModal = modal;
        window.addEventListener('choose-perk', (e: any) => {
            const picks: string[] = e.detail?.picks || [];
            if (!this.perkModal) return;
            for (let i = 0; i < this.perkButtons.length; i++) {
                const btn = this.perkButtons[i];
                const label = picks[i] || '';
                btn.textContent = label;
                btn.onclick = () => {
                    this.applyPerk(label);
                    this.perkModal!.style.display = 'none';
                    window.dispatchEvent(new CustomEvent('game-pause', { detail: { paused: false } }));
                };
            }
            this.perkModal.style.display = 'flex';
        });
    }

    private applyPerk(label: string) {
        for (const e of this.entities) {
            if (!e.tags.has('player')) continue;
            const pc = e.getComponent(PlayerControl);
            const weapon = e.getComponent(Weapon);
            const hp = e.getComponent(Health);
            const skill = e.getComponent(Skill);
            if (label.includes('移速') && pc) {
                pc.speed *= 1.1;
                if (weapon) {
                    weapon.speedMul *= 1.05;
                }
            } else if (label.includes('射速') && weapon) {
                weapon.fireRateMul = Math.max(0.5, weapon.fireRateMul * 0.9);
            } else if (label.includes('散布') && weapon) {
                weapon.spreadMul = Math.max(0.5, weapon.spreadMul * 0.8);
            } else if (label.includes('生命') && hp) {
                hp.max += 30;
                hp.current += 30;
            } else if (label.includes('冷却') && skill) {
                skill.maxCooldown = Math.floor(skill.maxCooldown * 0.85);
                skill.dashMaxCooldown = Math.floor(skill.dashMaxCooldown * 0.85);
            }
        }
    }

    private togglePause() {
        this.isPaused = !this.isPaused;
        if (this.isPaused) {
            this.pauseMenu.style.display = 'flex';
            window.dispatchEvent(new CustomEvent('game-pause', { detail: { paused: true } }));
        } else {
            this.pauseMenu.style.display = 'none';
            window.dispatchEvent(new CustomEvent('game-pause', { detail: { paused: false } }));
        }
    }

    private updatePlayerSettings(key: string, value: any) {
        for (const entity of this.entities) {
            if (entity.tags.has('player')) {
                if (key === 'color') {
                    const renderable = entity.getComponent(Renderable);
                    if (renderable) renderable.color = value;
                    const trail = entity.getComponent(Trail);
                    if (trail) trail.color = value;
                } else if (key === 'size') {
                    const renderable = entity.getComponent(Renderable);
                    if (renderable) renderable.radius = value;
                    const trail = entity.getComponent(Trail);
                    if (trail) trail.width = value * 1.5; // Trail slightly larger
                } else if (key === 'alpha') {
                    const trail = entity.getComponent(Trail);
                    if (trail) trail.alpha = value;
                }
            }
        }
    }

    public update(dt: number): void {
        for (const entity of this.entities) {
            if (entity.tags.has('player')) {
                const weapon = entity.getComponent(Weapon);
                const health = entity.getComponent(Health); // Get Player Health
                const skill = entity.getComponent(Skill);
                const score = entity.getComponent(Score);
                
                if (score) {
                    this.scoreDisplay.textContent = `SCORE: ${score.value}`;
                }

                // Update Stats (Wave is tricky to get here without reference to WaveSystem)
                // Let's just show HP for now. 
                // To get Wave, we might need a global GameState component or similar.
                const exp = entity.getComponent(Experience);
                if (health) {
                    const lvlTxt = exp ? ` LVL: ${exp.level} (${exp.xp}/${exp.next})` : '';
                    this.statsDisplay.textContent = `HP: ${Math.ceil(health.current)} / ${health.max}${lvlTxt}`;
                }

                if (weapon) {
                    const config = weapon.config;
                    const ammo = weapon.ammo[weapon.currentWeaponIndex] ?? 0;
                    const reloadTxt = weapon.reloading ? ' (reloading...)' : '';
                    this.weaponDisplay.textContent = `WEAPON: ${config.name}  ${ammo}/${config.magSize}${reloadTxt}`;
                    this.weaponDisplay.style.color = config.color;
                }

                if (skill) {
                    const lvl = exp ? exp.level : 0;
                    const parts: string[] = [];
                    if (lvl < 10) {
                        parts.push(`Dash: LV10 解锁`);
                    } else {
                        if (skill.dashCooldown > 0) {
                            parts.push(`Dash: ${(skill.dashCooldown / 60).toFixed(1)}s`);
                        } else {
                            parts.push(`Dash: READY (Shift)`);
                        }
                    }
                    if (lvl < 20) {
                        parts.push(`Explosion: LV20 解锁`);
                        this.skillDisplay.style.color = 'gray';
                    } else {
                        if (skill.cooldown > 0) {
                            parts.push(`Explosion: ${(skill.cooldown / 60).toFixed(1)}s`);
                            this.skillDisplay.style.color = 'gray';
                        } else {
                            parts.push(`Explosion: READY (Space)`);
                            this.skillDisplay.style.color = 'lime';
                        }
                    }
                    this.skillDisplay.textContent = parts.join('  |  ');
                }
            }
        }
    }
}
