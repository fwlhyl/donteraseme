import { System } from '../core/System';
import { Entity } from '../core/Entity';
import { Transform } from '../components/Transform';
import { Weapon } from '../components/Weapon';
import { InputManager } from '../core/InputManager';
import { PlayerControl } from '../components/PlayerControl';
import { Renderable } from '../components/Renderable';
import { BulletFactory } from '../entities/BulletFactory';
import { WEAPONS } from '../components/Weapon';
import { Projectile } from '../components/Projectile';

export class WeaponSystem extends System {
    constructor(
        private input: InputManager,
        private addEntityCallback: (entity: Entity) => void,
        private trailCtx?: CanvasRenderingContext2D
    ) {
        super();
    }

    public update(dt: number): void {
        for (const entity of this.entities) {
            const weapon = entity.getComponent(Weapon);
            const transform = entity.getComponent(Transform);
            const renderable = entity.getComponent(Renderable);
            
            if (weapon && transform && renderable) {
                // Handle cooldown
                if (weapon.cooldown > 0) {
                    weapon.cooldown -= 1; // Assuming 60fps frame based cooldown
                }

                // Only player controls weapon for now
                if (entity.tags.has('player')) {
                    this.handlePlayerInput(entity, weapon, transform, renderable);
                }
            }
        }
    }

    private handlePlayerInput(player: Entity, weapon: Weapon, transform: Transform, renderable: Renderable): void {
        // Weapon switching
        if (this.input.isKeyDown('1')) this.switchWeapon(weapon, 0);
        if (this.input.isKeyDown('2')) this.switchWeapon(weapon, 1);
        if (this.input.isKeyDown('3')) this.switchWeapon(weapon, 2);
        if (this.input.isKeyDown('4')) this.switchWeapon(weapon, 3);
        if (this.input.isKeyDown('5')) this.switchWeapon(weapon, 4);
        
        // Reload
        if (this.input.isKeyDown('r') || this.input.isKeyDown('R')) {
            this.startReload(weapon);
        }

        // Update attacking state based on mouse input
        player.attacking = this.input.mouse.down;

        // Handle reloading timer
        if (weapon.reloading) {
            if (weapon.reloadTimer > 0) {
                weapon.reloadTimer -= 1;
            } else {
                const cfg = weapon.config;
                weapon.ammo[weapon.currentWeaponIndex] = cfg.magSize;
                weapon.reloading = false;
            }
        }
        
        // Shooting
        if (this.input.mouse.down && weapon.cooldown <= 0 && !weapon.reloading) {
            const idx = weapon.currentWeaponIndex;
            if (weapon.ammo[idx] > 0) {
                this.shoot(player, weapon, transform, renderable.color);
                weapon.ammo[idx] -= 1;
                if (weapon.ammo[idx] <= 0) {
                    this.startReload(weapon);
                }
            } else {
                this.startReload(weapon);
            }
        }
    }

    private switchWeapon(weapon: Weapon, index: number): void {
        if (!weapon.unlocked.has(index)) return;
        if (weapon.currentWeaponIndex !== index) {
            weapon.currentWeaponIndex = index;
            weapon.cooldown = 20; // Reset cooldown on switch
            console.log(`Switched to weapon: ${WEAPONS[index].name}`);
        }
    }

    private shoot(owner: Entity, weapon: Weapon, transform: Transform, ownerColor: string): void {
        const config = weapon.config;
        weapon.cooldown = Math.max(1, Math.round(config.fireRate * weapon.fireRateMul));
        
        // Set attack state for player
        if (owner.tags.has('player')) {
            // We now update attack state based on mouse down in handlePlayerInput
            // rather than a timeout here.
        }
        
        // Determine bullet color
        let bulletColor = config.color;
        // All weapons except Pistol (0) should use player color
        if (config.id !== 0) {
            bulletColor = ownerColor;
        }

        // Sniper special logic (Raycast)
        if (config.type === 'sniper') {
            // Create a visual beam entity
            const beam = new Entity();
            
            // Calculate beam end point (very far away)
            const range = config.range || 1200;
            const angle = transform.rotation; // Use rotation directly
            const endX = transform.x + Math.cos(angle) * range;
            const endY = transform.y + Math.sin(angle) * range;
            
            // We use Transform for start point, and Renderable width/height for end point (as per RenderSystem logic)
            beam.addComponent(new Transform(transform.x, transform.y));
            // Store end coordinates in width/height for line drawing
            beam.addComponent(new Renderable(bulletColor, 0, endX, endY, 'line', 5)); // Use bulletColor
            
            // Add a temporary component to remove it after a few frames
            beam.addComponent(new Projectile('sniper', config.damage, owner.id, 5)); // 5 frames life
            
            this.addEntityCallback(beam);
            
            // Draw Trail Line
            // Delay drawing the sniper trail line slightly so it happens AFTER the eraser 
            // has processed its death and stopped erasing.
            if (this.trailCtx) {
                // By deferring this to the end of the current event loop or next frame,
                // we ensure all CollisionSystem deaths are processed first.
                // Using setTimeout(..., 0) pushes this to the macro-task queue, 
                // which runs after the current frame's systems finish updating.
                setTimeout(() => {
                    if (this.trailCtx) {
                        this.trailCtx.save();
                        this.trailCtx.globalCompositeOperation = 'source-over';
                        this.trailCtx.beginPath();
                        this.trailCtx.moveTo(transform.x, transform.y);
                        this.trailCtx.lineTo(endX, endY);
                        this.trailCtx.strokeStyle = bulletColor;
                        this.trailCtx.lineWidth = 2;
                        this.trailCtx.stroke();
                        this.trailCtx.restore();
                    }
                }, 0);
            }
            
            return;
        }

        for (let i = 0; i < config.count; i++) {
            const spread = (Math.random() - 0.5) * config.spread * weapon.spreadMul;
            const angle = transform.rotation + spread;
            
            // Create bullet entity
            const bullet = BulletFactory.create(
                config,
                transform.x,
                transform.y,
                angle,
                bulletColor, // Use bulletColor
                owner.id,
                weapon.speedMul
            );
            
            this.addEntityCallback(bullet);
        }
    }
    
    private startReload(weapon: Weapon) {
        if (weapon.reloading) return;
        const cfg = weapon.config;
        weapon.reloading = true;
        weapon.reloadTimer = cfg.reloadTime;
        weapon.cooldown = cfg.reloadTime;
    }
}
