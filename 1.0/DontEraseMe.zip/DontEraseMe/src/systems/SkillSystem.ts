import { System } from '../core/System';
import { Entity } from '../core/Entity';
import { InputManager } from '../core/InputManager';
import { Transform } from '../components/Transform';
import { Skill } from '../components/Skill';
import { EnemyBehavior } from '../components/EnemyBehavior';
import { Health } from '../components/Health';
import { ParticleFactory } from '../entities/ParticleFactory';

import { Renderable } from '../components/Renderable';
import { Experience } from '../components/Experience';

export class SkillSystem extends System {
    constructor(
        private input: InputManager,
        private trailCtx: CanvasRenderingContext2D,
        private camera: { x: number, y: number, shakeX: number, shakeY: number, shakeTimer: number },
        private addEntityCallback: (entity: Entity) => void
    ) {
        super();
    }

    public update(dt: number): void {
        // 1. Update Camera Shake
        if (this.camera.shakeTimer > 0) {
            this.camera.shakeTimer -= dt;
            if (this.camera.shakeTimer <= 0) {
                this.camera.shakeX = 0;
                this.camera.shakeY = 0;
            } else {
                this.camera.shakeX = (Math.random() - 0.5) * 20;
                this.camera.shakeY = (Math.random() - 0.5) * 20;
            }
        }

        // 2. Handle Skill Logic
        for (const entity of this.entities) {
            const skill = entity.getComponent(Skill);
            const transform = entity.getComponent(Transform);
            const renderable = entity.getComponent(Renderable);
            const exp = entity.getComponent(Experience);

            if (!skill || !transform) continue;

            // Reduce cooldown
            if (skill.cooldown > 0) {
                skill.cooldown -= 1; // Decrement per frame (approx 60fps)
            }
            if (skill.dashCooldown > 0) {
                skill.dashCooldown -= 1;
            }

            // Check Input
            if (this.input.isKeyDown(' ') && skill.cooldown <= 0 && exp && exp.level >= 20) {
                this.activateSkill(entity, skill, transform, renderable ? renderable.color : '#ffffff');
            }
            if ((this.input.isKeyDown('Shift') || this.input.isKeyDown('ShiftLeft') || this.input.isKeyDown('ShiftRight')) && skill.dashCooldown <= 0 && exp && exp.level >= 10) {
                this.activateDash(skill, transform, renderable ? renderable.color : '#ffffff');
            }
        }
    }

    private activateSkill(player: Entity, skill: Skill, transform: Transform, color: string): void {
        skill.cooldown = skill.maxCooldown;
        
        // 1. Visual Effect: Splatter on Trail Canvas (Player Color)
        // User: "Explosion skill player itself leaves no trace".
        // Wait: "Explosion skill player no trace... and enemy traces are red".
        // Re-reading: "5: Player's explosion skill needs to be visible... form round explosion ink effect... enemies receiving damage also leave explosion ink effect."
        // User Complaint 2: "Explosion skill player itself no trace".
        // So I MUST draw player trace.
        this.drawSplatter(transform.x, transform.y, color);

        // 2. Gameplay Effect: Damage Enemies
        // We need to iterate ALL entities to find enemies.
        // Since this.entities contains ALL entities in the game (as registered in Game.ts), we can iterate.
        for (const target of this.entities) {
            if (!target.active || target === player) continue;
            
            const enemy = target.getComponent(EnemyBehavior);
            const targetTransform = target.getComponent(Transform);
            const health = target.getComponent(Health);

            if (enemy && targetTransform) {
                const dist = Math.hypot(transform.x - targetTransform.x, transform.y - targetTransform.y);
                
                if (dist < skill.radius + 20) { // +20 for enemy radius approximation
                    // Apply Damage
                    if (health) {
                        health.current -= skill.damage;
                        if (health.current <= 0) {
                            // Kill Enemy
                            target.active = false;
                            
                            // Spawn Particles
                            const particles = ParticleFactory.createExplosion(
                                targetTransform.x, 
                                targetTransform.y, 
                                '#ff0000', // Enemy color usually
                                15 // Count
                            );
                            particles.forEach(p => this.addEntityCallback(p));
                            
                            // Draw Blood on Trail Canvas (Enemy Color)
                            // User: "Explosion skill... enemy leaves explosion ink marks"
                            // User: "Enemies traces are red, should be enemy color".
                            // I used '#ff0000' hardcoded.
                            const enemyRender = target.getComponent(Renderable);
                            const enemyColor = enemyRender ? enemyRender.color : '#ff0000';
                            
                            this.drawBlood(targetTransform.x, targetTransform.y, enemyColor);
                            
                            // Draw Splatter for enemy death by skill
                            // this.drawSplatter(targetTransform.x, targetTransform.y, '#ff0000'); // Redundant if drawBlood does it?
                        }
                    }
                }
            }
        }

        // 3. Camera Shake
        this.camera.shakeTimer = 0.2; // 0.2 seconds
    }

    private activateDash(skill: Skill, transform: Transform, color: string): void {
        skill.dashCooldown = skill.dashMaxCooldown;
        const dirX = Math.cos(transform.rotation);
        const dirY = Math.sin(transform.rotation);
        const steps = 6;
        const stepDist = skill.dashDistance / steps;
        for (let i = 0; i < steps; i++) {
            const px = transform.x;
            const py = transform.y;
            transform.x += dirX * stepDist;
            transform.y += dirY * stepDist;
            this.trailCtx.save();
            this.trailCtx.globalAlpha = 0.2;
            this.trailCtx.fillStyle = color;
            this.trailCtx.beginPath();
            this.trailCtx.arc(px, py, 8, 0, Math.PI * 2);
            this.trailCtx.fill();
            this.trailCtx.restore();
        }
    }

    private drawSplatter(x: number, y: number, color: string): void {
        const count = 20 + Math.random() * 10;
        
        this.trailCtx.save();
        this.trailCtx.fillStyle = color;
        this.trailCtx.globalAlpha = 0.8;
        
        for (let i = 0; i < count; i++) {
            const angle = Math.random() * Math.PI * 2;
            const dist = Math.random() * 150; // explosion radius
            const size = 5 + Math.random() * 20;
            
            const sx = x + Math.cos(angle) * dist;
            const sy = y + Math.sin(angle) * dist;

            this.trailCtx.beginPath();
            this.trailCtx.arc(sx, sy, size, 0, Math.PI * 2);
            this.trailCtx.fill();
            
            // Draw connecting lines
            this.trailCtx.beginPath();
            this.trailCtx.moveTo(x, y);
            this.trailCtx.lineTo(sx, sy);
            this.trailCtx.strokeStyle = color;
            this.trailCtx.lineWidth = size / 2;
            this.trailCtx.stroke();
        }
        this.trailCtx.restore();
    }

    private drawBlood(x: number, y: number, color: string): void {
        const drops = 5 + Math.random() * 5;
        this.trailCtx.save();
        this.trailCtx.fillStyle = color;
        this.trailCtx.globalAlpha = 0.6;
        
        for(let i=0; i<drops; i++) {
            const angle = Math.random() * Math.PI * 2;
            const dist = Math.random() * 25; 
            const radius = 5 + Math.random() * 12; 
            
            this.trailCtx.beginPath();
            this.trailCtx.arc(x + Math.cos(angle)*dist, y + Math.sin(angle)*dist, radius, 0, Math.PI*2);
            this.trailCtx.fill();
        }
        this.trailCtx.restore();
    }
}
