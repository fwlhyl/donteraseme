export interface CharacterConfig {
    id: string;
    name: string;
    description: string;
    baseHp: number;
    baseSpeed: number;
    // 角色专属技能描述
    uniqueSkillName: string;
    uniqueSkillDesc: string;
}

export const CHARACTERS: CharacterConfig[] = [
    {
        id: 'collector',
        name: '收藏家 (Collector)',
        description: '平衡的基础属性，能快速积累财富',
        baseHp: 100,
        baseSpeed: 5,
        uniqueSkillName: '打钱',
        uniqueSkillDesc: '随着游戏存活时间增加，金币获取量逐渐提升'
    },
    {
        id: 'graffiti',
        name: '街头涂鸦客 (Graffiti Artist)',
        description: '高移速，擅长走位与地形控制',
        baseHp: 80,
        baseSpeed: 6.5,
        uniqueSkillName: '修正带护城河',
        uniqueSkillDesc: '移动时留下减速带，闭合图形会对内部敌人造成高额伤害'
    },
    {
        id: 'classical',
        name: '古典油画家 (Classical Painter)',
        description: '重装坦克，生存能力极强',
        baseHp: 150,
        baseSpeed: 3.5,
        uniqueSkillName: '厚涂',
        uniqueSkillDesc: '自带护盾抵挡一次伤害，破裂后一定时间重新生成'
    },
    {
        id: 'sketcher',
        name: '速写漫画家 (Sketch Artist)',
        description: '玻璃大炮，极致的射速和换弹',
        baseHp: 60,
        baseSpeed: 5,
        uniqueSkillName: '灵光一闪',
        uniqueSkillDesc: '换弹速度极快，每次换弹后短时间内射速翻倍'
    },
    {
        id: 'watercolor',
        name: '水彩插画师 (Watercolorist)',
        description: '擅长持续伤害和范围扩散',
        baseHp: 90,
        baseSpeed: 4.5,
        uniqueSkillName: '水痕',
        uniqueSkillDesc: '击杀敌人后在原地留下水痕毒沼，造成持续伤害'
    },
    {
        id: 'digital',
        name: '数字板绘师 (Digital Artist)',
        description: '自动化输出，伴随召唤物',
        baseHp: 80,
        baseSpeed: 5,
        uniqueSkillName: 'Ctrl+C',
        uniqueSkillDesc: '自带“数位笔”浮游炮，周期性复制上一次强力攻击'
    },
    {
        id: 'calligrapher',
        name: '书法家 (Calligrapher)',
        description: '极高单发爆发，牺牲移动开火',
        baseHp: 100,
        baseSpeed: 5,
        uniqueSkillName: '入木三分',
        uniqueSkillDesc: '静止时伤害不断叠加，且子弹具有极强穿透力'
    },
    {
        id: 'ink',
        name: '水墨画家 (Ink Painter)',
        description: '利用致盲和隐蔽进行反击',
        baseHp: 90,
        baseSpeed: 5,
        uniqueSkillName: '墨染',
        uniqueSkillDesc: '受击喷射致盲水墨团，范围内的敌人丢失目标原地发愣'
    }
];

export enum SkillCategory {
    BASE_STATS = '基础属性强化',
    RELOAD = '换弹触发系',
    HIT = '命中/暴击触发系',
    KILL = '击杀触发系',
    SUMMON = '召唤物系',
    DEFENSE = '防御/受击触发系',
    MOVEMENT = '走位互动系',
    ELEMENT = '元素附魔系',
    SYNERGY = '双生联动系'
}

export interface SkillLevelConfig {
    level: number;
    description: string;
    // 后续可在这里添加具体的数值字段，如 value1, value2 等
    // 以便在业务逻辑中直接读取
    value?: number;
}

export interface SkillConfig {
    id: string;
    name: string;
    category: SkillCategory;
    maxLevel: number;
    levels: SkillLevelConfig[];
    prerequisites?: string[]; // 前置技能ID（比如双生联动需要2个）
}

// 技能配置
export const SKILLS: SkillConfig[] = [
    // ================== 基础属性强化 ==================
    {
        id: 'base_speed', name: '健步如飞 (移速提升)', category: SkillCategory.BASE_STATS, maxLevel: 3,
        levels: [
            { level: 1, description: '移速 +10%', value: 0.1 },
            { level: 2, description: '移速 +25%', value: 0.25 },
            { level: 3, description: '移速 +50%', value: 0.5 }
        ]
    },
    {
        id: 'base_firerate', name: '灵感迸发 (射速提升)', category: SkillCategory.BASE_STATS, maxLevel: 3,
        levels: [
            { level: 1, description: '射速 +10%', value: 0.1 },
            { level: 2, description: '射速 +25%', value: 0.25 },
            { level: 3, description: '射速 +50%', value: 0.5 }
        ]
    },
    {
        id: 'base_dodge', name: '躲避伤害 (闪避提升)', category: SkillCategory.BASE_STATS, maxLevel: 3,
        levels: [
            { level: 1, description: '有 10% 概率避免受到伤害', value: 0.1 },
            { level: 2, description: '有 20% 概率避免受到伤害', value: 0.2 },
            { level: 3, description: '有 30% 概率避免受到伤害', value: 0.3 }
        ]
    },
    {
        id: 'base_health', name: '生命强化 (最大生命提升)', category: SkillCategory.BASE_STATS, maxLevel: 3,
        levels: [
            { level: 1, description: '最大生命值 +10%', value: 0.1 },
            { level: 2, description: '最大生命值 +25%', value: 0.25 },
            { level: 3, description: '最大生命值 +50%', value: 0.5 }
        ]
    },
    {
        id: 'base_damage', name: '武器伤害 (攻击提升)', category: SkillCategory.BASE_STATS, maxLevel: 3,
        levels: [
            { level: 1, description: '伤害 +10%', value: 0.1 },
            { level: 2, description: '伤害 +25%', value: 0.25 },
            { level: 3, description: '伤害 +50%', value: 0.5 }
        ]
    },
    {
        id: 'base_reload', name: '换弹速度 (换弹提升)', category: SkillCategory.BASE_STATS, maxLevel: 3,
        levels: [
            { level: 1, description: '换弹时间 -10%', value: 0.1 },
            { level: 2, description: '换弹时间 -25%', value: 0.25 },
            { level: 3, description: '换弹时间 -50%', value: 0.5 }
        ]
    },
    {
        id: 'base_trail', name: '轨迹粗细 (覆盖提升)', category: SkillCategory.BASE_STATS, maxLevel: 3,
        levels: [
            { level: 1, description: '子弹或拖尾宽度 +10%', value: 0.1 },
            { level: 2, description: '子弹或拖尾宽度 +25%', value: 0.25 },
            { level: 3, description: '子弹或拖尾宽度 +50%', value: 0.5 }
        ]
    },
    {
        id: 'base_pierce', name: '子弹穿透', category: SkillCategory.BASE_STATS, maxLevel: 3,
        levels: [
            { level: 1, description: '子弹额外穿透 1 个敌人', value: 1 },
            { level: 2, description: '子弹额外穿透 2 个敌人', value: 2 },
            { level: 3, description: '子弹额外穿透 3 个敌人', value: 3 }
        ]
    },

    // ================== 元素附魔系 ==================
    {
        id: 'element_ice', name: '冰霜颜料', category: SkillCategory.ELEMENT, maxLevel: 3,
        levels: [
            { level: 1, description: '子弹有 20% 概率冻结敌人 1 秒', value: 0.2 },
            { level: 2, description: '冰冻概率提升至 30%', value: 0.3 },
            { level: 3, description: '冰冻概率提升至 40%，且冻结时间变为 1.5 秒', value: 0.4 }
        ]
    },
    {
        id: 'element_corrosive', name: '腐蚀墨水', category: SkillCategory.ELEMENT, maxLevel: 3,
        levels: [
            { level: 1, description: '子弹命中使敌人受到伤害增加 10%，最多叠加 3 层', value: 0.1 },
            { level: 2, description: '每层伤害增加提升至 15%', value: 0.15 },
            { level: 3, description: '每层伤害增加提升至 20%', value: 0.2 }
        ]
    },
    {
        id: 'element_fire', name: '焦油燃烧', category: SkillCategory.ELEMENT, maxLevel: 3,
        levels: [
            { level: 1, description: '子弹附加燃烧，每秒造成 20% 攻击力的持续伤害，持续 3 秒', value: 0.2 },
            { level: 2, description: '燃烧伤害提升至 35% 攻击力', value: 0.35 },
            { level: 3, description: '燃烧伤害提升至 50% 攻击力，且引燃周围敌人', value: 0.5 }
        ]
    },
    {
        id: 'element_electric', name: '静电导电', category: SkillCategory.ELEMENT, maxLevel: 3,
        levels: [
            { level: 1, description: '子弹命中时弹射 1 个附近敌人，造成 50% 伤害', value: 1 },
            { level: 2, description: '弹射 2 个附近敌人，造成 50% 伤害', value: 2 },
            { level: 3, description: '弹射 3 个附近敌人，造成 75% 伤害', value: 3 }
        ]
    },

    // ================== 换弹触发系 ==================
    {
        id: 'reload_thumbtack', name: '图钉禁锢', category: SkillCategory.RELOAD, maxLevel: 3,
        levels: [
            { level: 1, description: '每次换弹时，将自身周围小范围内的所有敌人钉住 2 秒' },
            { level: 2, description: '范围中等，持续 3 秒' },
            { level: 3, description: '范围大，持续 4 秒' }
        ]
    },
    {
        id: 'reload_pigment_dump', name: '颜料倾倒', category: SkillCategory.RELOAD, maxLevel: 3,
        levels: [
            { level: 1, description: '每次换弹时在脚下留下一摊毒水，持续 5 秒，造成基础伤害' },
            { level: 2, description: '范围扩大，伤害 +50%' },
            { level: 3, description: '毒水内的敌人移速降低 50%' }
        ]
    },
    {
        id: 'reload_compass_dash', name: '圆规冲刺', category: SkillCategory.RELOAD, maxLevel: 3,
        levels: [
            { level: 1, description: '弹匣为 0 换弹时，向移动方向短冲刺，画出半圆减速敌人 30% 并造成伤害' },
            { level: 2, description: '冲刺距离中等，减速 50%' },
            { level: 3, description: '冲刺期间无敌，减速 80%' }
        ]
    },
    {
        id: 'reload_inspiration', name: '灵感爆发', category: SkillCategory.RELOAD, maxLevel: 3,
        levels: [
            { level: 1, description: '换弹后的第一发子弹必定暴击，且伤害 +100%' },
            { level: 2, description: '第一发子弹伤害 +200%' },
            { level: 3, description: '第一发子弹伤害 +300% 且附带穿透' }
        ]
    },

    // ================== 命中/暴击触发系 ==================
    {
        id: 'hit_sketch_clone', name: '素描分身', category: SkillCategory.HIT, maxLevel: 3,
        levels: [
            { level: 1, description: '击中敌人后，15% 概率分裂 2 发额外子弹弹射其他敌人' },
            { level: 2, description: '概率提升至 25%，分裂 2 发' },
            { level: 3, description: '概率提升至 25%，分裂 4 发' }
        ]
    },
    {
        id: 'hit_explosion', name: '色彩爆炸', category: SkillCategory.HIT, maxLevel: 3,
        levels: [
            { level: 1, description: '击中敌人时，10% 概率产生小范围爆炸' },
            { level: 2, description: '概率提升至 20%' },
            { level: 3, description: '概率提升至 30%，且爆炸范围扩大' }
        ]
    },
    {
        id: 'crit_pierce', name: '致命穿透', category: SkillCategory.HIT, maxLevel: 3,
        levels: [
            { level: 1, description: '暴击时 30% 概率穿透当前敌人，穿透伤害不衰减' },
            { level: 2, description: '概率提升至 60%' },
            { level: 3, description: '概率提升至 100%' }
        ]
    },
    {
        id: 'crit_vampire', name: '吸血鬼之触', category: SkillCategory.HIT, maxLevel: 3,
        levels: [
            { level: 1, description: '暴击时 5% 概率恢复 1 点生命值' },
            { level: 2, description: '概率提升至 10%' },
            { level: 3, description: '概率提升至 15%' }
        ]
    },

    // ================== 击杀触发系 ==================
    {
        id: 'kill_bloom', name: '颜料绽放', category: SkillCategory.KILL, maxLevel: 3,
        levels: [
            { level: 1, description: '击杀敌人后尸体炸开，造成相当于其最大生命值 5% 的真实伤害' },
            { level: 2, description: '真实伤害提升至 10%' },
            { level: 3, description: '真实伤害提升至 15%' }
        ]
    },
    {
        id: 'kill_frenzy', name: '墨滴狂热', category: SkillCategory.KILL, maxLevel: 3,
        levels: [
            { level: 1, description: '击杀敌人后，移速和射速临时提升 10%，持续 2 秒（可叠加）' },
            { level: 2, description: '加成提升至 15%' },
            { level: 3, description: '加成提升至 20%，持续时间增至 3 秒' }
        ]
    },
    {
        id: 'kill_magnet', name: '经验磁铁', category: SkillCategory.KILL, maxLevel: 3,
        levels: [
            { level: 1, description: '击杀敌人时，20% 概率直接吸收掉落的经验' },
            { level: 2, description: '概率提升至 40%' },
            { level: 3, description: '概率提升至 60%，且拾取时恢复极少量生命' }
        ]
    },
    {
        id: 'kill_reaper', name: '死神收割', category: SkillCategory.KILL, maxLevel: 3,
        levels: [
            { level: 1, description: '连续击杀 15 个敌人后，下一次攻击必定触发所有“命中触发系”效果' },
            { level: 2, description: '需连杀 10 个' },
            { level: 3, description: '需连杀 5 个' }
        ]
    },

    // ================== 召唤物系 ==================
    {
        id: 'summon_stickman', name: '火柴人助手', category: SkillCategory.SUMMON, maxLevel: 3,
        levels: [
            { level: 1, description: '召唤 1 个简笔画火柴人跟在身后独立开火' },
            { level: 2, description: '召唤 2 个火柴人' },
            { level: 3, description: '召唤 2 个火柴人，且射速翻倍' }
        ]
    },
    {
        id: 'summon_palette', name: '调色盘卫星', category: SkillCategory.SUMMON, maxLevel: 3,
        levels: [
            { level: 1, description: '召唤 2 个发光的色块像卫星一样围绕玩家旋转切割敌人' },
            { level: 2, description: '增加至 3 个色块' },
            { level: 3, description: '增加至 4 个色块，且旋转速度提升' }
        ]
    },
    {
        id: 'summon_scythe', name: '吸血镰刀', category: SkillCategory.SUMMON, maxLevel: 3,
        levels: [
            { level: 1, description: '召唤 1 把镰刀围绕玩家做圆周运动，割到敌人恢复 1 点生命值' },
            { level: 2, description: '收割半径扩大 50%' },
            { level: 3, description: '恢复量提升至 2 点并附带重伤效果' }
        ]
    },
    {
        id: 'summon_drone', name: '无人机（橡皮擦猎手）', category: SkillCategory.SUMMON, maxLevel: 3,
        levels: [
            { level: 1, description: '召唤 1 架小飞船专门消灭“橡皮擦”敌人' },
            { level: 2, description: '召唤 2 架无人机' },
            { level: 3, description: '无人机附带发射激光制导，伤害大幅提升' }
        ]
    },
    {
        id: 'summon_behemoth', name: '护卫巨兽', category: SkillCategory.SUMMON, maxLevel: 3,
        levels: [
            { level: 1, description: '每存活 5 分钟召唤一只“黏土巨兽”抗伤害，拥有基础血量' },
            { level: 2, description: '巨兽血量翻倍' },
            { level: 3, description: '巨兽拥有嘲讽光环' }
        ]
    },

    // ================== 防御/受击触发系 ==================
    {
        id: 'defense_shield', name: '折纸盾牌', category: SkillCategory.DEFENSE, maxLevel: 3,
        levels: [
            { level: 1, description: '定期生成环绕自身的纸盾抵挡一次伤害，60 秒冷却' },
            { level: 2, description: '冷却时间降低至 45 秒' },
            { level: 3, description: '冷却时间降低至 30 秒，且破碎时发射追踪纸屑' }
        ]
    },
    {
        id: 'defense_dummy', name: '墨水替身', category: SkillCategory.DEFENSE, maxLevel: 3,
        levels: [
            { level: 1, description: '受致命伤留下假人嘲讽，自身隐身无敌并加速，60 秒冷却' },
            { level: 2, description: '冷却时间降低至 45 秒' },
            { level: 3, description: '冷却时间降低至 30 秒，且假人爆炸造成巨额伤害' }
        ]
    },
    {
        id: 'defense_desperate_explosion', name: '绝境爆炸', category: SkillCategory.DEFENSE, maxLevel: 3,
        levels: [
            { level: 1, description: '血量低于 20% 且受击时，瞬间触发大范围颜料爆炸，60 秒冷却' },
            { level: 2, description: '冷却时间降低至 45 秒' },
            { level: 3, description: '冷却时间降低至 30 秒，且爆炸后恢复 10% 生命值' }
        ]
    },
    {
        id: 'defense_hedgehog', name: '刺猬装甲', category: SkillCategory.DEFENSE, maxLevel: 3,
        levels: [
            { level: 1, description: '受击时，向四周发射 8 根尖锐的铅笔芯' },
            { level: 2, description: '发射 16 根' },
            { level: 3, description: '发射 24 根且带穿透' }
        ]
    },

    // ================== 走位互动系 ==================
    {
        id: 'move_mirror', name: '镜像位移', category: SkillCategory.MOVEMENT, maxLevel: 3,
        levels: [
            { level: 1, description: '持续同向移动 10 秒触发镜像通道传送并切割敌人' },
            { level: 2, description: '需同向移动 8 秒' },
            { level: 3, description: '需同向移动 5 秒' }
        ]
    },
    {
        id: 'move_skateboard', name: '颜料滑板', category: SkillCategory.MOVEMENT, maxLevel: 3,
        levels: [
            { level: 1, description: '未开火状态下移速逐渐提升最高 150%，开火时转化为伤害倍率' },
            { level: 2, description: '最高提升至 200% 移速' },
            { level: 3, description: '最高提升至 250% 移速，且开火伤害倍率翻倍' }
        ]
    },
    {
        id: 'move_static_charge', name: '静止蓄能', category: SkillCategory.MOVEMENT, maxLevel: 3,
        levels: [
            { level: 1, description: '静止 2 秒后，每秒增加攻击力，最高 50%' },
            { level: 2, description: '需静止 1.5 秒，最高 100%' },
            { level: 3, description: '需静止 1 秒，最高 150%' }
        ]
    },
    {
        id: 'move_parkour', name: '跑酷大师', category: SkillCategory.MOVEMENT, maxLevel: 3,
        levels: [
            { level: 1, description: '移动速度越快闪避率越高，最高 15%' },
            { level: 2, description: '最高 25% 闪避' },
            { level: 3, description: '最高 40% 闪避' }
        ]
    },

    // ================== 特殊文具联动与双生系 ==================
    {
        id: 'gadget_paperclip', name: '磁力曲别针', category: SkillCategory.SYNERGY, maxLevel: 3,
        levels: [
            { level: 1, description: '每 10 秒掉落曲别针，两针之间连起高压电线，伤害敌人后消失' },
            { level: 2, description: '每 8 秒掉落 1 个' },
            { level: 3, description: '每 5 秒掉落 1 个，且电线伤害翻倍' }
        ]
    },
    {
        id: 'synergy_ice_fire', name: '双生·冰火两重天', category: SkillCategory.SYNERGY, maxLevel: 1,
        prerequisites: ['element_ice', 'element_fire'],
        levels: [
            { level: 1, description: '子弹命中冻结且燃烧的敌人触发热胀冷缩，造成最大生命值 15% 真实伤害爆炸' }
        ]
    },
    {
        id: 'synergy_legion', name: '双生·军团降临', category: SkillCategory.SYNERGY, maxLevel: 1,
        prerequisites: ['summon_stickman', 'summon_palette'],
        levels: [
            { level: 1, description: '火柴人获得微型调色盘卫星，且火柴人伤害有概率吸血' }
        ]
    }
];