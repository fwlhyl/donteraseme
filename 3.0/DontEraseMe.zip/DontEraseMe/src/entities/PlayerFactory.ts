import { Entity } from '../core/Entity';
import { Transform } from '../components/Transform';
import { Velocity } from '../components/Velocity';
import { Renderable } from '../components/Renderable';
import { PlayerControl } from '../components/PlayerControl';
import { Trail } from '../components/Trail';
import { Weapon } from '../components/Weapon';
import { Skill } from '../components/Skill';

import { Health } from '../components/Health';
import { Score } from '../components/Score';
import { Skeleton, Bone } from '../components/Skeleton';
import { SpriteAttachments } from '../components/SpriteAttachments';
import { Experience } from '../components/Experience';
import { StoryState } from '../components/StoryState';
import { Quest } from '../components/Quest';
import type { QuestStep } from '../components/Quest';
import { PlayerStats } from '../components/PlayerStats';
import { CHARACTERS } from '../config/EndlessConfig';

export class PlayerFactory {
    public static create(x: number, y: number, characterId?: string, weaponId?: number): Entity {
        const player = new Entity();
        
        console.log('Creating player at', x, y);
        
        // Find selected character or default to the first one
        const charConfig = CHARACTERS.find(c => c.id === characterId) || CHARACTERS[0];
        const initialWeapon = weaponId !== undefined ? weaponId : 0;

        
        player.addComponent(new Transform(x, y));
        player.addComponent(new Velocity());
        
        const renderable = new Renderable('white', 20, 40, 40, 'circle', 10);
        
        // Load custom skin if exists
        const savedSkin = localStorage.getItem('player_custom_skin');
        if (savedSkin) {
            renderable.shape = 'sprite';
            const img = new Image();
            img.src = savedSkin;
            renderable.attachmentBone = 'spine';
            renderable.offsetX = 0;
            renderable.offsetY = 0;
            renderable.attachmentRotationOffset = 0;
            img.onerror = () => {
                renderable.shape = 'circle';
                renderable.image = undefined;
            };
            img.onload = () => {
                if (img.naturalWidth === 0) {
                    renderable.shape = 'circle';
                    renderable.image = undefined;
                }
            };
            renderable.image = img;
        }
        
        player.addComponent(renderable);
        
        const attachments = new SpriteAttachments();
        const partKeys = [
            { key: 'player_part_head', bone: 'spine', w: 28, h: 28, ox: 0, oy: -26, ro: 0, z: 2 },
            { key: 'player_part_body', bone: 'spine', w: 46, h: 46, ox: 0, oy: 0, ro: 0, z: 1 },
            { key: 'player_part_arm_r', bone: 'arm_r', w: 18, h: 18, ox: 10, oy: 0, ro: 0, z: 3 },
            { key: 'player_part_forearm_r', bone: 'forearm_r', w: 16, h: 16, ox: 10, oy: 0, ro: 0, z: 4 }
        ];
        let hasParts = false;
        for (const p of partKeys) {
            const url = localStorage.getItem(p.key);
            if (url) {
                const i = new Image();
                i.src = url;
                attachments.addPart({
                    image: i,
                    bone: p.bone,
                    width: p.w,
                    height: p.h,
                    offsetX: p.ox,
                    offsetY: p.oy,
                    rotationOffset: p.ro,
                    z: p.z
                });
                hasParts = true;
            }
        }
        if (hasParts) {
            player.addComponent(attachments);
        }
        
        // Add PlayerStats based on selection
        const stats = new PlayerStats();
        player.addComponent(stats);

        // Base values from character config
        player.addComponent(new PlayerControl(charConfig.baseSpeed));
        player.addComponent(new Trail('rgba(255, 255, 255, 0.5)', 30, 0.2)); 
        player.addComponent(new Weapon(initialWeapon)); // Start with selected weapon
        player.addComponent(new Skill()); 
        player.addComponent(new Health(charConfig.baseHp, charConfig.baseHp)); 
        player.addComponent(new Score(0)); 
        player.addComponent(new Experience(1, 0, 100)); 
        player.addComponent(new StoryState('Prologue', {}));
        const steps: QuestStep[] = [
            { type: 'announce', text: '序章开始' },
            { type: 'rating', target: 60 },
            { type: 'kills', target: 10 },
            { type: 'announce', text: '进入擦除之夜' }
        ];
        player.addComponent(new Quest(steps, 0, true));
        
        const bones = [
            new Bone('root', 0, 0, 0, 20),
            new Bone('spine', 0, 0, 0, 24, 'root'),
            new Bone('arm_r', 24, 0, 0, 22, 'spine'),
            new Bone('forearm_r', 22, 0, 0, 18, 'arm_r')
        ];
        player.addComponent(new Skeleton(bones, 'root'));
        
        player.tags.add('player');
        
        return player;
    }
}
