import { Component } from '../core/Component';

export class PlayerStats extends Component {
    // 基础属性池 (会受角色初始属性和技能加成影响)
    public maxHp: number = 100;
    public currentHp: number = 100;
    
    // 各种乘区系数 (Multiplier)
    public speedMultiplier: number = 1.0;
    public fireRateMultiplier: number = 1.0;
    public damageMultiplier: number = 1.0;
    public reloadSpeedMultiplier: number = 1.0;
    
    // 暴击与吸血
    public critChance: number = 0.0;
    public critDamage: number = 1.5;
    public lifesteal: number = 0.0;
    
    // 其他属性
    public bulletCountBonus: number = 0; // 额外弹道数
    public pierceBonus: number = 0;      // 额外穿透次数
    public pickupRange: number = 50;     // 经验拾取范围
    
    // 当前拥有的技能与等级字典 (skillId -> level)
    public acquiredSkills: Record<string, number> = {};
    
    // 局内经验与等级
    public level: number = 1;
    public currentXp: number = 0;
    public xpToNextLevel: number = 100;
    
    // 击杀数/金币数
    public kills: number = 0;
    public gold: number = 0;

    constructor() {
        super();
    }

    // 快捷方法：检查是否拥有某个技能，以及获取技能等级
    public getSkillLevel(skillId: string): number {
        return this.acquiredSkills[skillId] || 0;
    }

    public hasSkill(skillId: string): boolean {
        return this.getSkillLevel(skillId) > 0;
    }
}