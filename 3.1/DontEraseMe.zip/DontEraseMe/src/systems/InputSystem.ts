import { System } from '../core/System';
import { Entity } from '../core/Entity';
import { Transform } from '../components/Transform';
import { Velocity } from '../components/Velocity';
import { PlayerControl } from '../components/PlayerControl';
import { InputManager } from '../core/InputManager';
import { PlayerStats } from '../components/PlayerStats';

export class InputSystem extends System {
    constructor(
        private input: InputManager,
        private camera: { x: number, y: number }
    ) {
        super();
    }

    public update(dt: number): void {
        for (const entity of this.entities) {
            if (!entity.hasComponent(PlayerControl)) continue;

            const velocity = entity.getComponent(Velocity)!;
            const control = entity.getComponent(PlayerControl)!;
            const transform = entity.getComponent(Transform)!;
            const stats = entity.getComponent(PlayerStats);

            const calculatedSpeed = stats ? control.speed * stats.speedMultiplier : control.speed;
            
            // 方案一：速度硬上限为 8.0，溢出的速度转化为额外的伤害倍率 (每溢出 1 点速度，增加 10% 伤害)
            let currentSpeed = calculatedSpeed;
            if (stats) {
                // 先重置由速度溢出带来的临时伤害加成
                stats.speedOverflow = Math.max(0, calculatedSpeed - 8.0);
                currentSpeed = Math.min(calculatedSpeed, 8.0);
            }

            // 书法家：攻击时移速大幅降低
            if (stats && stats.hasCalligrapherPassive && entity.attacking) {
                currentSpeed *= 0.1;
            }

            // Reset velocity
            velocity.x = 0;
            velocity.y = 0;

            // Keyboard input
            if (this.input.isKeyDown('w')) velocity.y -= currentSpeed;
            if (this.input.isKeyDown('s')) velocity.y += currentSpeed;
            if (this.input.isKeyDown('a')) velocity.x -= currentSpeed;
            if (this.input.isKeyDown('d')) velocity.x += currentSpeed;
            
            const isMoving = velocity.x !== 0 || velocity.y !== 0;

            // 书法家被动：静止时叠加伤害
            if (stats && stats.hasCalligrapherPassive) {
                if (!isMoving) {
                    stats.calligrapherStackTimer++;
                    if (stats.calligrapherStackTimer >= 15) { // 每0.25秒(15帧)加一层
                        stats.calligrapherDamageStacks = Math.min(stats.maxCalligrapherStacks, stats.calligrapherDamageStacks + 1);
                        stats.calligrapherStackTimer = 0;
                    }
                } else {
                    stats.calligrapherDamageStacks = 0;
                    stats.calligrapherStackTimer = 0;
                }
            }

            const mag = Math.hypot(velocity.x, velocity.y);
            if (mag > 0) {
                velocity.x = (velocity.x / mag) * currentSpeed;
                velocity.y = (velocity.y / mag) * currentSpeed;
            }

            // Update rotation based on mouse
            // Mouse is in screen coordinates, transform is in world coordinates.
            // We need to convert mouse to world coordinates.
            const mouseWorldX = this.input.mouse.x + this.camera.x;
            const mouseWorldY = this.input.mouse.y + this.camera.y;

            const dx = mouseWorldX - transform.x;
            const dy = mouseWorldY - transform.y;
            transform.rotation = Math.atan2(dy, dx);
        }
    }
}
