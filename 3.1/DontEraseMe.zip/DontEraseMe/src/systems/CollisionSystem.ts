import { System } from '../core/System';
import { Entity } from '../core/Entity';
import { Transform } from '../components/Transform';
import { Renderable } from '../components/Renderable';
import { Projectile } from '../components/Projectile';
import { EnemyBehavior } from '../components/EnemyBehavior';
import { Health } from '../components/Health';
import { PlayerControl } from '../components/PlayerControl';
import { ParticleFactory } from '../entities/ParticleFactory';
import { Velocity } from '../components/Velocity'; // Import Velocity
import { Score } from '../components/Score'; // Import Score
import { Experience } from '../components/Experience';
import { Skill } from '../components/Skill';
import { PlayerStats } from '../components/PlayerStats';
import { DamageTextSystem } from './DamageTextSystem';
import { WaterMark } from '../components/WaterMark';
import { InkCloud } from '../components/InkCloud';
import { ExperienceOrb } from '../components/ExperienceOrb';
// removed Physics import
export class CollisionSystem extends System {
    constructor(
        private addEntityCallback?: (entity: Entity) => void,
        private trailCtx?: CanvasRenderingContext2D // Add trailCtx
    ) {
        super();
    }
    private frame: number = 0;
    private enemyContactCooldown: Map<string, number> = new Map();

    // Helper: Draw Blood / Splash
    private drawSplash(ctx: CanvasRenderingContext2D, x: number, y: number, color: string, radius: number) {
        // Only draw splash for explosions (Rocket or Skill) or if explicitly called for death?
        // User Requirement 1: "Only explosion effect (Weapon 4 and Explosion Skill) leaves traces on enemies."
        // Wait, "Weapon damage causes enemies to leave traces" -> User says "Actually should be ONLY explosion".
        // So regular bullets should NOT cause `drawSplash` on death?
        // Or maybe regular death doesn't leave a huge splash, just particles?
        // Re-reading: "Weapon damage causes enemies to leave traces, actually should only be explosion effect (Weapon 4 and Skill) that causes enemy to leave traces."
        // This implies:
        // 1. Regular bullet hit -> No trace (already true, drawSplash is on death).
        // 2. Regular bullet kill -> User says "Only explosion effect... causes enemy to leave traces".
        // So if I kill with pistol, NO splash on canvas?
        // If so, I should wrap `drawSplash` call in a check for weapon type.
        
        // But the code below calls `drawSplash` inside `if (eHealth.current <= 0)`.
        // I need to check `pData.type` there.
        
        const drops = 5 + Math.random() * 5;
        ctx.fillStyle = color;
        ctx.globalAlpha = 0.6;
        
        for(let i=0; i<drops; i++) {
            const angle = Math.random() * Math.PI * 2;
            const dist = Math.random() * radius;
            const r = 2 + Math.random() * (radius / 2);
            
            ctx.beginPath();
            ctx.arc(x + Math.cos(angle)*dist, y + Math.sin(angle)*dist, r, 0, Math.PI*2);
            ctx.fill();
        }
        ctx.globalAlpha = 1.0;
    }

    private handleEnemyDeath(enemy: Entity, player: Entity | null, x: number, y: number, color: string): void {
        if (!enemy.active) return;
        enemy.active = false;

        // 1. Score and XP
        if (player && player.active) {
            const score = player.getComponent(Score);
            const stats = player.getComponent(PlayerStats);
            
            if (score) {
                score.value += 10; // Default points
                if (enemy.getComponent(EnemyBehavior)?.type === 'eraser') {
                    score.value += 40; // Bonus for eraser
                }
                
                const t = enemy.getComponent(EnemyBehavior)?.type || 'chaser';
                let baseGold = 1; // 杂兵
                if (t === 'boss') baseGold = 100; // Boss
                else if (t !== 'chaser') baseGold = 5; // 精英怪
                
                // 应用收藏家被动：存活时间增加金币获取
                let goldMultiplier = 1;
                if (stats) {
                    if (stats.characterId === 'collector') {
                        goldMultiplier += stats.survivalTime * 0.005; 
                    }
                    const finalGold = Math.ceil(baseGold * goldMultiplier);
                    score.coins += finalGold;
                    stats.gold += finalGold;

                    // 水彩插画师被动：击杀留水痕
                    if (stats.hasWatercolorPassive && this.addEntityCallback) {
                        const mark = new Entity();
                        mark.addComponent(new Transform(x, y));
                        mark.addComponent(new Renderable('rgba(0, 150, 255, 0.4)', 60, 0, 0, 'circle'));
                        // Need to import WaterMark
                        // wait, I will import it at the top of the file
                        mark.addComponent(new WaterMark(0.5, 60, 300, 'rgba(0, 150, 255, 0.4)'));
                        this.addEntityCallback(mark);
                    }
                } else {
                    score.coins += baseGold;
                }
            }
            const exp = player.getComponent(Experience);
            if (exp && this.addEntityCallback) {
                // Drop experience orb instead of direct gain
                const orb = new Entity();
                orb.tags.add('xp_orb');
                orb.addComponent(new Transform(x, y));
                orb.addComponent(new ExperienceOrb(20));
                orb.addComponent(new Renderable('#00ff00', 6, 0, 0, 'diamond'));
                this.addEntityCallback(orb);
            }
        }

        // 2. Particles
        if (this.addEntityCallback) {
            const particles = ParticleFactory.createExplosion(x, y, color, 10);
            for (const p of particles) {
                this.addEntityCallback(p);
            }
        }
    }

    private handlePlayerHit(player: Entity, pTransform: Transform) {
        const pStats = player.getComponent(PlayerStats);
        if (pStats && pStats.hasInkPassive && this.addEntityCallback) {
            // 水墨画家：受击喷射致盲水墨团，持续3秒，半径300
            const ink = new Entity();
            ink.addComponent(new Transform(pTransform.x, pTransform.y));
            ink.addComponent(new Renderable('rgba(0, 0, 0, 0.8)', 300, 0, 0, 'circle'));
            ink.addComponent(new InkCloud(300, 180, 'rgba(0, 0, 0, 0.8)'));
            this.addEntityCallback(ink);
            window.dispatchEvent(new CustomEvent('announce', { detail: { text: `墨染致盲！` } }));
        }
    }

    public update(dt: number): void {
        this.frame += 1;
        const projectiles: Entity[] = [];
        const enemies: Entity[] = [];
        const watermarks: Entity[] = [];
        const inkClouds: Entity[] = [];
        const xpOrbs: Entity[] = [];
        let player: Entity | null = null;

        // 1. Filter entities into categories
        let canvasEye: Entity | null = null;
        for (const entity of this.entities) {
            if (entity.getComponent(Projectile)) {
                projectiles.push(entity);
            } else if (entity.getComponent(EnemyBehavior)) {
                enemies.push(entity);
            } else if (entity.getComponent(WaterMark)) {
                watermarks.push(entity);
            } else if (entity.getComponent(InkCloud)) {
                inkClouds.push(entity);
            } else if (entity.tags.has('xp_orb')) {
                xpOrbs.push(entity);
            } else if (entity.tags.has('player')) {
                player = entity;
                const pHealth = player.getComponent(Health);
                if (pHealth && pHealth.invincibleFrames > 0) {
                    pHealth.invincibleFrames -= 1;
                }
            } else if (entity.tags.has('canvas_eye')) {
                canvasEye = entity;
            }
        }

        // 2. Projectile vs Enemy
        for (const projectile of projectiles) {
            const pTransform = projectile.getComponent(Transform)!;
            const pRender = projectile.getComponent(Renderable)!;
            const pData = projectile.getComponent(Projectile)!;
            const pVel = projectile.getComponent(Velocity);

            if (!pTransform || !pRender) continue;

            // Team check: only player's子弹参与“子弹 vs 敌人”判定，避免敌人被友军或自身子弹误伤
            if (player && pData.ownerId !== player.id) {
                continue;
            }

            for (const enemy of enemies) {
                if (!enemy.active) continue;

                const eTransform = enemy.getComponent(Transform)!;
                const eRender = enemy.getComponent(Renderable)!;
                const eHealth = enemy.getComponent(Health)!;
                const eBeh = enemy.getComponent(EnemyBehavior)!;

                if (!eTransform || !eRender || !eHealth) continue;

                // Check collision based on projectile shape
                let hit = false;

                // Gravity Gun: Check if enemy is in range of black hole
                if (pData.type === 'gravity') {
                    // Check if it's a deployed black hole (stationary)
                    // We can check if it has 'blackhole' tag or if life is set to 180 (initial life of deployed BH)
                    // Or just check velocity?
                    // In CollisionSystem we iterate projectiles.
                    // The deployed BH is a projectile.
                    
                    // Actually, let's check distance for pull effect regardless of hit
                    const dx = pTransform.x - eTransform.x;
                    const dy = pTransform.y - eTransform.y;
                    const dist = Math.sqrt(dx*dx + dy*dy);
                    const gravityRadius = 250; // Black hole range 增加到了250 (之前是150)
                    
                    if (dist < gravityRadius) {
                        // Suck enemy in!
                        // Simplest Fix: Modify Transform directly for "Suck" effect, 
                        // as it overrides movement logic.
                        const pullFactor = 3.0; // 稍微增加一点吸力强度以匹配更大的范围
                        eTransform.x += (dx / dist) * pullFactor;
                        eTransform.y += (dy / dist) * pullFactor;
                        
                        // Gravity also deals continuous damage near center
                        if (dist < 40) { // 中心伤害范围也相应略微扩大
                            if (this.frame % 10 === 0) { // Deal damage every 10 frames to avoid clutter
                                eHealth.current -= 5; 
                                DamageTextSystem.addDamageText(eTransform.x, eTransform.y - 15, 5, '#ffffff', false);
                            }
                            // Don't set hit = true here, or it will destroy the black hole (if not handled)
                            // We want continuous damage.
                            
                            // Check death here for gravity kill
                            if (eHealth.current <= 0) {
                                hit = true; // Trigger death logic
                            }
                        }
                    }
                } 
                else if (pRender.shape === 'line') {
                    // raycast logic for sniper beam
                    // In RenderSystem, beam end point is stored in pRender.width and pRender.height
                    hit = this.lineCircleCollision(
                        pTransform.x, pTransform.y, 
                        pRender.width, pRender.height, 
                        eTransform.x, eTransform.y, 
                        eRender.radius || 15 
                    );
                }  
                // Normal Collision Logic
                else {
                    const dx = pTransform.x - eTransform.x;
                    const dy = pTransform.y - eTransform.y;
                    const dist = Math.sqrt(dx*dx + dy*dy);
                    const minDist = (pRender.radius || 5) + (eRender.radius || 15);
                    
                    if (dist < minDist) {
                        hit = true;
                    }
                }

                if (hit) {
                    if (eBeh && eBeh.type === 'shield' && eBeh.shield > 0 && pData.type !== 'gravity') {
                        let vx = 0, vy = 0;
                        if (pRender.shape === 'line') {
                            vx = pRender.width - pTransform.x;
                            vy = pRender.height - pTransform.y;
                            const d = Math.hypot(vx, vy) || 1;
                            vx /= d; vy /= d;
                        } else if (pVel) {
                            const d = Math.hypot(pVel.x, pVel.y) || 1;
                            vx = pVel.x / d; vy = pVel.y / d;
                        }
                        const fx = Math.cos(eTransform.rotation);
                        const fy = Math.sin(eTransform.rotation);
                        const dot = vx * fx + vy * fy;
                        if (dot > Math.cos(Math.PI / 3)) {
                            eBeh.shield -= pData.damage;
                            DamageTextSystem.addDamageText(eTransform.x, eTransform.y - 15, pData.damage, pData.isCrit ? '#ff4444' : '#66ccff', pData.isCrit);
                            if (this.trailCtx) {
                                this.trailCtx.save();
                                this.trailCtx.globalAlpha = 0.6;
                                this.trailCtx.strokeStyle = '#66ccff';
                                this.trailCtx.beginPath();
                                this.trailCtx.arc(eTransform.x, eTransform.y, (eRender.radius || 20) + 6, eTransform.rotation - Math.PI/3, eTransform.rotation + Math.PI/3);
                                this.trailCtx.stroke();
                                this.trailCtx.restore();
                            }
                            if (pRender.shape !== 'line') {
                                if (pData.pierceCount && pData.pierceCount > 0) {
                                    pData.pierceCount -= 1;
                                } else {
                                    projectile.active = false;
                                }
                            }
                            continue;
                        }
                    }
                    // Special logic for Rocket and Mine (AOE)
                    if (pData.type === 'rocket' || pData.type === 'mine') {
                        // Explosion radius
                        const explosionRadius = Math.floor(100 * (pData.explosionRadiusScale || 1));
                        const explosionDamage = (pData.type === 'rocket' ? 50 : 40) + (pData.damage || 0);
                        
                        // Find all enemies in range
                        for (const otherEnemy of enemies) {
                            if (!otherEnemy.active) continue;
                            const t = otherEnemy.getComponent(Transform)!;
                            const h = otherEnemy.getComponent(Health)!;
                            
                            const ex = t.x - eTransform.x;
                            const ey = t.y - eTransform.y;
                            const edist = Math.sqrt(ex*ex + ey*ey);
                            
                            if (edist <= explosionRadius) {
                                h.current -= explosionDamage;
                                DamageTextSystem.addDamageText(t.x, t.y - 15, explosionDamage, pData.isCrit ? '#ff4444' : '#ffffff', pData.isCrit);
                                // Visuals handled below if dead
                                if (h.current <= 0) {
                                    if (otherEnemy.active) { // Check again to avoid double kill logic
                                        this.handleEnemyDeath(otherEnemy, player, t.x, t.y, otherEnemy.getComponent(Renderable)!.color);
                                        if (this.trailCtx) {
                                            this.drawSplash(this.trailCtx, t.x, t.y, otherEnemy.getComponent(Renderable)!.color, otherEnemy.getComponent(Renderable)!.radius * 2);
                                        }
                                    }
                                }
                            }
                        }
                        
                        // Create big explosion effect
                        if (this.addEntityCallback) {
                            const particles = ParticleFactory.createExplosion(eTransform.x, eTransform.y, pRender.color, 20);
                            for (const p of particles) this.addEntityCallback(p);
                            
                            // Mine leaves a puddle
                            if (pData.type === 'mine') {
                                const puddle = new Entity();
                                puddle.addComponent(new Transform(eTransform.x, eTransform.y));
                                puddle.addComponent(new WaterMark(0.5, explosionRadius, 300, 'rgba(34, 255, 34, 0.4)')); // Green swamp
                                this.addEntityCallback(puddle);
                            }
                        }
                        
                        // Rocket Splash on Trail
                        if (this.trailCtx) {
                             // Add extra splash for rocket
                             // User: "Rocket didn't leave explosion splash on enemy".
                             // This block runs when Rocket hits (AOE).
                             // We are looping through enemies.
                             // But this block is OUTSIDE the enemy loop. It uses `eTransform` which is the PRIMARY target.
                             // We want to splash on ALL enemies hit? Or just the center?
                             // "Rocket didn't make enemy leave splash".
                             // The splash should be at the explosion center.
                             // And maybe splashes for all victims?
                              
                             // Let's draw a BIG splash at the center of explosion.
                             this.drawSplash(this.trailCtx, eTransform.x, eTransform.y, pRender.color, 60);
                        }

                        projectile.active = false; // Rocket/Mine destroyed on impact
                        break; // Stop checking other enemies for this rocket/mine
                    }

                    // Apply damage (for non-AOE or direct hit)
                    eHealth.current -= pData.damage;
                    DamageTextSystem.addDamageText(eTransform.x, eTransform.y - 15, pData.damage, pData.isCrit ? '#ff4444' : '#ffffff', pData.isCrit);

                    // 记录已经命中过的敌人，防止穿透时重复计算
                    if (!pData.hitEnemies) {
                        pData.hitEnemies = new Set<string>();
                    }
                    if (pData.hitEnemies.has(enemy.id)) {
                        continue;
                    }
                    pData.hitEnemies.add(enemy.id);

                    // 书法家被动：每穿透一个敌人，子弹伤害增加50%
                    if (pData.calligrapherBonus) {
                        pData.damage *= 1.5;
                    }
                    
                    if (pData.type === 'chain') {
                        const chainRadius = 220;
                        let remaining = pData.pierceCount || 0;
                        const candidates: { enemy: Entity, dist: number }[] = [];
                        for (const otherEnemy of enemies) {
                            if (!otherEnemy.active || otherEnemy === enemy) continue;
                            const t = otherEnemy.getComponent(Transform)!;
                            const dxx = t.x - eTransform.x;
                            const dyy = t.y - eTransform.y;
                            const dd = Math.sqrt(dxx*dxx + dyy*dyy);
                            if (dd <= chainRadius) {
                                candidates.push({ enemy: otherEnemy, dist: dd });
                            }
                        }
                        candidates.sort((a, b) => a.dist - b.dist);
                        for (let i = 0; i < Math.min(remaining, candidates.length); i++) {
                            const target = candidates[i].enemy;
                            const th = target.getComponent(Health)!;
                            const tt = target.getComponent(Transform)!;
                            const tr = target.getComponent(Renderable)!;
                            const chainDamage = Math.floor(pData.damage * 0.8);
                            th.current -= chainDamage;
                            DamageTextSystem.addDamageText(tt.x, tt.y - 15, chainDamage, pData.isCrit ? '#ff4444' : '#ffffff', pData.isCrit);
                            if (this.trailCtx) {
                                this.trailCtx.save();
                                this.trailCtx.strokeStyle = pRender.color;
                                this.trailCtx.globalAlpha = 0.7;
                                this.trailCtx.lineWidth = 2;
                                this.trailCtx.beginPath();
                                this.trailCtx.moveTo(eTransform.x, eTransform.y);
                                this.trailCtx.lineTo(tt.x, tt.y);
                                this.trailCtx.stroke();
                                this.trailCtx.restore();
                            }
                            if (th.current <= 0) {
                                this.handleEnemyDeath(target, player, tt.x, tt.y, tr.color);
                            }
                        }
                        projectile.active = false;
                    }
                    
                    // Shrink enemy if it's a chaser
                    if (enemy.getComponent(EnemyBehavior)?.type === 'chaser') {
                         if (eRender.shape === 'circle') {
                             eRender.radius = Math.max(5, eRender.radius - (pData.damage / 5));
                         }
                    }
                    
                    // Remove projectile unless piercing or special
                    if (pData.type !== 'sniper' && pData.type !== 'gravity' && pData.type !== 'flamethrower' && pData.type !== 'compass') {
                        if (pData.pierceCount && pData.pierceCount > 0) {
                            pData.pierceCount -= 1;
                        } else {
                            projectile.active = false;
                        }
                    }

                    // Check enemy death
                    if (eHealth.current <= 0) {
                        this.handleEnemyDeath(enemy, player, eTransform.x, eTransform.y, eRender.color);

                        // Splash effect on death
                        if (this.trailCtx) {
                            // Only Gravity(Blackhole?) causes splash on death here
                            if (pData.type === 'gravity') {
                                // Draw Enemy Splash
                                this.drawSplash(this.trailCtx, eTransform.x, eTransform.y, eRender.color, eRender.radius * 2);
                            }
                        }
                    }
                    
                    // If projectile is not piercing, break loop (only hit one enemy)
                    if (pData.type !== 'sniper' && pData.type !== 'gravity' && pData.type !== 'flamethrower' && pData.type !== 'compass') {
                        if (!(pData.pierceCount && pData.pierceCount > 0)) {
                            break;
                        }
                    }
                }
            }
        }

        // 2.5 Watermark vs Enemy
        for (const watermark of watermarks) {
            if (!watermark.active) continue;
            const wData = watermark.getComponent(WaterMark)!;
            const wTransform = watermark.getComponent(Transform)!;

            wData.durationFrames -= 1;
            if (wData.durationFrames <= 0) {
                watermark.active = false;
                continue;
            }

            for (const enemy of enemies) {
                if (!enemy.active) continue;
                const eTransform = enemy.getComponent(Transform)!;
                const eRender = enemy.getComponent(Renderable)!;
                const eHealth = enemy.getComponent(Health)!;
                const eBeh = enemy.getComponent(EnemyBehavior)!;

                const dx = wTransform.x - eTransform.x;
                const dy = wTransform.y - eTransform.y;
                const dist = Math.sqrt(dx * dx + dy * dy);
                const minDist = wData.radius + (eRender.radius || 15);

                if (dist < minDist) {
                    if (eBeh.type === 'eraser') {
                        // 橡皮擦可以擦掉接触部分的痕迹
                        // 避免每帧都添加过多的重叠圆，检查距离上一个记录点的距离
                        const eraseRadius = (eRender.radius || 15) + 5; // 稍微扩大一点擦除范围
                        let shouldAdd = true;
                        if (wData.erasedParts.length > 0) {
                            const last = wData.erasedParts[wData.erasedParts.length - 1];
                            const lx = last.x - eTransform.x;
                            const ly = last.y - eTransform.y;
                            if (lx * lx + ly * ly < eraseRadius * eraseRadius * 0.25) {
                                shouldAdd = false; // 距离太近，不重复添加
                            }
                        }
                        if (shouldAdd) {
                            wData.erasedParts.push({ x: eTransform.x, y: eTransform.y, radius: eraseRadius });
                        }
                        
                        // 如果被擦除的面积太大，可以直接销毁
                        if (wData.erasedParts.length > 30) {
                            watermark.active = false;
                            break;
                        }
                    } else {
                        // 普通敌人造成持续伤害 (每帧)
                        // 检查敌人是否在擦除区域内
                        let inErasedArea = false;
                        for (const part of wData.erasedParts) {
                            const px = part.x - eTransform.x;
                            const py = part.y - eTransform.y;
                            // 如果敌人的中心点在擦除区域内，就不受伤害
                            if (Math.sqrt(px * px + py * py) < part.radius) {
                                inErasedArea = true;
                                break;
                            }
                        }
                        
                        if (!inErasedArea) {
                            eHealth.current -= wData.damagePerFrame;
                            // 为了避免满屏伤害数字，可以降低伤害数字的频率，或者不显示持续伤害的数字
                            // 如果需要显示，可以用帧数取模
                            if (this.frame % 30 === 0) {
                                DamageTextSystem.addDamageText(eTransform.x, eTransform.y - 15, wData.damagePerFrame * 30, '#ffffff', false);
                            }
                            
                            if (eHealth.current <= 0) {
                                this.handleEnemyDeath(enemy, player, eTransform.x, eTransform.y, eRender.color);
                            }
                        }
                    }
                }
            }
        }

        // 2.6 InkCloud vs Enemy
        for (const ink of inkClouds) {
            if (!ink.active) continue;
            const inkData = ink.getComponent(InkCloud)!;
            const inkTransform = ink.getComponent(Transform)!;
            const inkRender = ink.getComponent(Renderable)!;

            inkData.durationFrames -= 1;
            if (inkData.durationFrames <= 0) {
                ink.active = false;
                continue;
            }

            // Fade out effect
            if (inkRender && inkData.durationFrames < 60) {
                const alpha = (inkData.durationFrames / 60) * 0.8;
                inkRender.color = `rgba(0, 0, 0, ${alpha})`;
            }

            for (const enemy of enemies) {
                if (!enemy.active) continue;
                const eTransform = enemy.getComponent(Transform)!;
                const eRender = enemy.getComponent(Renderable)!;
                const eBeh = enemy.getComponent(EnemyBehavior)!;

                const dx = inkTransform.x - eTransform.x;
                const dy = inkTransform.y - eTransform.y;
                const dist = Math.sqrt(dx * dx + dy * dy);
                const minDist = inkData.radius + (eRender.radius || 15);

                if (dist < minDist) {
                    // Enemy is inside ink cloud -> blind them
                    eBeh.blindFrames = 2; // Keep blinding them as long as they are inside, plus 1 extra frame
                }
            }
        }

        // 3. Enemy vs Canvas Eye
        for (const enemy of enemies) {
            if (!enemy.active) continue;
            const eTransform = enemy.getComponent(Transform)!;
            const eRender = enemy.getComponent(Renderable)!;
            if (canvasEye && canvasEye.active) {
                const cTransform = canvasEye.getComponent(Transform);
                const cRender = canvasEye.getComponent(Renderable);
                const cHealth = canvasEye.getComponent(Health);
                if (cTransform && cRender && cHealth) {
                    const dx = eTransform.x - cTransform.x;
                    const dy = eTransform.y - cTransform.y;
                    const dist = Math.sqrt(dx*dx + dy*dy);
                    const minDist = (eRender.radius || 15) + (cRender.radius || 40);
                    if (dist < minDist) {
                        if (this.frame % 30 === 0) { 
                            cHealth.current -= 5;
                            DamageTextSystem.addDamageText(cTransform.x, cTransform.y - 15, 5, '#ff0000', false);
                            const nx = dx / dist;
                            const ny = dy / dist;
                            eTransform.x += nx * 10;
                            eTransform.y += ny * 10;
                            cRender.color = 'rgba(255, 100, 100, 0.8)';
                            setTimeout(() => {
                                if (canvasEye && canvasEye.active && cRender) cRender.color = 'rgba(255, 255, 255, 0.8)';
                            }, 100);
                            if (cHealth.current <= 0) {
                                canvasEye.active = false;
                                window.dispatchEvent(new CustomEvent('announce', { detail: { text: '画眼被摧毁！防守失败。' } }));
                                const score = player ? (player.getComponent(Score)?.value || 0) : 0;
                                setTimeout(() => {
                                    window.dispatchEvent(new CustomEvent('game-over', { detail: { score } }));
                                }, 2000);
                            }
                        }
                    }
                }
            }
        }

        // 4. Enemy vs Player
        if (player && player.active) {
            const pTransform = player.getComponent(Transform)!;
            const pRender = player.getComponent(Renderable)!;
            const pSkill = player.getComponent(Skill);
            const pHealth = player.getComponent(Health);

            for (const enemy of enemies) {
                if (!enemy.active) continue;

                const eTransform = enemy.getComponent(Transform)!;
                const eRender = enemy.getComponent(Renderable)!;

                const dx = pTransform.x - eTransform.x;
                const dy = pTransform.y - eTransform.y;
                const dist = Math.sqrt(dx*dx + dy*dy);
                const minDist = (pRender.radius || 20) + (eRender.radius || 15);

                if (dist < minDist) {
                    if (pSkill && pSkill.eraserShieldFrames > 0) {
                        if (dist > 0) {
                            const nx = (pTransform.x - eTransform.x) / dist;
                            const ny = (pTransform.y - eTransform.y) / dist;
                            const kb = 14;
                            eTransform.x -= nx * kb;
                            eTransform.y -= ny * kb;
                        }
                        continue;
                    }
                    if (pHealth && pHealth.invincibleFrames > 0) {
                        continue;
                    }
                    const nextAllowed = this.enemyContactCooldown.get(enemy.id) || 0;
                    if (this.frame < nextAllowed) {
                        continue;
                    }
                    this.enemyContactCooldown.set(enemy.id, this.frame + 30);
                    
                    const pStats = player.getComponent(PlayerStats);
                    if (pStats && Date.now() < (pStats.invincibleUntil || 0)) {
                        continue;
                    }
                    if (pStats && Math.random() < pStats.dodgeChance) {
                        DamageTextSystem.addDamageText(pTransform.x, pTransform.y - 20, 0, '#88ccff', true, "闪避!");
                        continue;
                    }

                    if (pHealth) {
                        const pStats = player.getComponent(PlayerStats);
                        if (pStats && pStats.hasClassicalShield) {
                            pStats.hasClassicalShield = false;
                            pStats.shieldCooldownFrames = pStats.maxShieldCooldownFrames;
                            DamageTextSystem.addDamageText(pTransform.x, pTransform.y - 20, 0, '#00ffff', true, "免疫!");
                            window.dispatchEvent(new CustomEvent('announce', { detail: { text: `厚涂护盾破裂！` } }));
                            pHealth.invincibleFrames = 60; // Give some i-frames anyway to prevent instant multi-hit
                            this.handlePlayerHit(player, pTransform);
                        } else {
                            pHealth.current -= 50;
                            DamageTextSystem.addDamageText(pTransform.x, pTransform.y - 15, 50, '#ff0000', false);
                            pHealth.invincibleFrames = 60; // 1 second of i-frames
                            this.handlePlayerHit(player, pTransform);
                            // Knockback
                            if (dist > 0) {
                                const nx = (pTransform.x - eTransform.x) / dist;
                                const ny = (pTransform.y - eTransform.y) / dist;
                                const kb = 22;
                                pTransform.x += nx * kb;
                                pTransform.y += ny * kb;
                            }
                            // Screen shake
                            const isBoss = enemy.getComponent(EnemyBehavior)?.type === 'boss';
                            window.dispatchEvent(new CustomEvent('shake', { detail: { mag: isBoss ? 18 : 12, frames: isBoss ? 12 : 10 } }));
                            if (pHealth.current <= 0) {
                                console.log('GAME OVER! Player died.');
                                player.active = false;
                                const score = player.getComponent(Score)?.value || 0;
                                window.dispatchEvent(new CustomEvent('game-over', { detail: { score } }));
                            }
                        }
                    }
                }
            }

            for (const projectile of projectiles) {
                const pData2 = projectile.getComponent(Projectile)!;
                if (!pData2) continue;
                if (pData2.ownerId === player.id) continue;
                const t2 = projectile.getComponent(Transform)!;
                const r2 = projectile.getComponent(Renderable)!;
                if (!t2 || !r2) continue;
                const dx = t2.x - pTransform.x;
                const dy = t2.y - pTransform.y;
                const dist = Math.sqrt(dx*dx + dy*dy);
                const minDist = (r2.radius || 5) + (pRender.radius || 20);
                if (dist < minDist) {
                    if (pSkill && pSkill.eraserShieldFrames > 0) {
                        projectile.active = false;
                        continue;
                    }
                    if (pHealth && pHealth.invincibleFrames > 0) {
                        continue;
                    }
                    
                    const pStats = player.getComponent(PlayerStats);
                    if (pStats && Date.now() < (pStats.invincibleUntil || 0)) {
                        continue;
                    }
                    if (pStats && Math.random() < pStats.dodgeChance) {
                        DamageTextSystem.addDamageText(pTransform.x, pTransform.y - 20, 0, '#88ccff', true, "闪避!");
                        projectile.active = false;
                        continue;
                    }

                    if (pHealth) {
                        if (pStats && pStats.hasClassicalShield) {
                            pStats.hasClassicalShield = false;
                            pStats.shieldCooldownFrames = pStats.maxShieldCooldownFrames;
                            DamageTextSystem.addDamageText(pTransform.x, pTransform.y - 20, 0, '#00ffff', true, "免疫!");
                            window.dispatchEvent(new CustomEvent('announce', { detail: { text: `厚涂护盾破裂！` } }));
                            pHealth.invincibleFrames = 60; // i-frames
                            this.handlePlayerHit(player, pTransform);
                        } else {
                            pHealth.current -= 50;
                            DamageTextSystem.addDamageText(pTransform.x, pTransform.y - 15, 50, '#ff0000', false);
                            pHealth.invincibleFrames = 60; // 1 second of i-frames
                            this.handlePlayerHit(player, pTransform);
                            // Knockback from projectile
                            if (dist > 0) {
                                const nx = (pTransform.x - t2.x) / dist;
                                const ny = (pTransform.y - t2.y) / dist;
                                const kb = 18;
                                pTransform.x += nx * kb;
                                pTransform.y += ny * kb;
                            }
                            const ownerIsBoss = Array.from(this.entities).some(e => e.id === pData2.ownerId && e.getComponent(EnemyBehavior)?.type === 'boss');
                            window.dispatchEvent(new CustomEvent('shake', { detail: { mag: ownerIsBoss ? 18 : 10, frames: ownerIsBoss ? 12 : 8 } }));
                            if (pHealth.current <= 0) {
                                player.active = false;
                                const score = player.getComponent(Score)?.value || 0;
                                window.dispatchEvent(new CustomEvent('game-over', { detail: { score } }));
                            }
                        }
                    }
                    projectile.active = false;
                }
            }
        }
        
        // 3. Enemy vs Enemy separation to avoid complete overlap
        if (enemies.length > 1) {
            for (let i = 0; i < enemies.length; i++) {
                const e1 = enemies[i];
                if (!e1.active) continue;
                const t1 = e1.getComponent(Transform);
                const r1 = e1.getComponent(Renderable);
                if (!t1 || !r1) continue;
                for (let j = i + 1; j < enemies.length; j++) {
                    const e2 = enemies[j];
                    if (!e2.active) continue;
                    const t2 = e2.getComponent(Transform);
                    const r2 = e2.getComponent(Renderable);
                    if (!t2 || !r2) continue;
                    const dx = t2.x - t1.x;
                    const dy = t2.y - t1.y;
                    let dist = Math.hypot(dx, dy);
                    const minDist = (r1.radius || 15) + (r2.radius || 15);
                    if (dist === 0) {
                        const angle = Math.random() * Math.PI * 2;
                        const push = minDist * 0.5;
                        t1.x -= Math.cos(angle) * push;
                        t1.y -= Math.sin(angle) * push;
                        t2.x += Math.cos(angle) * push;
                        t2.y += Math.sin(angle) * push;
                        continue;
                    }
                    if (dist < minDist) {
                        const overlap = minDist - dist;
                        const nx = dx / dist;
                        const ny = dy / dist;
                        const push = overlap * 0.5;
                        t1.x -= nx * push;
                        t1.y -= ny * push;
                        t2.x += nx * push;
                        t2.y += ny * push;
                    }
                }
            }
        }

        // 4. Player vs XP Orb
        if (player && player.active) {
            const pTransform = player.getComponent(Transform);
            const pRender = player.getComponent(Renderable);
            const pStats = player.getComponent(PlayerStats);
            if (pTransform && pRender) {
                const baseMagnetRange = pStats ? pStats.pickupRange : 30; // 初始磁吸范围较小
                const magnetRadius = (pRender.radius || 20) + baseMagnetRange;
                for (const orb of xpOrbs) {
                    if (!orb.active) continue;
                    const oTransform = orb.getComponent(Transform);
                    const oData = orb.getComponent(ExperienceOrb);
                    if (!oTransform || !oData) continue;
                    
                    const dx = pTransform.x - oTransform.x;
                    const dy = pTransform.y - oTransform.y;
                    const dist = Math.hypot(dx, dy);
                    
                    // Simple magnet effect
                    if (dist < magnetRadius) {
                        const speed = 10;
                        oTransform.x += (dx / dist) * speed;
                        oTransform.y += (dy / dist) * speed;
                    }
                    
                    // Actual pickup logic (touching the player)
                    if (dist < (pRender.radius || 20) + 10) {
                        orb.active = false;
                        const exp = player.getComponent(Experience);
                        if (exp) {
                            exp.xp += oData.amount;
                        }
                    }
                }
            }
        }
    }

    // Helper: Line Segment vs Circle collision
    private lineCircleCollision(x1: number, y1: number, x2: number, y2: number, cx: number, cy: number, r: number): boolean {
        // Vector from start to end
        const dx = x2 - x1;
        const dy = y2 - y1;
        
        // Vector from start to circle center
        const fx = cx - x1;
        const fy = cy - y1;
        
        const len2 = dx*dx + dy*dy;
        // Dot product to find projection of center onto line
        const dot = fx*dx + fy*dy;
        
        // Find closest point on line segment
        let t = dot / len2;
        
        // Clamp t to segment [0, 1]
        if (t < 0) t = 0;
        if (t > 1) t = 1;
        
        // Closest point coordinates
        const closestX = x1 + t * dx;
        const closestY = y1 + t * dy;
        
        // Distance from closest point to circle center
        const distX = closestX - cx;
        const distY = closestY - cy;
        const dist2 = distX*distX + distY*distY;
        
        return dist2 <= r*r;
    }
}
