import { System } from '../core/System';
import { Transform } from '../components/Transform';
import { Velocity } from '../components/Velocity';
import { Projectile } from '../components/Projectile';
import { Renderable } from '../components/Renderable';
import { Skeleton } from '../components/Skeleton';
import { EnemyBehavior } from '../components/EnemyBehavior';

import { ParticleFactory } from '../entities/ParticleFactory';
import { Entity } from '../core/Entity';

export class MovementSystem extends System {
    constructor(
        private worldWidth: number, 
        private worldHeight: number,
        private addEntityCallback?: (entity: Entity) => void,
        private trailCtx?: CanvasRenderingContext2D
    ) {
        super();
    }

    public update(dt: number): void {
        const entitiesToRemove: Entity[] = [];
        const newEntities: Entity[] = [];

        for (const entity of this.entities) {
            const transform = entity.getComponent(Transform);
            const velocity = entity.getComponent(Velocity);
            const projectile = entity.getComponent(Projectile);
            const renderable = entity.getComponent(Renderable);

            if (transform && velocity) {
                // Gravity Bullet Logic
                if (projectile && projectile.type === 'gravity') {
                    // Check if this is already a deployed black hole
                    if (entity.tags.has('blackhole')) {
                        // This is a deployed black hole, just let the life countdown handle it
                    } else {
                        // This is a flying gravity bullet
                        velocity.x *= 0.95;
                        velocity.y *= 0.95;
                         
                        if (projectile.life <= 0 || (Math.abs(velocity.x) < 0.1 && Math.abs(velocity.y) < 0.1)) {
                            // Transform into Black Hole
                            if (this.addEntityCallback) {
                                // We don't have a BlackHole factory, but we can make a Particle that acts like one?
                                // Or just a stationary projectile with 'gravity' type but render as black hole?
                                // Demo: "particles.push({type: 'blackhole'...})"
                                // Let's create a special entity for BlackHole
                                const bh = new Entity();
                                bh.addComponent(new Transform(transform.x, transform.y));
                                // Black hole stays for 3 seconds (180 frames)
                               // We use Projectile component to identify it for collision (sucking)
                               bh.addComponent(new Projectile('gravity', 0.5, projectile.ownerId, 180)); 
                                bh.addComponent(new Renderable('black', 10, 0, 0, 'circle', 100)); // Render logic will handle effect?
                                // Add dummy velocity so MovementSystem iterates it and decreases life
                                bh.addComponent(new Velocity(0, 0, 0)); 
                                // Need a way to distinguish "flying gravity bullet" and "deployed black hole"
                                // Maybe 'deployed_gravity'?
                                // Let's use 'gravity' but with 0 velocity.
                                // Add a tag?
                                bh.tags.add('blackhole'); // Use tag for rendering effect
                                 
                                newEntities.push(bh);
                            }
                            entitiesToRemove.push(entity);
                            continue;
                        }
                    }
                }
                
                if (projectile && this.trailCtx) {
                    if (projectile.type === 'eraser') {
                        this.trailCtx.save();
                        this.trailCtx.globalCompositeOperation = 'destination-out';
                        this.trailCtx.beginPath();
                        this.trailCtx.arc(transform.x, transform.y, 10, 0, Math.PI * 2);
                        this.trailCtx.fillStyle = 'rgba(0,0,0,1)';
                        this.trailCtx.fill();
                        this.trailCtx.restore();
                    } else if (projectile.type === 'ribbon' && renderable) {
                        this.trailCtx.save();
                        this.trailCtx.globalAlpha = 0.8;
                        this.trailCtx.fillStyle = renderable.color;
                        const t = (projectile.life % 60) / 60;
                        const off = Math.sin(t * Math.PI * 2) * 8;
                        this.trailCtx.beginPath();
                        this.trailCtx.arc(transform.x - velocity.y * 0.2 + off, transform.y + velocity.x * 0.2, renderable.radius + 1, 0, Math.PI * 2);
                        this.trailCtx.fill();
                        this.trailCtx.restore();
                    }
                }

                // Flamethrower logic
                if (projectile && projectile.type === 'flamethrower' && renderable) {
                    const maxLife = 30;
                    const progress = 1 - (projectile.life / maxLife);
                    
                    // Expand and slow down over time
                    renderable.radius = 4 + (progress * 12);
                    velocity.x *= 0.92;
                    velocity.y *= 0.92;

                    // Update projectile color to fade out
                    const projAlpha = 0.8 * (1 - progress);
                    const trailAlpha = 0.4 * (1 - progress);

                    let r = 255, g = 68, b = 0; // Default fallback
                    if (projectile.baseColorRGB) {
                        const base = projectile.baseColorRGB;
                        if (base.r === 255 && base.g === 68 && base.b === 0) {
                            // 恢复经典的 橙红 -> 黄色 渐变
                            r = 255;
                            g = Math.floor(68 + progress * 150);
                            b = 0;
                        } else {
                            // 对于自定义颜色，做一个非常明显的渐变效果！
                            // 随着飞行（progress 0 -> 1），颜色会逐渐变亮并向白色/高光色偏移，制造出强烈的“火焰燃烧”和“能量消散”的感觉
                            // 原先的 60 太微弱了，现在加大到 180，让它有肉眼可见的色彩过渡
                            r = Math.min(255, Math.floor(base.r + progress * 180));
                            g = Math.min(255, Math.floor(base.g + progress * 180));
                            b = Math.min(255, Math.floor(base.b + progress * 180));
                        }
                    }

                    renderable.color = `rgba(${r}, ${g}, ${b}, ${projAlpha})`;

                    // Draw fire trail
                    if (this.trailCtx) {
                        this.trailCtx.save();
                        this.trailCtx.fillStyle = `rgba(${r}, ${g}, ${b}, ${trailAlpha})`;
                        this.trailCtx.beginPath();
                        this.trailCtx.arc(transform.x + (Math.random()-0.5)*8, transform.y + (Math.random()-0.5)*8, renderable.radius * 0.8, 0, Math.PI * 2);
                        this.trailCtx.fill();
                        this.trailCtx.restore();
                    }
                }

                // Compass logic
                if (projectile && projectile.type === 'compass') {
                    const maxLife = 90;
                    if (projectile.life > maxLife - 30) {
                        // Forward (handled by initial velocity)
                    } else if (projectile.life > maxLife - 60) {
                        // Spin in place
                        velocity.x = 0;
                        velocity.y = 0;
                        transform.rotation += 0.5; // Spin fast
                    } else {
                        // Return to player
                        // Keep it alive until it reaches the player
                        if (projectile.life <= 1) {
                            projectile.life = 2; // Prevent it from being removed by lifetime
                        }
                        
                        let player: Entity | null = null;
                        for (const e of this.entities) {
                            if (e.tags.has('player') && e.active) {
                                player = e;
                                break;
                            }
                        }
                        if (player) {
                            const pT = player.getComponent(Transform);
                            if (pT) {
                                const dx = pT.x - transform.x;
                                const dy = pT.y - transform.y;
                                const dist = Math.hypot(dx, dy);
                                if (dist < 30) {
                                    // Caught
                                    entitiesToRemove.push(entity);
                                    continue;
                                }
                                const speed = 15;
                                velocity.x = (dx / dist) * speed;
                                velocity.y = (dy / dist) * speed;
                            }
                        }
                        transform.rotation += 0.5; // Keep spinning while returning
                    }
                }

                // Shotgun Trail Logic
                if (projectile && projectile.type === 'shotgun' && this.trailCtx && renderable) {
                    if (Math.random() < 0.2) {
                        this.trailCtx.save();
                        this.trailCtx.beginPath();
                        this.trailCtx.arc(transform.x, transform.y, renderable.radius + Math.random() * 2, 0, Math.PI * 2);
                        this.trailCtx.fillStyle = renderable.color;
                        this.trailCtx.globalAlpha = 0.8; // 增加 Shotgun 喷雾痕迹的透明度到 0.8
                        this.trailCtx.fill();
                        this.trailCtx.restore();
                    }
                }

                const enemy = entity.getComponent(EnemyBehavior);
                if (enemy && velocity.speed > 0) {
                    const mag = Math.hypot(velocity.x, velocity.y);
                    if (mag > velocity.speed) {
                        velocity.x = (velocity.x / mag) * velocity.speed;
                        velocity.y = (velocity.y / mag) * velocity.speed;
                    }
                }
                
                let nextX = transform.x + velocity.x;
                let nextY = transform.y + velocity.y;

                // Collision with walls
                if (entity.tags.has('player') || entity.tags.has('enemy') || entity.tags.has('citizen')) {
                    const pr = renderable?.radius || 15;
                    for (const wall of this.entities) {
                        if (wall.tags.has('wall') && wall.active) {
                            const wTransform = wall.getComponent(Transform);
                            const wRender = wall.getComponent(Renderable);
                            if (wTransform && wRender && wRender.shape === 'rect') {
                                const hw = wRender.width / 2;
                                const hh = wRender.height / 2;
                                
                                // Check X movement
                                if (nextX + pr > wTransform.x - hw && nextX - pr < wTransform.x + hw &&
                                    transform.y + pr > wTransform.y - hh && transform.y - pr < wTransform.y + hh) {
                                    nextX = transform.x; // Block X
                                }
                                
                                // Check Y movement
                                if (transform.x + pr > wTransform.x - hw && transform.x - pr < wTransform.x + hw &&
                                    nextY + pr > wTransform.y - hh && nextY - pr < wTransform.y + hh) {
                                    nextY = transform.y; // Block Y
                                }
                            }
                        }
                    }
                }

                transform.x = nextX;
                transform.y = nextY;

                // Boundary check for Player and Enemy
                if (entity.tags.has('player') || entity.tags.has('enemy')) {
                    transform.x = Math.max(0, Math.min(this.worldWidth, transform.x));
                    transform.y = Math.max(0, Math.min(this.worldHeight, transform.y));
                }

                if (renderable && (entity.tags.has('player') || entity.tags.has('enemy')) && !entity.hasComponent(Skeleton)) {
                    const speed = Math.hypot(velocity.x, velocity.y);
                    if (speed > 0.1) {
                        // Stretch in direction of movement, squash perpendicular
                        const stretch = 1 + (speed * 0.05); // Adjust multiplier for effect strength
                        const squash = 1 / stretch; // Maintain volume roughly
                        
                        // We need to smoothly interpolate this
                        renderable.scaleX = renderable.scaleX + (stretch - renderable.scaleX) * 0.2;
                        renderable.scaleY = renderable.scaleY + (squash - renderable.scaleY) * 0.2;
                        
                        // Note: For this to work perfectly, we need to rotate the canvas to align with velocity before scaling.
                        // Currently RenderSystem rotates to `transform.rotation` which for player/enemy is aim direction, not velocity direction.
                        // For a pure soft-body look, we might want to decouple movement rotation from aim rotation later.
                    } else {
                        // Return to normal shape smoothly
                        renderable.scaleX = renderable.scaleX + (1.0 - renderable.scaleX) * 0.1;
                        renderable.scaleY = renderable.scaleY + (1.0 - renderable.scaleY) * 0.1;
                    }
                }
                
                // Boundary check for Projectiles?
                // The original code removed bullets if they went off screen.
                // Here "screen" means "world".
                if (projectile) {
                     if (transform.x < 0 || transform.x > this.worldWidth || 
                         transform.y < 0 || transform.y > this.worldHeight) {
                         entitiesToRemove.push(entity);
                     }
                }
            }
            
            // Handle projectile lifetime
            if (projectile && projectile.life > 0) {
                projectile.life--;
                if (projectile.life <= 0) {
                    entitiesToRemove.push(entity);
                }
            } else if (projectile && projectile.type === 'sniper') {
                 // Sniper beam auto-cleanup
                 entitiesToRemove.push(entity);
            }
        }

        // Add new entities
        if (this.addEntityCallback) {
            for (const e of newEntities) {
                this.addEntityCallback(e);
            }
        }

        // Cleanup expired entities
        for (const entity of entitiesToRemove) {
            if (entity.tags.has('player')) continue;
            // Hack: we don't have access to game.removeEntity directly, but we can mark inactive?
            // System doesn't have removeEntity method on itself usually.
            // But we can set active = false, and Game loop cleans it up.
            entity.active = false;
        }
    }
}
