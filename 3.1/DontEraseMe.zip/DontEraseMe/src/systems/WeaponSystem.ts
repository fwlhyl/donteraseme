import { System } from '../core/System';
import { Entity } from '../core/Entity';
import { Transform } from '../components/Transform';
import { Weapon } from '../components/Weapon';
import { InputManager } from '../core/InputManager';
import { PlayerControl } from '../components/PlayerControl';
import { Renderable } from '../components/Renderable';
import { BulletFactory } from '../entities/BulletFactory';
import { WEAPONS } from '../components/Weapon';
import { Projectile } from '../components/Projectile';
import { Skill } from '../components/Skill';
import { EnemyBehavior } from '../components/EnemyBehavior';
import { Health } from '../components/Health';
import { PlayerStats } from '../components/PlayerStats';
import { DamageTextSystem } from './DamageTextSystem';
import { ParticleFactory } from '../entities/ParticleFactory';
import { Score } from '../components/Score';
import { Experience } from '../components/Experience';
import { ExperienceOrb } from '../components/ExperienceOrb';
// removed Physics import
export class WeaponSystem extends System {   constructor(
        private input: InputManager,
        private addEntityCallback: (entity: Entity) => void,
        private trailCtx?: CanvasRenderingContext2D
    ) {
        super();
    }

    public update(dt: number): void {
        for (const entity of this.entities) {
            const weapon = entity.getComponent(Weapon);
            const transform = entity.getComponent(Transform);
            const renderable = entity.getComponent(Renderable);
            const stats = entity.getComponent(PlayerStats);
            
            if (weapon && transform && renderable) {
                // Handle cooldown
                if (weapon.cooldown > 0) {
                    weapon.cooldown -= 1; // Assuming 60fps frame based cooldown
                }

                // Only player controls weapon for now
                if (entity.tags.has('player')) {
                    this.handlePlayerInput(entity, weapon, transform, renderable);
                    
                    // 数字板绘师：浮游炮逻辑
                    if (stats && stats.hasDigitalPassive) {
                        this.handleDigitalPen(entity, stats, transform, renderable);
                    }
                }
            }
        }
    }

    private handlePlayerInput(player: Entity, weapon: Weapon, transform: Transform, renderable: Renderable): void {
        // Weapon switching
        if (this.input.isKeyDown('1')) this.switchWeapon(weapon, 0);
        if (this.input.isKeyDown('2')) this.switchWeapon(weapon, 1);
        if (this.input.isKeyDown('3')) this.switchWeapon(weapon, 2);
        if (this.input.isKeyDown('4')) this.switchWeapon(weapon, 3);
        if (this.input.isKeyDown('5')) this.switchWeapon(weapon, 4);
        if (this.input.isKeyDown('6')) this.switchWeapon(weapon, 5);
        if (this.input.isKeyDown('7')) this.switchWeapon(weapon, 6);
        if (this.input.isKeyDown('8')) this.switchWeapon(weapon, 7);
        if (this.input.isKeyDown('9')) this.switchWeapon(weapon, 8);
        if (this.input.isKeyDown('0')) {
            // Find the last weapon in the array, assuming 0 equips the newest fused weapon
            if (weapon.unlocked.size > 0) {
                const lastWeaponId = Math.max(...Array.from(weapon.unlocked));
                this.switchWeapon(weapon, lastWeaponId);
            }
        }
        
        // If weapon index is -1, it means unarmed (like in Prologue)
        if (weapon.currentWeaponIndex === -1) return;
        const stats = player.getComponent(PlayerStats);
        
        if (this.input.isKeyDown('r') || this.input.isKeyDown('R')) {
            this.startReload(weapon, stats);
        }

        // Update attacking state based on mouse input
        player.attacking = this.input.mouse.down;

        // Handle reloading timer
        if (weapon.reloading) {
            if (weapon.reloadTimer > 0) {
                weapon.reloadTimer -= 1;
            } else {
                const cfg = weapon.config;
                if (cfg) {
                    weapon.ammo[weapon.currentWeaponIndex] = cfg.magSize;
                }
                weapon.reloading = false;
            }
        }
        
        const config = weapon.config;
        if (!config) return;

        // Special continuous tool: Roller
        if (this.input.mouse.down && config.type === 'roller' && this.trailCtx) {
            weapon.cooldown = 2;
            this.trailCtx.save();
            this.trailCtx.fillStyle = renderable.color;
            this.trailCtx.globalAlpha = 0.8;
            this.trailCtx.beginPath();
            this.trailCtx.arc(transform.x, transform.y, 28, 0, Math.PI * 2);
            this.trailCtx.fill();
            this.trailCtx.restore();
        }
        // Shooting
        if (this.input.mouse.down && weapon.cooldown <= 0 && !weapon.reloading) {
            const idx = weapon.currentWeaponIndex;
            const cfg = config;
            if (cfg.type === 'melee') {
                this.shoot(player, weapon, transform, renderable.color, stats);
                // Melee不消耗子弹
            } else {
                if (weapon.ammo[idx] > 0) {
                    this.shoot(player, weapon, transform, renderable.color, stats);
                    if (!stats || Date.now() >= (stats.infiniteAmmoUntil || 0)) {
                        weapon.ammo[idx] -= 1;
                    }
                    if (weapon.ammo[idx] <= 0) {
                        this.startReload(weapon, stats);
                    }
                } else {
                    this.startReload(weapon, stats);
                }
            }
        }
    }

    private handleDigitalPen(player: Entity, stats: PlayerStats, transform: Transform, renderable: Renderable): void {
        stats.digitalPenCooldown -= 1;
        if (stats.digitalPenCooldown <= 0) {
            stats.digitalPenCooldown = stats.maxDigitalPenCooldown;
            if (stats.lastAttackConfig) {
                const weapon = player.getComponent(Weapon);
                if (weapon) {
                    // Find nearest enemy to aim at
                    let nearestEnemy: Entity | null = null;
                    let minDist = Infinity;
                    for (const e of this.entities) {
                        if (e.active && e.getComponent(EnemyBehavior)) {
                            const eTrans = e.getComponent(Transform);
                            if (eTrans) {
                                const dx = eTrans.x - transform.x;
                                const dy = eTrans.y - transform.y;
                                const dist = dx * dx + dy * dy;
                                if (dist < minDist) {
                                    minDist = dist;
                                    nearestEnemy = e;
                                }
                            }
                        }
                    }
                    
                    // Orbit offset logic (same as RenderSystem)
                    const time = Date.now() / 300;
                    const orbitRadius = renderable.radius + 20;
                    const penX = transform.x + Math.cos(time) * orbitRadius;
                    const penY = transform.y + Math.sin(time) * orbitRadius;
                    
                    let targetAngle = transform.rotation;
                    if (nearestEnemy) {
                        const eTrans = nearestEnemy.getComponent(Transform);
                        if (eTrans) {
                            targetAngle = Math.atan2(eTrans.y - penY, eTrans.x - penX);
                        }
                    }
                    
                    // Create a dummy transform for the pen
                    const penTransform = new Transform(penX, penY, targetAngle);
                    
                    // Fire the attack
                    this.fireDigitalPenAttack(player, weapon, stats.lastAttackConfig, penTransform, '#00ffff', stats);
                }
            }
        }
    }

    private fireDigitalPenAttack(owner: Entity, weapon: Weapon, config: any, transform: Transform, bulletColor: string, stats: PlayerStats): void {
        // A simplified version of shoot()
        const getDamage = (baseDamage: number, weaponBonus: number) => {
            let dmg = baseDamage + weaponBonus;
            let isCrit = false;
            dmg *= stats.damageMultiplier;
            if (stats.speedOverflow > 0) {
                dmg *= (1.0 + (stats.speedOverflow * 0.10));
            }
            if (stats.hasCalligrapherPassive && stats.calligrapherDamageStacks > 0) {
                dmg *= (1.0 + stats.calligrapherDamageStacks * 0.02);
            }
            const critC = weapon.critChance + stats.critChance;
            const critM = weapon.critMultiplier + (stats.critDamage - 1.5);
            if (Math.random() < critC) {
                dmg = Math.floor(dmg * critM);
                isCrit = true;
            }
            return { damage: dmg, isCrit };
        };

        if (config.type === 'ruler' && this.trailCtx) {
            const len = 600;
            const endX = transform.x + Math.cos(transform.rotation) * len;
            const endY = transform.y + Math.sin(transform.rotation) * len;
            this.trailCtx.save();
            this.trailCtx.strokeStyle = bulletColor;
            this.trailCtx.lineWidth = 8 * (stats ? stats.trailWidthMultiplier : 1);
            this.trailCtx.beginPath();
            this.trailCtx.moveTo(transform.x, transform.y);
            this.trailCtx.lineTo(endX, endY);
            this.trailCtx.stroke();
            this.trailCtx.restore();
            // Damage enemies along the line
            const ax = transform.x, ay = transform.y;
            const bx = endX, by = endY;
            const thickness = 12 * (stats ? stats.trailWidthMultiplier : 1);
            const idx = weapon.currentWeaponIndex;
            const bonus = weapon.damageBonus[idx] || 0;
            let rulerDmgResult = getDamage(config.damage, bonus);
            let baseRulerDmg = rulerDmgResult.damage;
            let isCrit = rulerDmgResult.isCrit;
            let pierceCount = 0;
            
            // Sort enemies by distance to player
            const enemiesHit = [];
            for (const e of this.entities) {
                if (!e.active || e === owner) continue;
                const eb = e.getComponent(EnemyBehavior);
                const tt = e.getComponent(Transform);
                const hp = e.getComponent(Health);
                if (!eb || !tt || !hp) continue;
                const dx = bx - ax, dy = by - ay;
                const t = Math.max(0, Math.min(1, ((tt.x - ax) * dx + (tt.y - ay) * dy) / (dx*dx + dy*dy + 1e-6)));
                const px = ax + dx * t, py = ay + dy * t;
                const d = Math.hypot(tt.x - px, tt.y - py);
                if (d <= thickness) {
                    const distToPlayer = Math.hypot(tt.x - ax, tt.y - ay);
                    enemiesHit.push({ e, hp, distToPlayer });
                }
            }
            
            enemiesHit.sort((a, b) => a.distToPlayer - b.distToPlayer);
            
            for (const hit of enemiesHit) {
                let dmg = baseRulerDmg;
                if (stats && stats.hasCalligrapherPassive) {
                    dmg *= (1 + pierceCount * 0.5); // 每次穿透伤害增加50%
                }
                hit.hp.current -= dmg;
                DamageTextSystem.addDamageText(hit.e.getComponent(Transform)!.x, hit.e.getComponent(Transform)!.y - 15, dmg, isCrit ? '#ff4444' : '#ffffff', isCrit);
                pierceCount++;
                if (hit.hp.current <= 0) {
                    this.handleEnemyDeath(hit.e, owner);
                }
            }
            return;
        }

        if (config.type === 'sniper') {
            const beam = new Entity();
            const range = config.range || 1200;
            const angle = transform.rotation;
            const endX = transform.x + Math.cos(angle) * range;
            const endY = transform.y + Math.sin(angle) * range;
            
            beam.addComponent(new Transform(transform.x, transform.y));
            beam.addComponent(new Renderable(bulletColor, 0, endX, endY, 'line', 5 * (stats ? stats.trailWidthMultiplier : 1)));
            beam.addComponent(new Projectile('sniper', config.damage, owner.id, 5));
            
            const beamProj = beam.getComponent(Projectile);
            if (beamProj) {
                const dmgResult = getDamage(beamProj.damage, 0);
                beamProj.damage = dmgResult.damage;
                beamProj.isCrit = dmgResult.isCrit;
            }
            this.addEntityCallback(beam);
            
            if (this.trailCtx) {
                setTimeout(() => {
                    if (this.trailCtx) {
                        this.trailCtx.save();
                        this.trailCtx.globalCompositeOperation = 'source-over';
                        this.trailCtx.beginPath();
                        this.trailCtx.moveTo(transform.x, transform.y);
                        this.trailCtx.lineTo(endX, endY);
                        this.trailCtx.strokeStyle = bulletColor;
                        this.trailCtx.lineWidth = 2 * (stats ? stats.trailWidthMultiplier : 1);
                        this.trailCtx.stroke();
                        this.trailCtx.restore();
                    }
                }, 0);
            }
            return;
        }

        if (config.type === 'melee') {
            const reach = (config.range || 80) * (stats ? stats.trailWidthMultiplier : 1);
            const halfArc = Math.PI * 0.35;
            const base = transform.rotation;
            let dmgResult = getDamage(config.damage, 0);
            let dmg = dmgResult.damage;
            let isCrit = dmgResult.isCrit;
            if (this.trailCtx) {
                this.trailCtx.save();
                this.trailCtx.strokeStyle = bulletColor;
                this.trailCtx.globalAlpha = 0.6;
                this.trailCtx.lineWidth = 6 * (stats ? stats.trailWidthMultiplier : 1);
                this.trailCtx.beginPath();
                this.trailCtx.arc(transform.x, transform.y, reach, base - halfArc, base + halfArc);
                this.trailCtx.stroke();
                this.trailCtx.restore();
            }
            for (const e of this.entities) {
                if (!e.active || e === owner) continue;
                const eb = e.getComponent(EnemyBehavior);
                const tt = e.getComponent(Transform);
                const hp = e.getComponent(Health);
                if (!eb || !tt || !hp) continue;
                const dx = tt.x - transform.x;
                const dy = tt.y - transform.y;
                const dist = Math.sqrt(dx*dx + dy*dy);
                if (dist <= reach + 15) {
                    let angleToEnemy = Math.atan2(dy, dx);
                    let angleDiff = angleToEnemy - base;
                    while (angleDiff <= -Math.PI) angleDiff += Math.PI * 2;
                    while (angleDiff > Math.PI) angleDiff -= Math.PI * 2;
                    if (Math.abs(angleDiff) <= halfArc) {
                        hp.current -= dmg;
                        DamageTextSystem.addDamageText(tt.x, tt.y - 15, dmg, isCrit ? '#ff4444' : '#ffffff', isCrit);
                        if (hp.current <= 0) this.handleEnemyDeath(e, owner);
                    }
                }
            }
            return;
        }

        const count = config.count + stats.bulletCountBonus;
        for (let i = 0; i < count; i++) {
            const spread = (Math.random() - 0.5) * config.spread * weapon.spreadMul;
            const angle = transform.rotation + spread;
            const bullet = BulletFactory.create(
                config,
                transform.x,
                transform.y,
                angle,
                bulletColor,
                owner.id,
                weapon.speedMul,
                stats.trailWidthMultiplier
            );
            const proj = bullet.getComponent(Projectile);
            if (proj) {
                const dmgResult = getDamage(proj.damage, 0);
                proj.damage = dmgResult.damage;
                proj.isCrit = dmgResult.isCrit;
                proj.pierceCount = weapon.pierceCount + stats.pierceBonus;
                if (config.type === 'rocket') {
                    proj.explosionRadiusScale = weapon.explosionRadiusScale;
                }
                if (config.type === 'chain') {
                    proj.pierceCount = 3;
                }
            }
            this.addEntityCallback(bullet);
        }
    }

    private switchWeapon(weapon: Weapon, index: number): void {
        if (!weapon.unlocked.has(index)) return;
        if (weapon.currentWeaponIndex !== index) {
            weapon.currentWeaponIndex = index;
            weapon.cooldown = 20; // Reset cooldown on switch
            console.log(`Switched to weapon: ${WEAPONS[index].name}`);
        }
    }

    private shoot(owner: Entity, weapon: Weapon, transform: Transform, ownerColor: string, stats?: PlayerStats): void {
        const config = weapon.config;
        if (!config) return;
        const frMultiplier = stats ? weapon.fireRateMul / stats.fireRateMultiplier : weapon.fireRateMul;
        weapon.cooldown = Math.max(1, Math.round(config.fireRate * frMultiplier));
        
        const getDamage = (baseDamage: number, weaponBonus: number): { damage: number, isCrit: boolean } => {
            let dmg = baseDamage + weaponBonus;
            let isCrit = false;
            if (stats) {
                // 应用基础伤害倍率
                dmg *= stats.damageMultiplier;
                
                // 溢出的移动速度转化为额外伤害倍率（每溢出 1 点速度增加 10% 伤害）
                if (stats.speedOverflow > 0) {
                    const extraMultiplier = 1.0 + (stats.speedOverflow * 0.10);
                    dmg *= extraMultiplier;
                }

                // 书法家被动伤害加成（每层2%）
                if (stats.hasCalligrapherPassive && stats.calligrapherDamageStacks > 0) {
                    dmg *= (1.0 + stats.calligrapherDamageStacks * 0.02);
                }
            }
            const critC = weapon.critChance + (stats ? stats.critChance : 0);
            const critM = weapon.critMultiplier + (stats ? (stats.critDamage - 1.5) : 0);
            if (Math.random() < critC) {
                dmg = Math.floor(dmg * critM);
                isCrit = true;
            }
            return { damage: dmg, isCrit };
        };
        
        // Set attack state for player
        if (owner.tags.has('player')) {
            // We now update attack state based on mouse down in handlePlayerInput
            // rather than a timeout here.
            
            // 数字板绘师：记录上一次攻击
            if (stats && stats.hasDigitalPassive) {
                stats.lastAttackConfig = config;
            }
        }
        
        // Determine bullet color
        let bulletColor = config.color;
        // All weapons except Pistol (0) should use player color
        if (config.id !== 0) {
            bulletColor = ownerColor;
        }

        // Ruler gun draws a direct line
        if (config.type === 'ruler' && this.trailCtx) {
            const len = 600;
            const endX = transform.x + Math.cos(transform.rotation) * len;
            const endY = transform.y + Math.sin(transform.rotation) * len;
            this.trailCtx.save();
            this.trailCtx.strokeStyle = ownerColor;
            this.trailCtx.lineWidth = 8 * (stats ? stats.trailWidthMultiplier : 1);
            this.trailCtx.beginPath();
            this.trailCtx.moveTo(transform.x, transform.y);
            this.trailCtx.lineTo(endX, endY);
            this.trailCtx.stroke();
            this.trailCtx.restore();
            // Damage enemies along the line
            const ax = transform.x, ay = transform.y;
            const bx = endX, by = endY;
            const thickness = 12 * (stats ? stats.trailWidthMultiplier : 1);
            const idx = weapon.currentWeaponIndex;
            const bonus = weapon.damageBonus[idx] || 0;
            let rulerDmgResult = getDamage(config.damage, bonus);
            let baseRulerDmg = rulerDmgResult.damage;
            let isCrit = rulerDmgResult.isCrit;
            let pierceCount = 0;
            
            // Sort enemies by distance to player
            const enemiesHit = [];
            for (const e of this.entities) {
                if (!e.active || e === owner) continue;
                const eb = e.getComponent(EnemyBehavior);
                const tt = e.getComponent(Transform);
                const hp = e.getComponent(Health);
                if (!eb || !tt || !hp) continue;
                const dx = bx - ax, dy = by - ay;
                const t = Math.max(0, Math.min(1, ((tt.x - ax) * dx + (tt.y - ay) * dy) / (dx*dx + dy*dy + 1e-6)));
                const px = ax + dx * t, py = ay + dy * t;
                const d = Math.hypot(tt.x - px, tt.y - py);
                if (d <= thickness) {
                    const distToPlayer = Math.hypot(tt.x - ax, tt.y - ay);
                    enemiesHit.push({ e, hp, distToPlayer });
                }
            }
            
            enemiesHit.sort((a, b) => a.distToPlayer - b.distToPlayer);
            
            for (const hit of enemiesHit) {
                let dmg = baseRulerDmg;
                if (stats && stats.hasCalligrapherPassive) {
                    dmg *= (1 + pierceCount * 0.5); // 每次穿透伤害增加50%
                }
                hit.hp.current -= dmg;
                DamageTextSystem.addDamageText(hit.e.getComponent(Transform)!.x, hit.e.getComponent(Transform)!.y - 15, dmg, isCrit ? '#ff4444' : '#ffffff', isCrit);
                pierceCount++;
                if (hit.hp.current <= 0) {
                    this.handleEnemyDeath(hit.e, owner);
                }
            }
            return;
        }

        // Ruler skill: one-shot straight line
        const sk = owner.getComponent(Skill);
        if (sk && sk.rulerArmed && this.trailCtx) {
            const len = 600;
            const endX = transform.x + Math.cos(transform.rotation) * len;
            const endY = transform.y + Math.sin(transform.rotation) * len;
            this.trailCtx.save();
            this.trailCtx.strokeStyle = ownerColor;
            this.trailCtx.lineWidth = 6;
            this.trailCtx.beginPath();
            this.trailCtx.moveTo(transform.x, transform.y);
            this.trailCtx.lineTo(endX, endY);
            this.trailCtx.stroke();
            this.trailCtx.restore();
            sk.rulerArmed = false;
            return;
        }

        // Sniper special logic (Raycast)
        if (config.type === 'sniper') {
            // Create a visual beam entity
            const beam = new Entity();
            
            // Calculate beam end point (very far away)
            const range = config.range || 1200;
            const angle = transform.rotation; // Use rotation directly
            const endX = transform.x + Math.cos(angle) * range;
            const endY = transform.y + Math.sin(angle) * range;
            
            // We use Transform for start point, and Renderable width/height for end point (as per RenderSystem logic)
            beam.addComponent(new Transform(transform.x, transform.y));
            // Store end coordinates in width/height for line drawing
            beam.addComponent(new Renderable(bulletColor, 0, endX, endY, 'line', 5 * (stats ? stats.trailWidthMultiplier : 1))); // Use bulletColor
            
            beam.addComponent(new Projectile('sniper', config.damage, owner.id, 5));
            const beamProj = beam.getComponent(Projectile);
            if (beamProj) {
                const idx = weapon.currentWeaponIndex;
                const bonus = weapon.damageBonus[idx] || 0;
                const dmgResult = getDamage(beamProj.damage, bonus);
                beamProj.damage = dmgResult.damage;
                beamProj.isCrit = dmgResult.isCrit;
                if (stats && stats.hasCalligrapherPassive) {
                    beamProj.calligrapherBonus = true;
                }
            }
            
            this.addEntityCallback(beam);
            
            // Draw Trail Line
            // Delay drawing the sniper trail line slightly so it happens AFTER the eraser 
            // has processed its death and stopped erasing.
            if (this.trailCtx) {
                // By deferring this to the end of the current event loop or next frame,
                // we ensure all CollisionSystem deaths are processed first.
                // Using setTimeout(..., 0) pushes this to the macro-task queue, 
                // which runs after the current frame's systems finish updating.
                setTimeout(() => {
                    if (this.trailCtx) {
                        this.trailCtx.save();
                        this.trailCtx.globalCompositeOperation = 'source-over';
                        this.trailCtx.beginPath();
                        this.trailCtx.moveTo(transform.x, transform.y);
                        this.trailCtx.lineTo(endX, endY);
                        this.trailCtx.strokeStyle = bulletColor;
                        this.trailCtx.lineWidth = 2 * (stats ? stats.trailWidthMultiplier : 1);
                        this.trailCtx.stroke();
                        this.trailCtx.restore();
                    }
                }, 0);
            }
            
            return;
        }

        // Melee：前方扇形近战打击
        if (config.type === 'melee') {
            const reach = (config.range || 80) * (stats ? stats.trailWidthMultiplier : 1);
            const halfArc = Math.PI * 0.35; // 约40度扇形
            const base = transform.rotation;
            const idx = weapon.currentWeaponIndex;
            const bonus = weapon.damageBonus[idx] || 0;
            let dmgResult = getDamage(config.damage, bonus);
            let dmg = dmgResult.damage;
            let isCrit = dmgResult.isCrit;
            // 视觉：在轨迹层画出短暂的弧线
            if (this.trailCtx) {
                this.trailCtx.save();
                this.trailCtx.strokeStyle = ownerColor;
                this.trailCtx.globalAlpha = 0.6;
                this.trailCtx.lineWidth = 6 * (stats ? stats.trailWidthMultiplier : 1);
                this.trailCtx.beginPath();
                this.trailCtx.arc(transform.x, transform.y, reach, base - halfArc, base + halfArc);
                this.trailCtx.stroke();
                this.trailCtx.restore();
            }
            // 命中判定
            for (const e of this.entities) {
                if (!e.active || e === owner) continue;
                const eb = e.getComponent(EnemyBehavior);
                const tt = e.getComponent(Transform);
                const hp = e.getComponent(Health);
                if (!eb || !tt || !hp) continue;
                const dx = tt.x - transform.x;
                const dy = tt.y - transform.y;
                const dist = Math.hypot(dx, dy);
                if (dist > reach) continue;
                const ang = Math.atan2(dy, dx);
                let diff = ang - base;
                while (diff > Math.PI) diff -= Math.PI * 2;
                while (diff < -Math.PI) diff += Math.PI * 2;
                if (Math.abs(diff) <= halfArc) {
                    hp.current -= dmg;
                    DamageTextSystem.addDamageText(tt.x, tt.y - 15, dmg, isCrit ? '#ff4444' : '#ffffff', isCrit);
                    // 轻微击退
                    const kb = 8;
                    tt.x += Math.cos(ang) * kb;
                    tt.y += Math.sin(ang) * kb;
                    if (hp.current <= 0) {
                        this.handleEnemyDeath(e, owner);
                    }
                }
            }
            return;
        }

        const count = config.count + (stats ? stats.bulletCountBonus : 0);
        for (let i = 0; i < count; i++) {
            const spread = (Math.random() - 0.5) * config.spread * weapon.spreadMul;
            const angle = transform.rotation + spread;
            
            // Create bullet entity
            const bullet = BulletFactory.create(
                config,
                transform.x,
                transform.y,
                angle,
                bulletColor, // Use bulletColor
                owner.id,
                weapon.speedMul,
                stats ? stats.trailWidthMultiplier : 1.0
            );
            const proj = bullet.getComponent(Projectile);
            if (proj) {
                const idx = weapon.currentWeaponIndex;
                const bonus = weapon.damageBonus[idx] || 0;
                const dmgResult = getDamage(proj.damage, bonus);
                proj.damage = dmgResult.damage;
                proj.isCrit = dmgResult.isCrit;
                proj.pierceCount = weapon.pierceCount + (stats ? stats.pierceBonus : 0);
                if (config.type === 'rocket') {
                    proj.explosionRadiusScale = weapon.explosionRadiusScale;
                }
                if (config.type === 'chain') {
                    proj.pierceCount = 3;
                }
                if (stats && stats.hasCalligrapherPassive) {
                    proj.calligrapherBonus = true;
                }
            }
            
            this.addEntityCallback(bullet);
        }
    }
    
    private startReload(weapon: Weapon, stats?: PlayerStats) {
        if (weapon.reloading) return;
        const cfg = weapon.config;
        if (!cfg) return;
        weapon.reloading = true;
        const reloadMul = stats ? weapon.reloadTimeMul / stats.reloadSpeedMultiplier : weapon.reloadTimeMul;
        const rt = Math.max(1, Math.floor(cfg.reloadTime * reloadMul));
        weapon.reloadTimer = rt;
        weapon.cooldown = rt;
    }

    private handleEnemyDeath(enemy: Entity, player: Entity): void {
        if (!enemy.active) return;
        enemy.active = false;

        const score = player.getComponent(Score);
        const stats = player.getComponent(PlayerStats);
        
        if (score) {
            score.value += 10;
            if (enemy.getComponent(EnemyBehavior)?.type === 'eraser') {
                score.value += 40;
            }
            
            const t = enemy.getComponent(EnemyBehavior)?.type || 'chaser';
            let baseGold = 1;
            if (t === 'boss') baseGold = 100;
            else if (t !== 'chaser') baseGold = 5;
            
            let goldMultiplier = 1;
            if (stats) {
                if (stats.characterId === 'collector') {
                    goldMultiplier += stats.survivalTime * 0.005; 
                }
                const finalGold = Math.ceil(baseGold * goldMultiplier);
                score.coins += finalGold;
                stats.gold += finalGold;
            } else {
                score.coins += baseGold;
            }
        }

        const tt = enemy.getComponent(Transform);
        const tr = enemy.getComponent(Renderable);

        const exp = player.getComponent(Experience);
            if (exp && this.addEntityCallback && tt) {
                const orb = new Entity();
                orb.tags.add('xp_orb');
                orb.addComponent(new Transform(tt.x, tt.y));
                orb.addComponent(new ExperienceOrb(20));
                orb.addComponent(new Renderable('#00ff00', 6, 0, 0, 'diamond'));
                this.addEntityCallback(orb);
            }
        if (tt && tr && this.addEntityCallback) {
            const particles = ParticleFactory.createExplosion(tt.x, tt.y, tr.color, 10);
            particles.forEach(p => this.addEntityCallback!(p));
        }
    }
}
