import { System } from '../core/System';
import { Entity } from '../core/Entity';
import { Transform } from '../components/Transform';
import { ControlPoint } from '../components/ControlPoint';
import { Renderable } from '../components/Renderable';
import { PlayerControl } from '../components/PlayerControl';
import { Health } from '../components/Health';

export class ObjectiveSystem extends System {
    constructor(
        private worldWidth: number,
        private worldHeight: number,
        private addEntityCallback: (e: Entity) => void
    ) {
        super();
    }
    
    public update(dt: number): void {
        let player: Entity | undefined;
        for (const e of this.entities) {
            if (e.tags.has('player')) { player = e; break; }
        }
        if (!player) return;
        
        const pT = player.getComponent(Transform);
        if (!pT) return;
        
        for (const e of this.entities) {
            const cp = e.getComponent(ControlPoint);
            const t = e.getComponent(Transform);
            if (!cp || !t || !cp.active) continue;
            
            const dist = Math.hypot(t.x - pT.x, t.y - pT.y);
            if (dist <= cp.radius) {
                cp.progress += 1;
                if (cp.progress >= cp.required) {
                    cp.active = false;
                    this.applyReward(player);
                    this.spawnNext();
                    e.active = false;
                }
            } else {
                cp.progress = Math.max(0, cp.progress - 0.5);
            }
        }
        
        if (![...this.entities].some(e => e.getComponent(ControlPoint) && e.active)) {
            this.spawnNext();
        }
    }
    
    private applyReward(player: Entity) {
        const options = [
            '移速+10%',
            '射速+10%',
            '散布-20%',
            '生命+30',
            '技能冷却-15%',
            '武器伤害+10',
            '换弹速度+20%',
            '轨迹粗细+20%',
            '暴击+10%',
            '子弹穿透+1',
            '爆炸范围+20%'
        ];
        // Pick 3 distinct
        const picks: string[] = [];
        while (picks.length < 3 && options.length > 0) {
            const i = Math.floor(Math.random() * options.length);
            picks.push(options.splice(i, 1)[0]);
        }
        window.dispatchEvent(new CustomEvent('choose-perk', { detail: { picks } }));
        window.dispatchEvent(new CustomEvent('game-pause', { detail: { paused: true } }));
    }
    
    private spawnNext() {
        const e = new Entity();
        const x = Math.random() * (this.worldWidth - 400) + 200;
        const y = Math.random() * (this.worldHeight - 400) + 200;
        e.addComponent(new Transform(x, y));
        e.addComponent(new ControlPoint(80, 0, 300, true));
        e.addComponent(new Renderable('rgba(0, 200, 255, 0.2)', 80, 0, 0, 'circle', 5));
        e.tags.add('control_point');
        this.addEntityCallback(e);
    }
}
