import { System } from '../core/System';
import { Entity } from '../core/Entity';
import { Experience } from '../components/Experience';
import { Weapon } from '../components/Weapon';
import { Health } from '../components/Health';
import { Skill } from '../components/Skill';

export class LevelSystem extends System {
    public update(dt: number): void {
        for (const e of this.entities) {
            if (!e.tags.has('player')) continue;
            const exp = e.getComponent(Experience);
            if (!exp) continue;
            while (exp.xp >= exp.next) {
                exp.xp -= exp.next;
                exp.level += 1;
                exp.next = Math.floor(exp.next * 1.2 + 50);
                const health = e.getComponent(Health);
                if (health) {
                    health.max += 25;
                    health.current = Math.min(health.max, health.current + 100);
                }
                const weapon = e.getComponent(Weapon);
                if (weapon) {
                    if (exp.level >= 5) weapon.unlocked.add(1);
                    if (exp.level >= 10) weapon.unlocked.add(2);
                    if (exp.level >= 15) weapon.unlocked.add(3);
                    if (exp.level >= 20) weapon.unlocked.add(4);
                    if (exp.level >= 25) weapon.unlocked.add(5);
                    if (exp.level >= 30) weapon.unlocked.add(6);
                    if (exp.level >= 35) weapon.unlocked.add(7);
                }
                const skill = e.getComponent(Skill);
                if (skill) {
                    // Unlocks are enforced in SkillSystem via level checks
                }
                window.dispatchEvent(new CustomEvent('player-levelup', { detail: { level: exp.level } }));
                if (exp.level === 10) {
                    //window.dispatchEvent(new CustomEvent('announce', { detail: { text: `解锁：瞬移 (Shift)` } }));
                } else if (exp.level === 20) {
                    window.dispatchEvent(new CustomEvent('announce', { detail: { text: `解锁：爆炸 (Space)` } }));
                }
            }
        }
    }
}
