import { System } from '../core/System';
import { Entity } from '../core/Entity';
import { EnemyFactory } from '../entities/EnemyFactory';
import { EnemyBehavior } from '../components/EnemyBehavior';
import { Transform } from '../components/Transform';
import { Renderable } from '../components/Renderable';
import { Health } from '../components/Health';

export class WaveSystem extends System {
    private spawnTimer: number = 0;
    private spawnInterval: number = 2; // Seconds
    private wave: number = 1;
    private enemiesSpawnedInWave: number = 0;
    private maxEnemiesInWave: number = 10;
    private bossSpawned: boolean = false;
    
    private width: number = window.innerWidth;
    private height: number = window.innerHeight;

    constructor(
        private addEntityCallback: (entity: Entity) => void,
        private camera: { x: number, y: number }
    ) {
        super();
        window.addEventListener('resize', () => {
            this.width = window.innerWidth;
            this.height = window.innerHeight;
        });
    }

    public update(dt: number): void {
        // Count active enemies
        let activeEnemies = 0;
        for (const entity of this.entities) {
            if (entity.getComponent(EnemyBehavior)) {
                activeEnemies++;
            }
        }

        // Wave logic
        if (this.enemiesSpawnedInWave >= this.maxEnemiesInWave && activeEnemies === 0) {
            this.startNextWave();
        }

        // Spawn logic
        if (this.enemiesSpawnedInWave < this.maxEnemiesInWave) {
            this.spawnTimer -= dt;
            if (this.spawnTimer <= 0) {
                this.spawnEnemy();
                this.spawnTimer = this.spawnInterval;
            }
        }
    }

    public reset(): void {
        this.wave = 1;
        this.enemiesSpawnedInWave = 0;
        this.maxEnemiesInWave = 10;
        this.spawnInterval = 2;
        this.spawnTimer = 0;
        this.bossSpawned = false;
    }

    private startNextWave(): void {
        this.wave++;
        this.enemiesSpawnedInWave = 0;
        this.maxEnemiesInWave += 5; // Increase difficulty
        this.spawnInterval *= 0.9; // Spawn faster
        if (this.spawnInterval < 0.5) this.spawnInterval = 0.5;
        this.bossSpawned = false;
        
        console.log(`Wave ${this.wave} Started! Max Enemies: ${this.maxEnemiesInWave}`);
        window.dispatchEvent(new CustomEvent('announce', { detail: { text: `Wave ${this.wave}` } }));
    }

    private spawnEnemy(): void {
        // Calculate visible area in world coordinates
        const viewX = this.camera.x;
        const viewY = this.camera.y;
        const viewW = this.width;
        const viewH = this.height;
        const padding = 50;
        let x = 0, y = 0;

        // Clamp to world bounds (optional, but good to keep them inside or just outside)
        // Actually, if we spawn outside world bounds, they might get stuck or look weird if we have walls.
        // But for now, let's allow them to spawn outside and walk in.
        
        if (this.wave % 5 === 0 && !this.bossSpawned) {
            x = viewX + viewW / 2;
            y = viewY + viewH / 2;
            const warn = new Entity();
            warn.addComponent(new Transform(x, y));
            warn.addComponent(new Renderable('rgba(255,204,0,0.25)', 80, 0, 0, 'circle', 9999));
            this.addEntityCallback(warn);
            window.dispatchEvent(new CustomEvent('announce', { detail: { text: `BOSS 即将出现` } }));
            setTimeout(() => {
                const boss = EnemyFactory.create('boss', x, y);
                const hp = boss.getComponent(Health);
                if (hp) {
                    const inc = Math.max(0, (this.wave - 1)) * 30;
                    hp.max += inc;
                    hp.current = hp.max;
                }
                this.addEntityCallback(boss);
                window.dispatchEvent(new CustomEvent('announce', { detail: { text: `BOSS 来了！` } }));
            }, 1500);
            this.enemiesSpawnedInWave++;
            this.bossSpawned = true;
            setTimeout(() => {
                warn.active = false;
            }, 1500);
            return;
        }
        
        // For regular enemies, spawn at屏幕四边
        const side = Math.floor(Math.random() * 4);
        switch (side) {
            case 0: // Top
                x = viewX + Math.random() * viewW;
                y = viewY - padding;
                break;
            case 1: // Right
                x = viewX + viewW + padding;
                y = viewY + Math.random() * viewH;
                break;
            case 2: // Bottom
                x = viewX + Math.random() * viewW;
                y = viewY + viewH + padding;
                break;
            case 3: // Left
                x = viewX - padding;
                y = viewY + Math.random() * viewH;
                break;
        }
        const r = Math.random();
        let type: any = 'chaser';
        if (r < 0.55) type = 'chaser';
        else if (r < 0.7) type = 'eraser';
        else if (r < 0.82) type = 'shield';
        else if (r < 0.94) type = 'shooter';
        else type = 'summoner';
        if (this.wave < 3 && type === 'shooter') {
            type = Math.random() < 0.5 ? 'chaser' : 'eraser';
        }
        
        const enemy = EnemyFactory.create(type, x, y);
        const hp = enemy.getComponent(Health);
        if (hp) {
            const inc = Math.max(0, (this.wave - 1)) * 30;
            hp.max += inc;
            hp.current = hp.max;
        }
        this.addEntityCallback(enemy);
        this.enemiesSpawnedInWave++;
    }
}
