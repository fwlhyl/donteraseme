import { System } from '../core/System';
import { Entity } from '../core/Entity';
import { Transform } from '../components/Transform';
import { Weapon } from '../components/Weapon';
import { InputManager } from '../core/InputManager';
import { PlayerControl } from '../components/PlayerControl';
import { Renderable } from '../components/Renderable';
import { BulletFactory } from '../entities/BulletFactory';
import { WEAPONS } from '../components/Weapon';
import { Projectile } from '../components/Projectile';
import { Skill } from '../components/Skill';
import { EnemyBehavior } from '../components/EnemyBehavior';
import { Health } from '../components/Health';
import { PlayerStats } from '../components/PlayerStats';
import { DamageTextSystem } from './DamageTextSystem';
import { ParticleFactory } from '../entities/ParticleFactory';
import { Score } from '../components/Score';
import { Experience } from '../components/Experience';
import { ExperienceOrb } from '../components/ExperienceOrb';
import { Puddle } from '../components/Puddle';
// removed Physics import
import { DeathHandler } from './DeathHandler';
export class WeaponSystem extends System {   constructor(
        private input: InputManager,
        private addEntityCallback: (entity: Entity) => void,
        private trailCtx?: CanvasRenderingContext2D
    ) {
        super();
    }

    public update(dt: number): void {
        for (const entity of this.entities) {
            const weapon = entity.getComponent(Weapon);
            const transform = entity.getComponent(Transform);
            const renderable = entity.getComponent(Renderable);
            const stats = entity.getComponent(PlayerStats);
            
            if (weapon && transform && renderable) {
                // Handle cooldown
                if (weapon.cooldown > 0) {
                    weapon.cooldown -= 1; // Assuming 60fps frame based cooldown
                }

                // Only player controls weapon for now
                if (entity.tags.has('player')) {
                    this.handlePlayerInput(entity, weapon, transform, renderable);
                    
                    // 数字板绘师：浮游炮逻辑
                    if (stats && stats.hasDigitalPassive) {
                        this.handleDigitalPen(entity, stats, transform, renderable);
                    }
                }
            }
        }
    }

    private handlePlayerInput(player: Entity, weapon: Weapon, transform: Transform, renderable: Renderable): void {
        // Weapon switching
        if (this.input.isKeyDown('1')) this.switchWeapon(weapon, 0);
        if (this.input.isKeyDown('2')) this.switchWeapon(weapon, 1);
        if (this.input.isKeyDown('3')) this.switchWeapon(weapon, 2);
        if (this.input.isKeyDown('4')) this.switchWeapon(weapon, 3);
        if (this.input.isKeyDown('5')) this.switchWeapon(weapon, 4);
        if (this.input.isKeyDown('6')) this.switchWeapon(weapon, 5);
        if (this.input.isKeyDown('7')) this.switchWeapon(weapon, 6);
        if (this.input.isKeyDown('8')) this.switchWeapon(weapon, 7);
        if (this.input.isKeyDown('9')) this.switchWeapon(weapon, 8);
        if (this.input.isKeyDown('0')) {
            // Find the last weapon in the array, assuming 0 equips the newest fused weapon
            if (weapon.unlocked.size > 0) {
                const lastWeaponId = Math.max(...Array.from(weapon.unlocked));
                this.switchWeapon(weapon, lastWeaponId);
            }
        }
        
        // If weapon index is -1, it means unarmed (like in Prologue)
        if (weapon.currentWeaponIndex === -1) return;
        const stats = player.getComponent(PlayerStats);
        
        if (this.input.isKeyDown('r') || this.input.isKeyDown('R')) {
            this.startReload(player, weapon, stats);
        }

        // Update attacking state based on mouse input
        player.attacking = this.input.mouse.down;

        // Handle reloading timer
        if (weapon.reloading) {
            if (weapon.reloadTimer > 0) {
                weapon.reloadTimer -= 1;
            } else {
                const cfg = weapon.config;
                if (cfg) {
                    weapon.ammo[weapon.currentWeaponIndex] = cfg.magSize;
                }
                weapon.reloading = false;
            }
        }
        
        const config = weapon.config;
        if (!config) return;

        // Special continuous tool: Roller
        if (this.input.mouse.down && config.type === 'roller' && this.trailCtx) {
            weapon.cooldown = 2;
            this.trailCtx.save();
            this.trailCtx.fillStyle = renderable.color;
            this.trailCtx.globalAlpha = 0.8;
            this.trailCtx.beginPath();
            this.trailCtx.arc(transform.x, transform.y, 28, 0, Math.PI * 2);
            this.trailCtx.fill();
            this.trailCtx.restore();
        }
        // Shooting
        if (this.input.mouse.down && weapon.cooldown <= 0 && !weapon.reloading) {
            const idx = weapon.currentWeaponIndex;
            const cfg = config;
            if (cfg.type === 'melee') {
                this.shoot(player, weapon, transform, renderable.color, stats);
                // Melee不消耗子弹
            } else {
                if (weapon.ammo[idx] > 0) {
                    this.shoot(player, weapon, transform, renderable.color, stats);
                    if (!stats || Date.now() >= (stats.infiniteAmmoUntil || 0)) {
                        weapon.ammo[idx] -= 1;
                    }
                    if (weapon.ammo[idx] <= 0) {
                        this.startReload(player, weapon, stats);
                    }
                } else {
                    this.startReload(player, weapon, stats);
                }
            }
        }
    }

    private handleDigitalPen(player: Entity, stats: PlayerStats, transform: Transform, renderable: Renderable): void {
        stats.digitalPenCooldown -= 1;
        if (stats.digitalPenCooldown <= 0) {
            stats.digitalPenCooldown = stats.maxDigitalPenCooldown;
            if (stats.lastAttackConfig) {
                const weapon = player.getComponent(Weapon);
                if (weapon) {
                    // Find nearest enemy to aim at
                    let nearestEnemy: Entity | null = null;
                    let minDist = Infinity;
                    for (const e of this.entities) {
                        if (e.active && e.getComponent(EnemyBehavior)) {
                            const eTrans = e.getComponent(Transform);
                            if (eTrans) {
                                const dx = eTrans.x - transform.x;
                                const dy = eTrans.y - transform.y;
                                const dist = dx * dx + dy * dy;
                                if (dist < minDist) {
                                    minDist = dist;
                                    nearestEnemy = e;
                                }
                            }
                        }
                    }
                    
                    // Orbit offset logic (same as RenderSystem)
                    const time = Date.now() / 300;
                    const orbitRadius = renderable.radius + 20;
                    const penX = transform.x + Math.cos(time) * orbitRadius;
                    const penY = transform.y + Math.sin(time) * orbitRadius;
                    
                    let targetAngle = transform.rotation;
                    if (nearestEnemy) {
                        const eTrans = nearestEnemy.getComponent(Transform);
                        if (eTrans) {
                            targetAngle = Math.atan2(eTrans.y - penY, eTrans.x - penX);
                        }
                    }
                    
                    // Create a dummy transform for the pen
                    const penTransform = new Transform(penX, penY, targetAngle);
                    
                    // Fire the attack
                    this.fireDigitalPenAttack(player, weapon, stats.lastAttackConfig, penTransform, '#00ffff', stats);
                }
            }
        }
    }

    private fireDigitalPenAttack(owner: Entity, weapon: Weapon, config: any, transform: Transform, bulletColor: string, stats: PlayerStats): void {
        let isReaperStrike = false;
        if (stats && stats.killReaperReady) {
            isReaperStrike = true;
            stats.killReaperReady = false;
        }

        // A simplified version of shoot()
        const getDamage = (baseDamage: number, weaponBonus: number) => {
            let dmg = baseDamage + weaponBonus;
            let isCrit = false;
            dmg *= stats.damageMultiplier;
            if (stats.speedOverflow > 0) {
                dmg *= (1.0 + (stats.speedOverflow * 0.10));
            }
            if (stats.hasCalligrapherPassive && stats.calligrapherDamageStacks > 0) {
                dmg *= (1.0 + stats.calligrapherDamageStacks * 0.02);
            }
            let critC = weapon.critChance + stats.critChance;
            let critM = weapon.critMultiplier + (stats.critDamage - 1.5);

            if (isReaperStrike) {
                critC = 1.0;
            }

            if (Math.random() < critC) {
                dmg = Math.floor(dmg * critM);
                isCrit = true;
            }
            return { damage: dmg, isCrit };
        };

        if (config.type === 'ruler' && this.trailCtx) {
            const len = 600;
            const endX = transform.x + Math.cos(transform.rotation) * len;
            const endY = transform.y + Math.sin(transform.rotation) * len;
            this.trailCtx.save();
            this.trailCtx.strokeStyle = bulletColor;
            this.trailCtx.lineWidth = 8 * (stats ? stats.trailWidthMultiplier : 1);
            this.trailCtx.beginPath();
            this.trailCtx.moveTo(transform.x, transform.y);
            this.trailCtx.lineTo(endX, endY);
            this.trailCtx.stroke();
            this.trailCtx.restore();
            // Damage enemies along the line
            const ax = transform.x, ay = transform.y;
            const bx = endX, by = endY;
            const thickness = 12 * (stats ? stats.trailWidthMultiplier : 1);
            const idx = weapon.currentWeaponIndex;
            const bonus = weapon.damageBonus[idx] || 0;
            let rulerDmgResult = getDamage(config.damage, bonus);
            let baseRulerDmg = rulerDmgResult.damage;
            let isCrit = rulerDmgResult.isCrit;
            let pierceCount = 0;
            
            // Sort enemies by distance to player
            const enemiesHit = [];
            for (const e of this.entities) {
                if (!e.active || e === owner) continue;
                const eb = e.getComponent(EnemyBehavior);
                const tt = e.getComponent(Transform);
                const hp = e.getComponent(Health);
                if (!eb || !tt || !hp) continue;
                const dx = bx - ax, dy = by - ay;
                const t = Math.max(0, Math.min(1, ((tt.x - ax) * dx + (tt.y - ay) * dy) / (dx*dx + dy*dy + 1e-6)));
                const px = ax + dx * t, py = ay + dy * t;
                const d = Math.hypot(tt.x - px, tt.y - py);
                if (d <= thickness) {
                    const distToPlayer = Math.hypot(tt.x - ax, tt.y - ay);
                    enemiesHit.push({ e, hp, distToPlayer });
                }
            }
            
            enemiesHit.sort((a, b) => a.distToPlayer - b.distToPlayer);
            
            for (const hit of enemiesHit) {
                let dmg = baseRulerDmg;
                if (stats && stats.hasCalligrapherPassive) {
                    dmg *= (1 + pierceCount * 0.5); // 每次穿透伤害增加50%
                }
                hit.hp.current -= dmg;
                DamageTextSystem.addDamageText(hit.e.getComponent(Transform)!.x, hit.e.getComponent(Transform)!.y - 15, dmg, isCrit ? '#ff4444' : '#ffffff', isCrit);
                pierceCount++;
                if (hit.hp.current <= 0) {
                    this.handleEnemyDeath(hit.e, owner);
                }
            }
            return;
        }

        if (config.type === 'sniper') {
            const beam = new Entity();
            const range = config.range || 1200;
            const angle = transform.rotation;
            const endX = transform.x + Math.cos(angle) * range;
            const endY = transform.y + Math.sin(angle) * range;
            
            beam.addComponent(new Transform(transform.x, transform.y));
            beam.addComponent(new Renderable(bulletColor, 0, endX, endY, 'line', 5 * (stats ? stats.trailWidthMultiplier : 1)));
            beam.addComponent(new Projectile('sniper', config.damage, owner.id, 5));
            
            const beamProj = beam.getComponent(Projectile);
            if (beamProj) {
                const dmgResult = getDamage(beamProj.damage, 0);
                beamProj.damage = dmgResult.damage;
                beamProj.isCrit = dmgResult.isCrit;
                beamProj.reaperStrike = isReaperStrike;
            }
            this.addEntityCallback(beam);
            
            if (this.trailCtx) {
                setTimeout(() => {
                    if (this.trailCtx) {
                        this.trailCtx.save();
                        this.trailCtx.globalCompositeOperation = 'source-over';
                        this.trailCtx.beginPath();
                        this.trailCtx.moveTo(transform.x, transform.y);
                        this.trailCtx.lineTo(endX, endY);
                        this.trailCtx.strokeStyle = bulletColor;
                        this.trailCtx.lineWidth = 2 * (stats ? stats.trailWidthMultiplier : 1);
                        this.trailCtx.stroke();
                        this.trailCtx.restore();
                    }
                }, 0);
            }
            return;
        }

        if (config.type === 'melee') {
            const reach = (config.range || 80) * (stats ? stats.trailWidthMultiplier : 1);
            const halfArc = Math.PI * 0.35;
            const base = transform.rotation;
            let dmgResult = getDamage(config.damage, 0);
            let dmg = dmgResult.damage;
            let isCrit = dmgResult.isCrit;
            if (this.trailCtx) {
                this.trailCtx.save();
                this.trailCtx.strokeStyle = bulletColor;
                this.trailCtx.globalAlpha = 0.6;
                this.trailCtx.lineWidth = 6 * (stats ? stats.trailWidthMultiplier : 1);
                this.trailCtx.beginPath();
                this.trailCtx.arc(transform.x, transform.y, reach, base - halfArc, base + halfArc);
                this.trailCtx.stroke();
                this.trailCtx.restore();
            }
            for (const e of this.entities) {
                if (!e.active || e === owner) continue;
                const eb = e.getComponent(EnemyBehavior);
                const tt = e.getComponent(Transform);
                const hp = e.getComponent(Health);
                if (!eb || !tt || !hp) continue;
                const dx = tt.x - transform.x;
                const dy = tt.y - transform.y;
                const dist = Math.sqrt(dx*dx + dy*dy);
                if (dist <= reach + 15) {
                    let angleToEnemy = Math.atan2(dy, dx);
                    let angleDiff = angleToEnemy - base;
                    while (angleDiff <= -Math.PI) angleDiff += Math.PI * 2;
                    while (angleDiff > Math.PI) angleDiff -= Math.PI * 2;
                    if (Math.abs(angleDiff) <= halfArc) {
                        hp.current -= dmg;
                        DamageTextSystem.addDamageText(tt.x, tt.y - 15, dmg, isCrit ? '#ff4444' : '#ffffff', isCrit);
                        if (hp.current <= 0) this.handleEnemyDeath(e, owner);
                    }
                }
            }
            return;
        }

        const count = config.count + stats.bulletCountBonus;
        for (let i = 0; i < count; i++) {
            const spread = (Math.random() - 0.5) * config.spread * weapon.spreadMul;
            const angle = transform.rotation + spread;
            const bullet = BulletFactory.create(
                config,
                transform.x,
                transform.y,
                angle,
                bulletColor,
                owner.id,
                weapon.speedMul,
                stats.trailWidthMultiplier
            );
            const proj = bullet.getComponent(Projectile);
            if (proj) {
                const dmgResult = getDamage(proj.damage, 0);
                proj.damage = dmgResult.damage;
                proj.isCrit = dmgResult.isCrit;
                proj.reaperStrike = isReaperStrike;
                proj.pierceCount = weapon.pierceCount + stats.pierceBonus;
                if (config.type === 'rocket') {
                    proj.explosionRadiusScale = weapon.explosionRadiusScale;
                }
                if (config.type === 'chain') {
                    proj.pierceCount = 3;
                }
            }
            this.addEntityCallback(bullet);
        }
    }

    private switchWeapon(weapon: Weapon, index: number): void {
        if (!weapon.unlocked.has(index)) return;
        if (weapon.currentWeaponIndex !== index) {
            weapon.currentWeaponIndex = index;
            weapon.cooldown = 20; // Reset cooldown on switch
            console.log(`Switched to weapon: ${WEAPONS[index].name}`);
        }
    }

    private shoot(owner: Entity, weapon: Weapon, transform: Transform, ownerColor: string, stats?: PlayerStats): void {
        const config = weapon.config;
        if (!config) return;
        
        let frenzySpeedBonus = 0;
        if (stats) {
            const now = Date.now();
            stats.killFrenzyStacks = stats.killFrenzyStacks.filter(stack => stack.expireTime > now);
            for (const stack of stats.killFrenzyStacks) {
                frenzySpeedBonus += stack.amount;
            }
        }
        
        const baseFrMultiplier = stats ? weapon.fireRateMul / stats.fireRateMultiplier : weapon.fireRateMul;
        const finalFrMultiplier = baseFrMultiplier / (1 + frenzySpeedBonus);
        weapon.cooldown = Math.max(1, Math.round(config.fireRate * finalFrMultiplier));
        
        // 换弹灵感判定
        let inspLevel = 0;
        if ((weapon as any).inspirationLevel && (weapon as any).inspirationLevel > 0) {
            inspLevel = (weapon as any).inspirationLevel;
            (weapon as any).inspirationLevel = 0; // 消耗掉
        }

        let isReaperStrike = false;
        if (stats && stats.killReaperReady) {
            isReaperStrike = true;
            stats.killReaperReady = false; // 消耗掉
        }

        const getDamage = (baseDamage: number, weaponBonus: number): { damage: number, isCrit: boolean, bonusPierce: number } => {
            let dmg = baseDamage + weaponBonus;
            let isCrit = false;
            let bonusPierce = 0;
            if (stats) {
                // 应用基础伤害倍率
                dmg *= stats.damageMultiplier;
                
                // 溢出的移动速度转化为额外伤害倍率（每溢出 1 点速度增加 10% 伤害）
                if (stats.speedOverflow > 0) {
                    const extraMultiplier = 1.0 + (stats.speedOverflow * 0.10);
                    dmg *= extraMultiplier;
                }

                // 书法家被动伤害加成（每层2%）
                if (stats.hasCalligrapherPassive && stats.calligrapherDamageStacks > 0) {
                    dmg *= (1.0 + stats.calligrapherDamageStacks * 0.02);
                }
            }
            let critC = weapon.critChance + (stats ? stats.critChance : 0);
            let critM = weapon.critMultiplier + (stats ? (stats.critDamage - 1.5) : 0);

            // 收笔一击判定
            let isLastStrike = false;
            let lastStrikeLevel = 0;
            if (stats && owner.tags.has('player')) {
                lastStrikeLevel = stats.getSkillLevel('hit_last_strike');
                const idx = weapon.currentWeaponIndex;
                if (lastStrikeLevel > 0 && weapon.ammo[idx] === 1) {
                    isLastStrike = true;
                }
            }

            if (inspLevel > 0) {
                critC = 1.0; // 必定暴击
                const bonusDmg = inspLevel === 1 ? 1 : (inspLevel === 2 ? 2 : 3); // +100% / +200% / +300%
                dmg *= (1 + bonusDmg);
                if (inspLevel >= 3) {
                    bonusPierce = 1; // 3级才附带穿透
                }
            }

            if (isLastStrike) {
                critC = 1.0; // 必定暴击
                if (lastStrikeLevel >= 2) {
                    critM += 0.5; // +50% 暴击伤害
                }
                if (lastStrikeLevel >= 3) {
                    critM += 0.5; // 累计 +100% 暴击伤害
                    bonusPierce += 1; // 附带穿透
                }
            }

            if (isReaperStrike) {
                critC = 1.0; // 必定暴击
            }

            // 致命穿透 (crit_pierce) 转化判定：
            // 如果武器本身就是自带无限穿透的类型，致命穿透技能改为提供暴击伤害加成
            let critPierceBonusDamage = 0;
            if (stats && owner.tags.has('player')) {
                const pierceLevel = stats.getSkillLevel('crit_pierce');
                if (pierceLevel > 0) {
                    // 无限穿透类型或天生高穿透类型
                    const infinitePierceTypes = ['sniper', 'ruler', 'flamethrower', 'gravity', 'compass', 'melee'];
                    if (infinitePierceTypes.includes(config.type)) {
                        // 转化为暴击伤害加成: 30% / 60% / 100%
                        critPierceBonusDamage = pierceLevel === 1 ? 0.3 : (pierceLevel === 2 ? 0.6 : 1.0);
                        critM += critPierceBonusDamage;
                    }
                }
            }

            if (Math.random() < critC) {
                dmg = Math.floor(dmg * critM);
                isCrit = true;
            }
            return { damage: dmg, isCrit, bonusPierce };
        };
        
        // Set attack state for player
        if (owner.tags.has('player')) {
            // We now update attack state based on mouse down in handlePlayerInput
            // rather than a timeout here.
            
            // 数字板绘师：记录上一次攻击
            if (stats && stats.hasDigitalPassive) {
                stats.lastAttackConfig = config;
            }
        }
        
        // Determine bullet color
        let bulletColor = config.color;
        // All weapons except Pistol (0) should use player color
        if (config.id !== 0) {
            bulletColor = ownerColor;
        }

        // Ruler gun draws a direct line
        if (config.type === 'ruler' && this.trailCtx) {
            const len = 600;
            const endX = transform.x + Math.cos(transform.rotation) * len;
            const endY = transform.y + Math.sin(transform.rotation) * len;
            this.trailCtx.save();
            this.trailCtx.strokeStyle = ownerColor;
            this.trailCtx.lineWidth = 8 * (stats ? stats.trailWidthMultiplier : 1);
            this.trailCtx.beginPath();
            this.trailCtx.moveTo(transform.x, transform.y);
            this.trailCtx.lineTo(endX, endY);
            this.trailCtx.stroke();
            this.trailCtx.restore();
            // Damage enemies along the line
            const ax = transform.x, ay = transform.y;
            const bx = endX, by = endY;
            const thickness = 12 * (stats ? stats.trailWidthMultiplier : 1);
            const idx = weapon.currentWeaponIndex;
            const bonus = weapon.damageBonus[idx] || 0;
            let rulerDmgResult = getDamage(config.damage, bonus);
            let baseRulerDmg = rulerDmgResult.damage;
            let isCrit = rulerDmgResult.isCrit;
            let pierceCount = 0;
            
            // Sort enemies by distance to player
            const enemiesHit = [];
            for (const e of this.entities) {
                if (!e.active || e === owner) continue;
                const eb = e.getComponent(EnemyBehavior);
                const tt = e.getComponent(Transform);
                const hp = e.getComponent(Health);
                if (!eb || !tt || !hp) continue;
                const dx = bx - ax, dy = by - ay;
                const t = Math.max(0, Math.min(1, ((tt.x - ax) * dx + (tt.y - ay) * dy) / (dx*dx + dy*dy + 1e-6)));
                const px = ax + dx * t, py = ay + dy * t;
                const d = Math.hypot(tt.x - px, tt.y - py);
                if (d <= thickness) {
                    const distToPlayer = Math.hypot(tt.x - ax, tt.y - ay);
                    enemiesHit.push({ e, hp, distToPlayer });
                }
            }
            
            enemiesHit.sort((a, b) => a.distToPlayer - b.distToPlayer);
            
            for (const hit of enemiesHit) {
                let dmg = baseRulerDmg;
                if (stats && stats.hasCalligrapherPassive) {
                    dmg *= (1 + pierceCount * 0.5); // 每次穿透伤害增加50%
                }
                hit.hp.current -= dmg;
                DamageTextSystem.addDamageText(hit.e.getComponent(Transform)!.x, hit.e.getComponent(Transform)!.y - 15, dmg, isCrit ? '#ff4444' : '#ffffff', isCrit);
                pierceCount++;
                if (hit.hp.current <= 0) {
                    this.handleEnemyDeath(hit.e, owner);
                }
            }
            return;
        }

        // Ruler skill: one-shot straight line
        const sk = owner.getComponent(Skill);
        if (sk && sk.rulerArmed && this.trailCtx) {
            const len = 600;
            const endX = transform.x + Math.cos(transform.rotation) * len;
            const endY = transform.y + Math.sin(transform.rotation) * len;
            this.trailCtx.save();
            this.trailCtx.strokeStyle = ownerColor;
            this.trailCtx.lineWidth = 6;
            this.trailCtx.beginPath();
            this.trailCtx.moveTo(transform.x, transform.y);
            this.trailCtx.lineTo(endX, endY);
            this.trailCtx.stroke();
            this.trailCtx.restore();
            sk.rulerArmed = false;
            return;
        }

        // Sniper special logic (Raycast)
        if (config.type === 'sniper') {
            // Create a visual beam entity
            const beam = new Entity();
            
            // Calculate beam end point (very far away)
            const range = config.range || 1200;
            const angle = transform.rotation; // Use rotation directly
            const endX = transform.x + Math.cos(angle) * range;
            const endY = transform.y + Math.sin(angle) * range;
            
            // We use Transform for start point, and Renderable width/height for end point (as per RenderSystem logic)
            beam.addComponent(new Transform(transform.x, transform.y));
            // Store end coordinates in width/height for line drawing
            beam.addComponent(new Renderable(bulletColor, 0, endX, endY, 'line', 5 * (stats ? stats.trailWidthMultiplier : 1))); // Use bulletColor
            
            beam.addComponent(new Projectile('sniper', config.damage, owner.id, 5));
            const beamProj = beam.getComponent(Projectile);
            if (beamProj) {
                const idx = weapon.currentWeaponIndex;
                const bonus = weapon.damageBonus[idx] || 0;
                const dmgResult = getDamage(beamProj.damage, bonus);
                beamProj.damage = dmgResult.damage;
                beamProj.isCrit = dmgResult.isCrit;
                beamProj.pierceCount += dmgResult.bonusPierce;
                if (stats && stats.hasCalligrapherPassive) {
                    beamProj.calligrapherBonus = true;
                }
            }
            
            this.addEntityCallback(beam);
            
            // Draw Trail Line
            // Delay drawing the sniper trail line slightly so it happens AFTER the eraser 
            // has processed its death and stopped erasing.
            if (this.trailCtx) {
                // By deferring this to the end of the current event loop or next frame,
                // we ensure all CollisionSystem deaths are processed first.
                // Using setTimeout(..., 0) pushes this to the macro-task queue, 
                // which runs after the current frame's systems finish updating.
                setTimeout(() => {
                    if (this.trailCtx) {
                        this.trailCtx.save();
                        this.trailCtx.globalCompositeOperation = 'source-over';
                        this.trailCtx.beginPath();
                        this.trailCtx.moveTo(transform.x, transform.y);
                        this.trailCtx.lineTo(endX, endY);
                        this.trailCtx.strokeStyle = bulletColor;
                        this.trailCtx.lineWidth = 2 * (stats ? stats.trailWidthMultiplier : 1);
                        this.trailCtx.stroke();
                        this.trailCtx.restore();
                    }
                }, 0);
            }
            
            return;
        }

        // Melee：前方扇形近战打击
        if (config.type === 'melee') {
            const reach = (config.range || 80) * (stats ? stats.trailWidthMultiplier : 1);
            const halfArc = Math.PI * 0.35; // 约40度扇形
            const base = transform.rotation;
            const idx = weapon.currentWeaponIndex;
            const bonus = weapon.damageBonus[idx] || 0;
            let dmgResult = getDamage(config.damage, bonus);
            let dmg = dmgResult.damage;
            let isCrit = dmgResult.isCrit;
            // 视觉：在轨迹层画出短暂的弧线
            if (this.trailCtx) {
                this.trailCtx.save();
                this.trailCtx.strokeStyle = ownerColor;
                this.trailCtx.globalAlpha = 0.6;
                this.trailCtx.lineWidth = 6 * (stats ? stats.trailWidthMultiplier : 1);
                this.trailCtx.beginPath();
                this.trailCtx.arc(transform.x, transform.y, reach, base - halfArc, base + halfArc);
                this.trailCtx.stroke();
                this.trailCtx.restore();
            }
            // 命中判定
            for (const e of this.entities) {
                if (!e.active || e === owner) continue;
                const eb = e.getComponent(EnemyBehavior);
                const tt = e.getComponent(Transform);
                const hp = e.getComponent(Health);
                if (!eb || !tt || !hp) continue;
                const dx = tt.x - transform.x;
                const dy = tt.y - transform.y;
                const dist = Math.hypot(dx, dy);
                if (dist > reach) continue;
                const ang = Math.atan2(dy, dx);
                let diff = ang - base;
                while (diff > Math.PI) diff -= Math.PI * 2;
                while (diff < -Math.PI) diff += Math.PI * 2;
                if (Math.abs(diff) <= halfArc) {
                    hp.current -= dmg;
                    DamageTextSystem.addDamageText(tt.x, tt.y - 15, dmg, isCrit ? '#ff4444' : '#ffffff', isCrit);
                    // 轻微击退
                    const kb = 8;
                    tt.x += Math.cos(ang) * kb;
                    tt.y += Math.sin(ang) * kb;
                    if (hp.current <= 0) {
                        this.handleEnemyDeath(e, owner);
                    }
                }
            }
            return;
        }

        const count = config.count + (stats ? stats.bulletCountBonus : 0);
        for (let i = 0; i < count; i++) {
            const spread = (Math.random() - 0.5) * config.spread * weapon.spreadMul;
            const angle = transform.rotation + spread;
            
            // Create bullet entity
            const bullet = BulletFactory.create(
                config,
                transform.x,
                transform.y,
                angle,
                bulletColor, // Use bulletColor
                owner.id,
                weapon.speedMul,
                stats ? stats.trailWidthMultiplier : 1.0
            );
            const proj = bullet.getComponent(Projectile);
            if (proj) {
                const idx = weapon.currentWeaponIndex;
                const bonus = weapon.damageBonus[idx] || 0;
                const dmgResult = getDamage(proj.damage, bonus);
                proj.damage = dmgResult.damage;
                proj.isCrit = dmgResult.isCrit;
                proj.pierceCount = weapon.pierceCount + (stats ? stats.pierceBonus : 0) + dmgResult.bonusPierce;
                if (config.type === 'rocket') {
                    proj.explosionRadiusScale = weapon.explosionRadiusScale;
                }
                if (config.type === 'chain') {
                    proj.pierceCount = 3 + dmgResult.bonusPierce;
                }
                if (stats && stats.hasCalligrapherPassive) {
                    proj.calligrapherBonus = true;
                }
            }
            
            this.addEntityCallback(bullet);
        }
    }
    
    private startReload(player: Entity, weapon: Weapon, stats?: PlayerStats) {
        if (weapon.reloading) return;
        const cfg = weapon.config;
        if (!cfg) return;
        weapon.reloading = true;
        const reloadMul = stats ? weapon.reloadTimeMul / stats.reloadSpeedMultiplier : weapon.reloadTimeMul;
        const rt = Math.max(1, Math.floor(cfg.reloadTime * reloadMul));
        weapon.reloadTimer = rt;
        weapon.cooldown = rt;

        if (stats) {
            const transform = player.getComponent(Transform);
            if (!transform) return;

            // 1. 图钉禁锢 (reload_thumbtack)
            const thumbtackLevel = stats.getSkillLevel('reload_thumbtack');
            if (thumbtackLevel > 0) {
                // 将自身周围小范围内的所有敌人钉住 2/3/4 秒
                const radius = thumbtackLevel === 1 ? 150 : (thumbtackLevel === 2 ? 250 : 400);
                const duration = thumbtackLevel === 1 ? 120 : (thumbtackLevel === 2 ? 180 : 240); // 2/3/4 seconds
                for (const e of this.entities) {
                    if (!e.active || !e.hasComponent(EnemyBehavior)) continue;
                    const et = e.getComponent(Transform);
                    if (et) {
                        const dist = Math.hypot(et.x - transform.x, et.y - transform.y);
                        if (dist <= radius) {
                            const eb = e.getComponent(EnemyBehavior);
                            if (eb) eb.frozenFrames = duration;
                        }
                    }
                }
            }

            // 2. 颜料倾倒 (reload_pigment_dump)
            const pigmentLevel = stats.getSkillLevel('reload_pigment_dump');
            if (pigmentLevel > 0) {
                // 在脚下留下一摊毒水，持续 5 秒，造成基础伤害
                const radius = pigmentLevel === 1 ? 80 : 150;
                const damageMult = pigmentLevel >= 2 ? 1.5 : 1.0;
                const slowFactor = pigmentLevel >= 3 ? 0.5 : 1.0; // 0.5 意味着移速降低 50%
                const damagePerFrame = (cfg.damage * damageMult) / 30; // 假设每秒2次基础伤害？或者直接/30每帧伤害

                if (this.addEntityCallback) {
                    const puddleEntity = new Entity();
                    puddleEntity.addComponent(new Transform(transform.x, transform.y));
                    puddleEntity.addComponent(new Puddle(radius, 300, 300, damagePerFrame, slowFactor, 'rgba(128, 0, 128, 0.4)'));
                    puddleEntity.addComponent(new Renderable('rgba(128, 0, 128, 0.4)', radius, 0, 0, 'circle'));
                    this.addEntityCallback(puddleEntity);
                }
            }

            // 3. 圆规冲刺 (reload_compass_dash)
            const compassDashLevel = stats.getSkillLevel('reload_compass_dash');
            if (compassDashLevel > 0) {
                const idx = weapon.currentWeaponIndex;
                if (weapon.ammo[idx] <= 0) {
                    const pc = player.getComponent(PlayerControl);
                    if (pc) {
                        // 1级精确位移1个黑底像素格(100像素)，2/3级精确位移2个像素格(200像素)
                        // 极快速度：设置极短的帧数（3帧，即0.05秒），实现"唰"一下的瞬间冲刺
                        const isHighLevel = compassDashLevel >= 2;
                        pc.dashFrames = 3;
                        pc.dashSpeed = isHighLevel ? (200 / 3) : (100 / 3);
                        
                        // Determine dash direction from movement input or rotation
                        let dx = 0, dy = 0;
                        if (this.input.isKeyDown('w')) dy -= 1;
                        if (this.input.isKeyDown('s')) dy += 1;
                        if (this.input.isKeyDown('a')) dx -= 1;
                        if (this.input.isKeyDown('d')) dx += 1;
                        
                        if (dx === 0 && dy === 0) {
                            // If no input, dash towards mouse
                            dx = Math.cos(transform.rotation);
                            dy = Math.sin(transform.rotation);
                        } else {
                            const len = Math.hypot(dx, dy);
                            dx /= len; dy /= len;
                        }
                        
                        pc.dashDirX = dx;
                        pc.dashDirY = dy;
                        pc.dashInvincible = compassDashLevel >= 3;
                        
                        // 产生沿途 Puddle 造成伤害和减速 (半圆效果这里用一系列圆形 Puddle 模拟)
                        if (this.addEntityCallback) {
                            const slowFactor = compassDashLevel === 1 ? 0.7 : (compassDashLevel === 2 ? 0.5 : 0.2); // 30%, 50%, 80% reduction
                            
                            // 圈的大小也精确匹配格子大小（半径50即直径100为一个格子，半径100即直径200为两个格子）
                            const finalRadius = isHighLevel ? 100 : 50; 
                            const puddleEntity = new Entity();
                            // Transform 设置为 transform.x, transform.y (即玩家当前脚下)
                            puddleEntity.addComponent(new Transform(transform.x, transform.y));
                            puddleEntity.addComponent(new Puddle(finalRadius, 60, 60, cfg.damage / 10, slowFactor, 'rgba(0, 200, 255, 0.4)'));
                            puddleEntity.addComponent(new Renderable('rgba(0, 200, 255, 0.4)', finalRadius, 0, 0, 'circle'));
                            this.addEntityCallback(puddleEntity);
                        }
                    }
                }
            }

            // 4. 灵感爆发 (reload_inspiration)
            const inspirationLevel = stats.getSkillLevel('reload_inspiration');
            if (inspirationLevel > 0) {
                // Add a dynamic property to weapon to mark next shot as inspired
                (weapon as any).inspirationLevel = inspirationLevel;
            }
        }
    }

    private handleEnemyDeath(enemy: Entity, player: Entity): void {
        const eTransform = enemy.getComponent(Transform);
        const eRender = enemy.getComponent(Renderable);
        const x = eTransform ? eTransform.x : 0;
        const y = eTransform ? eTransform.y : 0;
        const color = eRender ? eRender.color : '#ffffff';
        DeathHandler.handleEnemyDeath(enemy, player, x, y, color, this.entities, this.addEntityCallback);
    }
}
