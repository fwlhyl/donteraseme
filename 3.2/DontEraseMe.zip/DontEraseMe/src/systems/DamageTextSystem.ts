import { System } from '../core/System';

interface DamageText {
    x: number;
    y: number;
    text: string;
    color: string;
    life: number;
    maxLife: number;
    velocityY: number;
}

export class DamageTextSystem extends System {
    private texts: DamageText[] = [];
    
    // Use a static instance for easy access from anywhere
    private static instance: DamageTextSystem;

    constructor(
        private ctx: CanvasRenderingContext2D,
        private camera: { x: number, y: number }
    ) {
        super();
        DamageTextSystem.instance = this;
    }

    public static addDamageText(x: number, y: number, damage: number, color: string = '#ff4444', isCrit: boolean = false, customText?: string) {
        if (!DamageTextSystem.instance) return;
        // Check global setting
        if ((window as any).gameInstance && (window as any).gameInstance.showDamageNumbers === false) return;
        
        let text = customText !== undefined ? customText : (isCrit ? `${Math.ceil(damage)}!` : `${Math.ceil(damage)}`);

        DamageTextSystem.instance.texts.push({
            x: x + (Math.random() * 20 - 10),
            y: y + (Math.random() * 10 - 5),
            text: text,
            color: color,
            life: 0.8,
            maxLife: 0.8,
            velocityY: -40
        });
    }

    public update(dt: number): void {
        if (this.texts.length === 0) return;

        this.ctx.save();
        // The Game camera shake is already applied in RenderSystem, 
        // but here we just use base camera. For simplicity, we just use -camera.x, -camera.y
        this.ctx.translate(-this.camera.x, -this.camera.y);

        for (let i = this.texts.length - 1; i >= 0; i--) {
            const t = this.texts[i];
            t.life -= dt;
            if (t.life <= 0) {
                this.texts.splice(i, 1);
                continue;
            }

            t.y += t.velocityY * dt;

            const alpha = Math.max(0, t.life / t.maxLife);
            this.ctx.globalAlpha = alpha;
            this.ctx.fillStyle = t.color;
            
            const size = t.text.includes('!') ? 24 : 18;
            this.ctx.font = `bold ${size}px Arial`;
            this.ctx.textAlign = 'center';
            this.ctx.textBaseline = 'middle';
            
            this.ctx.strokeStyle = 'rgba(0, 0, 0, 0.8)';
            this.ctx.lineWidth = 3;
            this.ctx.strokeText(t.text, t.x, t.y);
            this.ctx.fillText(t.text, t.x, t.y);
        }

        this.ctx.restore();
    }
}
