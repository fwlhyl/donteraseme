import { System } from '../core/System';
import { Entity } from '../core/Entity';
import { InputManager } from '../core/InputManager';
import { Transform } from '../components/Transform';
import { Skill } from '../components/Skill';
import { EnemyBehavior } from '../components/EnemyBehavior';
import { Health } from '../components/Health';
import { ParticleFactory } from '../entities/ParticleFactory';

import { Renderable } from '../components/Renderable';
import { Experience } from '../components/Experience';
import { Stunned } from '../components/Stunned';
import { Score } from '../components/Score';
import { ExperienceOrb } from '../components/ExperienceOrb';
import { PlayerStats } from '../components/PlayerStats';
import { DamageTextSystem } from './DamageTextSystem';

export class SkillSystem extends System {
    constructor(
        private input: InputManager,
        private trailCtx: CanvasRenderingContext2D,
        private camera: { x: number, y: number, shakeX: number, shakeY: number, shakeTimer: number },
        private addEntityCallback: (entity: Entity) => void
    ) {
        super();
        window.addEventListener('tool-select', (e: any) => {
            const id = e.detail?.id as ('curve'|'symmetry'|'eraser'|'pin'|'explosion');
            if (!id) return;
            for (const ent of this.entities) {
                if (!ent.tags.has('player')) continue;
                const sk = ent.getComponent(Skill);
                const ex = ent.getComponent(Experience);
                const lvl = ex ? ex.level : 0;
                const conf = this.getToolSettings(id);
                if (lvl < conf.unlock) {
                    window.dispatchEvent(new CustomEvent('announce', { detail: { text: `未解锁：${this.getToolName(id)} Lv${conf.unlock}` } }));
                    continue;
                }
                if (sk) {
                    sk.activeTool = id;
                    window.dispatchEvent(new CustomEvent('announce', { detail: { text: `已选择：${this.getToolName(id)}（F触发）` } }));
                }
            }
        });
    }

    public update(dt: number): void {
        // 1. Update Camera Shake
        if (this.camera.shakeTimer > 0) {
            this.camera.shakeTimer -= dt;
            if (this.camera.shakeTimer <= 0) {
                this.camera.shakeX = 0;
                this.camera.shakeY = 0;
            } else {
                this.camera.shakeX = (Math.random() - 0.5) * 20;
                this.camera.shakeY = (Math.random() - 0.5) * 20;
            }
        }

        // 2. Handle Skill Logic
        for (const entity of this.entities) {
            const skill = entity.getComponent(Skill);
            const transform = entity.getComponent(Transform);
            const renderable = entity.getComponent(Renderable);
            const exp = entity.getComponent(Experience);
            const stats = entity.getComponent(PlayerStats);

            if (stats && stats.characterId === 'classical' && !stats.hasClassicalShield) {
                if (stats.shieldCooldownFrames > 0) {
                    stats.shieldCooldownFrames--;
                    if (stats.shieldCooldownFrames <= 0) {
                        stats.hasClassicalShield = true;
                        window.dispatchEvent(new CustomEvent('announce', { detail: { text: `厚涂护盾已就绪！` } }));
                    }
                }
            }

            if (stats) {
                // defense_shield cooldown
                if (!stats.hasOrigamiShield && stats.hasSkill('defense_shield')) {
                    if (stats.origamiShieldCooldownFrames > 0) {
                        stats.origamiShieldCooldownFrames--;
                    } else {
                        stats.hasOrigamiShield = true;
                        window.dispatchEvent(new CustomEvent('announce', { detail: { text: `折纸盾牌已生成！` } }));
                    }
                }

                // defense_dummy cooldown
                if (stats.dummyCooldownFrames > 0) {
                    stats.dummyCooldownFrames--;
                }

                // defense_desperate_explosion cooldown
                if (stats.explosionCooldownFrames > 0) {
                    stats.explosionCooldownFrames--;
                }

                if (stats.hedgehogCooldownFrames > 0) {
                    stats.hedgehogCooldownFrames--;
                }
            }

            if (!skill || !transform) continue;

            // Reduce cooldown
            if (skill.cooldown > 0) {
                skill.cooldown -= 1; // Decrement per frame (approx 60fps)
            }

            // Shared tool cooldown
            if (skill.toolCooldown > 0) skill.toolCooldown -= 1;
            
            // Unified tool trigger: F
            if (this.input.isKeyDown('f') || this.input.isKeyDown('F')) {
                const level = exp?.level ?? 0;
                if (skill.activeTool === 'curve') {
                    const conf = this.getToolSettings('curve');
                    if (level < conf.unlock) {
                        if (skill.toolCooldown <= 0) {
                            window.dispatchEvent(new CustomEvent('announce', { detail: { text: `未解锁：画圆 Lv${conf.unlock}` } }));
                            skill.toolCooldown = 45;
                        }
                    } else if (skill.toolCooldown <= 0) {
                        const mx = this.input.mouse.x + this.camera.x;
                        const my = this.input.mouse.y + this.camera.y;
                        const r = Math.max(12, Math.hypot(mx - transform.x, my - transform.y));
                        this.trailCtx.save();
                        this.trailCtx.strokeStyle = renderable ? renderable.color : '#ffffff';
                        this.trailCtx.lineWidth = 6;
                        this.trailCtx.beginPath();
                        this.trailCtx.arc(transform.x, transform.y, r, 0, Math.PI * 2);
                        this.trailCtx.stroke();
                        this.trailCtx.restore();
                        // Damage enemies touching the ring at the instant
                        const thickness = 12;
                        for (const target of this.entities) {
                            if (!target.active || target.tags.has('player')) continue;
                            const eb = target.getComponent(EnemyBehavior);
                            const tt = target.getComponent(Transform);
                            const hp = target.getComponent(Health);
                            if (!eb || !tt || !hp) continue;
                            const d = Math.hypot(tt.x - transform.x, tt.y - transform.y);
                            if (Math.abs(d - r) <= thickness) {
                                hp.current -= 40;
                                if (hp.current <= 0) {
                                    target.active = false;
                                    const exp = entity.getComponent(Experience);
                                    if (exp && this.addEntityCallback) {
                                        const orb = new Entity();
                                        orb.tags.add('xp_orb');
                                        orb.addComponent(new Transform(tt.x, tt.y));
                                        orb.addComponent(new ExperienceOrb(20));
                                        orb.addComponent(new Renderable('#00ff00', 6, 0, 0, 'diamond'));
                        this.addEntityCallback(orb);
                                    }
                                    const score = entity.getComponent(Score);
                                    if (score) {
                                        score.value += 10;
                                        score.coins += 5;
                                    }
                                }
                            }
                        }
                        skill.curveStage = 0;
                        skill.toolCooldown = conf.cd;
                        window.dispatchEvent(new CustomEvent('announce', { detail: { text: `画圆（命中伤害）` } }));
                    }
                } else if (skill.activeTool === 'symmetry') {
                    const conf = this.getToolSettings('symmetry');
                    if (level < conf.unlock) {
                        if (skill.toolCooldown <= 0) {
                            window.dispatchEvent(new CustomEvent('announce', { detail: { text: `未解锁：对称镜像 Lv${conf.unlock}` } }));
                            skill.toolCooldown = 45;
                        }
                    } else if (skill.toolCooldown <= 0) {
                        skill.symmetryFrames = 180;
                        skill.symmetryAxisX = transform.x;
                        skill.toolCooldown = conf.cd;
                        window.dispatchEvent(new CustomEvent('announce', { detail: { text: `对称镜像启动` } }));
                    }
                } else if (skill.activeTool === 'eraser') {
                    const conf = this.getToolSettings('eraser');
                    if (level < conf.unlock) {
                        if (skill.toolCooldown <= 0) {
                            window.dispatchEvent(new CustomEvent('announce', { detail: { text: `未解锁：橡皮盾 Lv${conf.unlock}` } }));
                            skill.toolCooldown = 45;
                        }
                    } else if (skill.toolCooldown <= 0) {
                        skill.eraserShieldFrames = 240;
                        skill.toolCooldown = conf.cd;
                        window.dispatchEvent(new CustomEvent('announce', { detail: { text: `橡皮盾开启` } }));
                    }
                } else if (skill.activeTool === 'pin') {
                    const conf = this.getToolSettings('pin');
                    if (level < conf.unlock) {
                        if (skill.toolCooldown <= 0) {
                            window.dispatchEvent(new CustomEvent('announce', { detail: { text: `未解锁：定点钉住 Lv${conf.unlock}` } }));
                            skill.toolCooldown = 45;
                        }
                    } else if (skill.toolCooldown <= 0) {
                        const radius = 220;
                        for (const target of this.entities) {
                            if (!target.active || target === entity) continue;
                            const eb = target.getComponent(EnemyBehavior);
                            const tt = target.getComponent(Transform);
                            if (!eb || !tt) continue;
                            const d = Math.hypot(tt.x - transform.x, tt.y - transform.y);
                            if (d <= radius) {
                                target.addComponent(new Stunned(120));
                            }
                        }
                        skill.toolCooldown = conf.cd;
                        window.dispatchEvent(new CustomEvent('announce', { detail: { text: `定点钉住` } }));
                    }
                } else if (skill.activeTool === 'explosion') {
                    const conf = this.getToolSettings('explosion');
                    if (level < conf.unlock) {
                        if (skill.toolCooldown <= 0) {
                            window.dispatchEvent(new CustomEvent('announce', { detail: { text: `未解锁：爆炸 Lv${conf.unlock}` } }));
                            skill.toolCooldown = 45;
                        }
                    } else if (skill.toolCooldown <= 0) {
                        const prev = skill.cooldown;
                        this.activateSkill(entity, skill, transform, renderable ? renderable.color : '#ffffff');
                        skill.cooldown = prev; // keep Space cooldown unaffected; use tools' shared cooldown
                        skill.toolCooldown = conf.cd;
                        window.dispatchEvent(new CustomEvent('announce', { detail: { text: `爆炸` } }));
                    }
                }
            }

            // Per-frame tool effects
            if (skill.symmetryFrames > 0 && renderable) {
                // Decrement frames and draw mirrored trail point
                skill.symmetryFrames -= 1;
                const mx = skill.symmetryAxisX - (transform.x - skill.symmetryAxisX);
                this.trailCtx.save();
                this.trailCtx.globalAlpha = 0.6;
                this.trailCtx.fillStyle = renderable.color;
                this.trailCtx.beginPath();
                this.trailCtx.arc(mx, transform.y, 6, 0, Math.PI * 2);
                this.trailCtx.fill();
                this.trailCtx.restore();
                // Record latest mirrored position for teleport
                skill.symmetryLastX = mx;
                skill.symmetryLastY = transform.y;
                // When timer ends, teleport player to the end of mirrored path
                if (skill.symmetryFrames === 0) {
                    transform.x = skill.symmetryLastX;
                    transform.y = skill.symmetryLastY;
                    window.dispatchEvent(new CustomEvent('announce', { detail: { text: `镜像位移` } }));
                }
            }
            if (skill.eraserShieldFrames > 0) {
                skill.eraserShieldFrames -= 1;
                this.trailCtx.save();
                this.trailCtx.globalCompositeOperation = 'destination-out';
                this.trailCtx.beginPath();
                this.trailCtx.arc(transform.x, transform.y, 60, 0, Math.PI * 2);
                this.trailCtx.fillStyle = 'rgba(0,0,0,1)';
                this.trailCtx.fill();
                this.trailCtx.restore();
            }

            // Check Input（Space爆炸已移除，保留Tab圆盘的爆炸 via F）
        }
    }

    private getToolName(id: 'curve'|'symmetry'|'eraser'|'pin'|'explosion'): string {
        if (id === 'curve') return '画圆';
        if (id === 'symmetry') return '对称镜像';
        if (id === 'eraser') return '橡皮盾';
        if (id === 'explosion') return '爆炸';
        return '定点钉住';
    }

    private getToolSettings(id: 'curve'|'pin'|'symmetry'|'eraser'|'explosion'): { unlock: number, cd: number } {
        if (id === 'curve') return { unlock: 10, cd: 300 };      // 5s
        if (id === 'pin') return { unlock: 15, cd: 480 };        // 8s
        if (id === 'symmetry') return { unlock: 20, cd: 660 };   // 11s
        if (id === 'eraser') return { unlock: 25, cd: 840 };     // 14s
        return { unlock: 30, cd: 1020 };                         // explosion 17s
    }

    private activateSkill(player: Entity, skill: Skill, transform: Transform, color: string): void {
        skill.cooldown = skill.maxCooldown;
        
        // 1. Visual Effect: Splatter on Trail Canvas (Player Color)
        // User: "Explosion skill player itself leaves no trace".
        // Wait: "Explosion skill player no trace... and enemy traces are red".
        // Re-reading: "5: Player's explosion skill needs to be visible... form round explosion ink effect... enemies receiving damage also leave explosion ink effect."
        // User Complaint 2: "Explosion skill player itself no trace".
        // So I MUST draw player trace.
        this.drawSplatter(transform.x, transform.y, color);

        // 2. Gameplay Effect: Damage Enemies
        // We need to iterate ALL entities to find enemies.
        // Since this.entities contains ALL entities in the game (as registered in Game.ts), we can iterate.
        for (const target of this.entities) {
            if (!target.active || target === player) continue;
            
            const enemy = target.getComponent(EnemyBehavior);
            const targetTransform = target.getComponent(Transform);
            const health = target.getComponent(Health);

            if (enemy && targetTransform) {
                const dist = Math.hypot(transform.x - targetTransform.x, transform.y - targetTransform.y);
                
                if (dist < skill.radius + 20) { // +20 for enemy radius approximation
                    // Apply Damage
                    if (health) {
                        health.current -= skill.damage;
                        DamageTextSystem.addDamageText(targetTransform.x, targetTransform.y - 15, skill.damage, '#ffffff', false);
                        if (health.current <= 0) {
                            target.active = false;
                            
                            // 增加金币和分数
                            const score = player.getComponent(Score);
                            const stats = player.getComponent(PlayerStats);
                            if (score) {
                                score.value += 10;
                                const t = enemy.type || 'chaser';
                                let baseGold = 1;
                                if (t === 'boss') baseGold = 100;
                                else if (t !== 'chaser') baseGold = 5;
                                
                                let goldMultiplier = 1;
                                if (stats) {
                                    if (stats.characterId === 'collector') {
                                        goldMultiplier += stats.survivalTime * 0.005;
                                    }
                                    const finalGold = Math.ceil(baseGold * goldMultiplier);
                                    score.coins += finalGold;
                                    stats.gold += finalGold;
                                } else {
                                    score.coins += baseGold;
                                }
                            }
                            const exp = player.getComponent(Experience);
                                    if (exp && this.addEntityCallback) {
                                        const orb = new Entity();
                                        orb.tags.add('xp_orb');
                                        orb.addComponent(new Transform(transform.x, transform.y));
                                        orb.addComponent(new ExperienceOrb(20));
                                        orb.addComponent(new Renderable('#00ff00', 6, 0, 0, 'diamond'));
                                this.addEntityCallback(orb);
                                    }
                            
                            // Spawn Particles
                            const particles = ParticleFactory.createExplosion(
                                targetTransform.x, 
                                targetTransform.y, 
                                '#ff0000', // Enemy color usually
                                15 // Count
                            );
                            particles.forEach(p => this.addEntityCallback(p));
                            
                            // Draw Blood on Trail Canvas (Enemy Color)
                            // User: "Explosion skill... enemy leaves explosion ink marks"
                            // User: "Enemies traces are red, should be enemy color".
                            // I used '#ff0000' hardcoded.
                            const enemyRender = target.getComponent(Renderable);
                            const enemyColor = enemyRender ? enemyRender.color : '#ff0000';
                            
                            this.drawBlood(targetTransform.x, targetTransform.y, enemyColor);
                            
                            // Draw Splatter for enemy death by skill
                            // this.drawSplatter(targetTransform.x, targetTransform.y, '#ff0000'); // Redundant if drawBlood does it?
                        }
                    }
                }
            }
        }

        // 3. Camera Shake
        this.camera.shakeTimer = 0.2; // 0.2 seconds
    }

    // dash removed

    private drawSplatter(x: number, y: number, color: string): void {
        const count = 20 + Math.random() * 10;
        
        this.trailCtx.save();
        this.trailCtx.fillStyle = color;
        this.trailCtx.globalAlpha = 0.8;
        
        for (let i = 0; i < count; i++) {
            const angle = Math.random() * Math.PI * 2;
            const dist = Math.random() * 150; // explosion radius
            const size = 5 + Math.random() * 20;
            
            const sx = x + Math.cos(angle) * dist;
            const sy = y + Math.sin(angle) * dist;

            this.trailCtx.beginPath();
            this.trailCtx.arc(sx, sy, size, 0, Math.PI * 2);
            this.trailCtx.fill();
            
            // Draw connecting lines
            this.trailCtx.beginPath();
            this.trailCtx.moveTo(x, y);
            this.trailCtx.lineTo(sx, sy);
            this.trailCtx.strokeStyle = color;
            this.trailCtx.lineWidth = size / 2;
            this.trailCtx.stroke();
        }
        this.trailCtx.restore();
    }

    private drawBlood(x: number, y: number, color: string): void {
        const drops = 5 + Math.random() * 5;
        this.trailCtx.save();
        this.trailCtx.fillStyle = color;
        this.trailCtx.globalAlpha = 0.6;
        
        for(let i=0; i<drops; i++) {
            const angle = Math.random() * Math.PI * 2;
            const dist = Math.random() * 25; 
            const radius = 5 + Math.random() * 12; 
            
            this.trailCtx.beginPath();
            this.trailCtx.arc(x + Math.cos(angle)*dist, y + Math.sin(angle)*dist, radius, 0, Math.PI*2);
            this.trailCtx.fill();
        }
        this.trailCtx.restore();
    }
}
