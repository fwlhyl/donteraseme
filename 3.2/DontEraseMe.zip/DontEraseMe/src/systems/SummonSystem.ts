import { System } from '../core/System';
import { Entity } from '../core/Entity';
import { Transform } from '../components/Transform';
import { Velocity } from '../components/Velocity';
import { Renderable } from '../components/Renderable';
import { PlayerStats } from '../components/PlayerStats';
import { Summon } from '../components/Summon';
import type { SummonType } from '../components/Summon';
import { EnemyBehavior } from '../components/EnemyBehavior';
import { Health } from '../components/Health';
import { Projectile } from '../components/Projectile';
import { ParticleFactory } from '../entities/ParticleFactory';
import { DamageTextSystem } from './DamageTextSystem';

export class SummonSystem extends System {
    private addEntityCallback: (entity: Entity) => void;

    constructor(addEntityCallback: (entity: Entity) => void) {
        super();
        this.addEntityCallback = addEntityCallback;
    }

    public update(dt: number): void {
        const players = Array.from(this.entities).filter(e => e.tags.has('player'));
        if (players.length === 0) return;
        const player = players[0];
        const pStats = player.getComponent(PlayerStats);
        const pTransform = player.getComponent(Transform);
        if (!pStats || !pTransform) return;

        this.syncSummons(player, pStats, pTransform);
        this.updateSummons(player, pTransform, dt);
    }

    private syncSummons(player: Entity, stats: PlayerStats, pTransform: Transform): void {
        const currentSummons = Array.from(this.entities).filter(e => e.hasComponent(Summon) && e.getComponent(Summon)!.ownerId === player.id);
        
        // 1. Stickman (火柴人助手)
        const stickmanLevel = stats.getSkillLevel('summon_stickman');
        const expectedStickmen = stickmanLevel > 0 ? (stickmanLevel >= 2 ? 2 : 1) : 0;
        this.balanceSummons(currentSummons, player, 'stickman', expectedStickmen, stickmanLevel, pTransform);

        // 2. Palette (调色盘卫星)
        const paletteLevel = stats.getSkillLevel('summon_palette');
        const expectedPalettes = paletteLevel > 0 ? (paletteLevel === 1 ? 2 : (paletteLevel === 2 ? 3 : 4)) : 0;
        this.balanceSummons(currentSummons, player, 'palette', expectedPalettes, paletteLevel, pTransform);

        // 3. Scythe (吸血镰刀)
        const scytheLevel = stats.getSkillLevel('summon_scythe');
        const expectedScythes = scytheLevel > 0 ? 1 : 0;
        this.balanceSummons(currentSummons, player, 'scythe', expectedScythes, scytheLevel, pTransform);

        // 4. Drone (无人机)
        const droneLevel = stats.getSkillLevel('summon_drone');
        const expectedDrones = droneLevel > 0 ? (droneLevel >= 2 ? 2 : 1) : 0;
        this.balanceSummons(currentSummons, player, 'drone', expectedDrones, droneLevel, pTransform);

        // 5. Behemoth (护卫巨兽) - 仅存在1只，1/2级死亡后180秒复活，3级60秒复活
        const behemothLevel = stats.getSkillLevel('summon_behemoth');
        const expectedBehemoths = behemothLevel > 0 ? 1 : 0;
        this.balanceSummons(currentSummons, player, 'behemoth', expectedBehemoths, behemothLevel, pTransform);
    }

    private balanceSummons(currentSummons: Entity[], player: Entity, type: SummonType, expectedCount: number, level: number, pTransform: Transform): void {
        const typeSummons = currentSummons.filter(e => e.getComponent(Summon)!.type === type);
        
        const countChanged = typeSummons.length !== expectedCount;

        // Remove excess
        while (typeSummons.length > expectedCount) {
            const e = typeSummons.pop()!;
            e.active = false;
        }

        // Update levels and angles for existing
        for (let i = 0; i < typeSummons.length; i++) {
            const sum = typeSummons[i].getComponent(Summon)!;
            sum.level = level;
            sum.index = i;
            if (type === 'palette' || type === 'scythe') {
                if (countChanged) {
                    sum.angle = (i / expectedCount) * Math.PI * 2; // Distribute evenly only when count changes
                }
                if (type === 'palette') sum.speed = level >= 3 ? 3 : 1.5;
                if (type === 'scythe') sum.distance = level >= 2 ? 120 : 80;
            }
            if (type === 'stickman') {
                sum.maxFireTimer = level >= 3 ? 30 : 60;
                sum.distance = 60 + i * 20;
            }
            if (type === 'drone') {
                sum.maxFireTimer = level >= 3 ? 40 : 80;
            }
            if (type === 'behemoth') {
                const hp = typeSummons[i].getComponent(Health);
                if (hp) {
                    const expectedMax = level >= 2 ? 2000 : 1000;
                    if (hp.max < expectedMax) {
                        const diff = expectedMax - hp.max;
                        hp.max = expectedMax;
                        hp.current += diff;
                    }
                }
            }
        }

        // Add missing
        while (typeSummons.length < expectedCount) {
            const i = typeSummons.length;
            const newSummon = this.createSummon(player, type, level, i, expectedCount, pTransform);
            typeSummons.push(newSummon);
            this.addEntityCallback(newSummon);
        }
    }

    private createSummon(player: Entity, type: SummonType, level: number, index: number, total: number, pTransform: Transform): Entity {
        const entity = new Entity();
        entity.tags.add('summon');
        
        let angle = 0;
        let distance = 50;
        let speed = 0;
        let maxFireTimer = 60;

        if (type === 'stickman') {
            distance = 60 + index * 20;
            maxFireTimer = level >= 3 ? 30 : 60;
            entity.addComponent(new Renderable('#ffffff', 0, 15, 30, 'rect')); // Simple stickman placeholder
        } else if (type === 'palette') {
            angle = (index / total) * Math.PI * 2;
            distance = 80;
            speed = level >= 3 ? 3 : 1.5; // rad per second roughly
            entity.addComponent(new Renderable('#ff8800', 0, 20, 16, 'rect')); // Orange palette satellite
        } else if (type === 'scythe') {
            angle = 0;
            distance = level >= 2 ? 120 : 80;
            speed = 2;
            entity.addComponent(new Renderable('#aa0000', 0, 30, 10, 'rect')); // Scythe placeholder
        } else if (type === 'drone') {
            distance = 50;
            maxFireTimer = level >= 3 ? 40 : 80;
            // 设定半径15，使用三角形绘制
            entity.addComponent(new Renderable('#00ffff', 15, 0, 0, 'triangle'));
        } else if (type === 'behemoth') {
            distance = 100;
            entity.addComponent(new Renderable('#8b4513', 40, 0, 0, 'circle')); // Clay behemoth
            const hp = level >= 2 ? 2000 : 1000;
            entity.addComponent(new Health(hp));
        }

        entity.addComponent(new Transform(pTransform.x, pTransform.y));
        entity.addComponent(new Velocity(0, 0, 0, 0.9));
        entity.addComponent(new Summon(type, player.id, level, index, angle, distance, speed, 0, maxFireTimer));

        return entity;
    }

    private updateSummons(player: Entity, pTransform: Transform, dt: number): void {
        const stats = player.getComponent(PlayerStats);
        if (!stats) return;

        const summons = Array.from(this.entities).filter(e => e.hasComponent(Summon) && e.getComponent(Summon)!.ownerId === player.id);
        const enemies = Array.from(this.entities).filter(e => e.tags.has('enemy') && e.hasComponent(Health));

        for (const entity of summons) {
            const summon = entity.getComponent(Summon)!;
            const sTransform = entity.getComponent(Transform)!;
            const sVel = entity.getComponent(Velocity);

            if (summon.type === 'palette' || summon.type === 'scythe') {
                // Orbiting summons
                summon.angle += summon.speed * dt;
                if (summon.type === 'scythe') {
                    summon.distance = summon.level >= 2 ? 120 : 80;
                    // Make scythe rotate around its own center
                    sTransform.rotation += summon.speed * dt * 2;
                } else if (summon.type === 'palette') {
                    // Make palette rotate around its own center
                    sTransform.rotation += summon.speed * dt * 1.5;
                }
                const targetX = pTransform.x + Math.cos(summon.angle) * summon.distance;
                const targetY = pTransform.y + Math.sin(summon.angle) * summon.distance;
                
                sTransform.x = targetX;
                sTransform.y = targetY;

                // Collision damage
                const radius = summon.type === 'palette' ? 12 : 20;
                const damage = summon.type === 'palette' ? 10 * stats.damageMultiplier : 20 * stats.damageMultiplier;
                
                for (const enemy of enemies) {
                    const eTransform = enemy.getComponent(Transform);
                    const eHealth = enemy.getComponent(Health);
                    if (!eTransform || !eHealth) continue;

                    const dx = eTransform.x - sTransform.x;
                    const dy = eTransform.y - sTransform.y;
                    const distSq = dx*dx + dy*dy;

                    if (distSq < (radius + 20) * (radius + 20)) { // Assuming enemy radius ~20
                        if (!enemy.hasComponent(Velocity)) continue; // quick active check
                        // deal damage, limit hit rate using a cooldown? For simplicity, we just apply it
                        // Better to only hit if we haven't hit this frame. Actually this would hit every frame and instantly kill.
                        // Let's add a simple cooldown check for orbiting damage.
                        if (!entity.tags.has(`hit_${enemy.id}`)) {
                            eHealth.current -= damage;
                            DamageTextSystem.addDamageText(eTransform.x, eTransform.y, Math.floor(damage), '#ff0000', false);
                            entity.tags.add(`hit_${enemy.id}`);
                            setTimeout(() => {
                                if (entity) entity.tags.delete(`hit_${enemy.id}`);
                            }, 500); // Hit same enemy every 0.5s

                            if (summon.type === 'scythe') {
                                const heal = summon.level >= 3 ? 2 : 1;
                                const pHealth = player.getComponent(Health);
                                if (pHealth) {
                                    pHealth.current = Math.min(pHealth.max, pHealth.current + heal);
                                    DamageTextSystem.addDamageText(pTransform.x, pTransform.y, heal, '#00ff00', false);
                                }
                                if (summon.level >= 3) {
                                    // Apply grievous wounds (corrosive stacks or simply double damage taken effect)
                                    // We will use corrosiveStacks as a proxy for "grievous wounds" taking more damage
                                    const eBehavior = enemy.getComponent(EnemyBehavior);
                                    if (eBehavior) {
                                        eBehavior.corrosiveStacks = Math.min(10, (eBehavior.corrosiveStacks || 0) + 5);
                                        if (eBehavior.corrosiveFactor === 0) {
                                            eBehavior.corrosiveFactor = 0.1; // Default 10% per stack for grievous wounds
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            } else if (summon.type === 'stickman' || summon.type === 'drone') {
                // Follow player loosely
                const followOffsetX = summon.type === 'stickman' ? -summon.distance : summon.distance;
                const followOffsetY = (summon.index % 2 === 0 ? 1 : -1) * 30;
                
                const targetX = pTransform.x + followOffsetX;
                const targetY = pTransform.y + followOffsetY;

                const dx = targetX - sTransform.x;
                const dy = targetY - sTransform.y;
                
                if (sVel) {
                    sVel.x += dx * 0.05;
                    sVel.y += dy * 0.05;
                    
                    // Cap speed
                    const speed = Math.sqrt(sVel.x*sVel.x + sVel.y*sVel.y);
                    if (speed > 8) {
                        sVel.x = (sVel.x / speed) * 8;
                        sVel.y = (sVel.y / speed) * 8;
                    }
                    
                    // Rotate drone to face its movement direction
                    if (speed > 0.1) {
                        sTransform.rotation = Math.atan2(sVel.y, sVel.x) + Math.PI / 2;
                    }
                }

                // Shooting
                summon.fireTimer--;
                if (summon.fireTimer <= 0) {
                    summon.fireTimer = summon.maxFireTimer;
                    this.fireSummonProjectile(summon, sTransform, enemies, stats);
                }
            } else if (summon.type === 'behemoth') {
                // Behemoth rushes to the enemy closest to the player
                let targetX = pTransform.x;
                let targetY = pTransform.y;
                let foundEnemy = false;

                if (enemies.length > 0) {
                    let minDist = Infinity;
                    let nearestEnemy = null;
                    for (const enemy of enemies) {
                        const eT = enemy.getComponent(Transform);
                        if (!eT) continue;
                        const distSq = Math.pow(eT.x - pTransform.x, 2) + Math.pow(eT.y - pTransform.y, 2);
                        if (distSq < minDist) {
                            minDist = distSq;
                            nearestEnemy = eT;
                        }
                    }
                    // Only target if enemy is within a reasonable distance from player (e.g. 200)
                    if (nearestEnemy && minDist < 200 * 200) {
                        targetX = nearestEnemy.x;
                        targetY = nearestEnemy.y;
                        foundEnemy = true;
                    }
                }

                const dx = targetX - sTransform.x;
                const dy = targetY - sTransform.y;
                if (sVel) {
                    if (foundEnemy) {
                        // Rush towards enemy (slowed down)
                        sVel.x += dx * 0.003;
                        sVel.y += dy * 0.003;
                        const speed = Math.hypot(sVel.x, sVel.y);
                        if (speed > 4) {
                            sVel.x = (sVel.x / speed) * 4;
                            sVel.y = (sVel.y / speed) * 4;
                        }
                    } else {
                        // Soften acceleration when just following player
                        sVel.x += dx * 0.002;
                        sVel.y += dy * 0.002;
                        const speed = Math.hypot(sVel.x, sVel.y);
                        if (speed > 3) {
                            sVel.x = (sVel.x / speed) * 3;
                            sVel.y = (sVel.y / speed) * 3;
                        }
                    }
                }
                
                const bHealth = entity.getComponent(Health);
                const bRender = entity.getComponent(Renderable);
                
                if (summon.lifeTimer > 0) {
                    // It is dead, waiting to respawn
                    summon.lifeTimer -= dt;
                    if (sVel) { sVel.x = 0; sVel.y = 0; }
                    if (bRender) bRender.radius = 0; // Hide
                    
                    if (summon.lifeTimer <= 0) {
                        // Respawn
                        if (bHealth) bHealth.current = bHealth.max;
                        if (bRender) bRender.radius = 40; // Restore size
                        sTransform.x = pTransform.x;
                        sTransform.y = pTransform.y;
                    }
                } else {
                    if (bHealth && bHealth.current <= 0) {
                        // Die, start respawn timer based on level
                        summon.lifeTimer = summon.level >= 3 ? 60 : 180;
                    }
                }
            }
        }
    }

    private fireSummonProjectile(summon: Summon, sTransform: Transform, enemies: Entity[], stats: PlayerStats): void {
        if (enemies.length === 0) return;

        let target: Entity | null = null;
        let minDist = Infinity;

        if (summon.type === 'drone') {
            // Drone prioritizes 'eraser' enemies
            const erasers = enemies.filter(e => e.getComponent(EnemyBehavior)?.type === 'eraser');
            
            // 按照用户需求，无人机专门消灭橡皮擦敌人，如果没有橡皮擦敌人就不攻击
            if (erasers.length === 0) return;
            const targetList = erasers;
            
            for (const e of targetList) {
                const eT = e.getComponent(Transform);
                if (!eT) continue;
                const d = Math.pow(eT.x - sTransform.x, 2) + Math.pow(eT.y - sTransform.y, 2);
                if (d < minDist) {
                    minDist = d;
                    target = e;
                }
            }
        } else {
            // Stickman shoots nearest
            for (const e of enemies) {
                const eT = e.getComponent(Transform);
                if (!eT) continue;
                const d = Math.pow(eT.x - sTransform.x, 2) + Math.pow(eT.y - sTransform.y, 2);
                if (d < minDist) {
                    minDist = d;
                    target = e;
                }
            }
        }

        if (!target) return;

        const targetT = target.getComponent(Transform)!;
        const angle = Math.atan2(targetT.y - sTransform.y, targetT.x - sTransform.x);

        const bullet = new Entity();
        bullet.tags.add('player_bullet');
        bullet.addComponent(new Transform(sTransform.x, sTransform.y, angle));
        
        let damage = 5 * stats.damageMultiplier;
        let color = '#ffffff';
        let speed = 10;
        let radius = 4;

        if (summon.type === 'drone') {
            color = '#00ffff';
            damage = summon.level >= 3 ? 20 * stats.damageMultiplier : 10 * stats.damageMultiplier;
            speed = 15;
            if (summon.level >= 3) {
                bullet.tags.add('laser_guided'); // Pseudo tag for visual
                radius = 6;
            }
        }

        bullet.addComponent(new Velocity(Math.cos(angle) * speed, Math.sin(angle) * speed));
        bullet.addComponent(new Renderable(color, radius, 0, 0, 'circle'));
        bullet.addComponent(new Projectile('standard', damage, summon.ownerId, 60, 0, 1.0));

        this.addEntityCallback(bullet);
    }
}
