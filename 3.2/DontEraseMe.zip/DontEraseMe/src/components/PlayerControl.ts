import { Component } from '../core/Component';

export class PlayerControl extends Component {
    public dashFrames: number = 0;
    public dashSpeed: number = 0;
    public dashDirX: number = 0;
    public dashDirY: number = 0;
    public dashInvincible: boolean = false;
    
    // Marker component for player
    constructor(
        public speed: number = 3
    ) {
        super();
    }
}
