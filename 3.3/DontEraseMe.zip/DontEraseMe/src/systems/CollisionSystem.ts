import { System } from '../core/System';
import { Entity } from '../core/Entity';
import { Transform } from '../components/Transform';
import { Renderable } from '../components/Renderable';
import { Projectile } from '../components/Projectile';
import { EnemyBehavior } from '../components/EnemyBehavior';
import { Health } from '../components/Health';
import { PlayerControl } from '../components/PlayerControl';
import { ParticleFactory } from '../entities/ParticleFactory';
import { Velocity } from '../components/Velocity'; // Import Velocity
import { Score } from '../components/Score'; // Import Score
import { Experience } from '../components/Experience';
import { Skill } from '../components/Skill';
import { PlayerStats } from '../components/PlayerStats';
import { DamageTextSystem } from './DamageTextSystem';
import { WaterMark } from '../components/WaterMark';
import { InkCloud } from '../components/InkCloud';
import { ExperienceOrb } from '../components/ExperienceOrb';
import { DeathHandler } from './DeathHandler';
import { Puddle } from '../components/Puddle';
import { Paperclip } from '../components/Paperclip';
// removed Physics import
export class CollisionSystem extends System {
    constructor(
        private addEntityCallback?: (entity: Entity) => void,
        private trailCtx?: CanvasRenderingContext2D // Add trailCtx
    ) {
        super();
    }
    private frame: number = 0;
    private enemyContactCooldown: Map<string, number> = new Map();

    // Helper: Draw Blood / Splash
    private drawSplash(ctx: CanvasRenderingContext2D, x: number, y: number, color: string, radius: number) {
        // Only draw splash for explosions (Rocket or Skill) or if explicitly called for death?
        // User Requirement 1: "Only explosion effect (Weapon 4 and Explosion Skill) leaves traces on enemies."
        // Wait, "Weapon damage causes enemies to leave traces" -> User says "Actually should be ONLY explosion".
        // So regular bullets should NOT cause `drawSplash` on death?
        // Or maybe regular death doesn't leave a huge splash, just particles?
        // Re-reading: "Weapon damage causes enemies to leave traces, actually should only be explosion effect (Weapon 4 and Skill) that causes enemy to leave traces."
        // This implies:
        // 1. Regular bullet hit -> No trace (already true, drawSplash is on death).
        // 2. Regular bullet kill -> User says "Only explosion effect... causes enemy to leave traces".
        // So if I kill with pistol, NO splash on canvas?
        // If so, I should wrap `drawSplash` call in a check for weapon type.
        
        // But the code below calls `drawSplash` inside `if (eHealth.current <= 0)`.
        // I need to check `pData.type` there.
        
        const drops = 5 + Math.random() * 5;
        ctx.fillStyle = color;
        ctx.globalAlpha = 0.6;
        
        for(let i=0; i<drops; i++) {
            const angle = Math.random() * Math.PI * 2;
            const dist = Math.random() * radius;
            const r = 2 + Math.random() * (radius / 2);
            
            ctx.beginPath();
            ctx.arc(x + Math.cos(angle)*dist, y + Math.sin(angle)*dist, r, 0, Math.PI*2);
            ctx.fill();
        }
        ctx.globalAlpha = 1.0;
    }


    private handleEnemyDeath(enemy: Entity, player: Entity | null, x: number, y: number, color: string): void {
        DeathHandler.handleEnemyDeath(enemy, player, x, y, color, this.entities, this.addEntityCallback);
    }

    private handlePlayerHit(player: Entity, pTransform: Transform, sourceTransform: Transform) {
        const pStats = player.getComponent(PlayerStats);
        if (pStats && pStats.hasInkPassive && this.addEntityCallback) {
            // 水墨画家：受击喷射致盲水墨团，持续3秒，半径300
            const ink = new Entity();
            ink.addComponent(new Transform(pTransform.x, pTransform.y));
            ink.addComponent(new Renderable('rgba(0, 0, 0, 0.8)', 300, 0, 0, 'circle'));
            ink.addComponent(new InkCloud(300, 180, 'rgba(0, 0, 0, 0.8)'));
            this.addEntityCallback(ink);
            window.dispatchEvent(new CustomEvent('announce', { detail: { text: `墨染致盲！` } }));
        }

        // 防御/受击触发系：刺猬装甲 (defense_hedgehog)
        if (pStats) {
            const hedgehogLevel = pStats.getSkillLevel('defense_hedgehog');
            if (hedgehogLevel > 0 && pStats.hedgehogCooldownFrames <= 0 && this.addEntityCallback) {
                // 冷却时间: 3秒 (180帧), 2.5秒 (150帧), 2秒 (120帧)
                const cooldowns = [180, 150, 120];
                pStats.hedgehogCooldownFrames = cooldowns[hedgehogLevel - 1] || 180;

                const projCount = hedgehogLevel === 1 ? 8 : (hedgehogLevel === 2 ? 16 : 24);
                const projDamage = 20 * pStats.totalDamageMultiplier;
                const isPiercing = hedgehogLevel >= 3;
                
                for (let i = 0; i < projCount; i++) {
                    const angle = (Math.PI * 2 / projCount) * i;
                    const proj = new Entity();
                    proj.addComponent(new Transform(pTransform.x, pTransform.y));
                    proj.addComponent(new Renderable('#555555', 4, 0, 0, 'circle'));
                    proj.addComponent(new Velocity(Math.cos(angle) * 10, Math.sin(angle) * 10));
                    proj.addComponent(new Projectile('standard', projDamage, player.id, 60, isPiercing ? 999 : 1));
                    proj.tags.add('projectile');
                    this.addEntityCallback(proj);
                }
            }
        }
    }

    private applyDamageToPlayer(player: Entity, amount: number, pTransform: Transform, isBoss: boolean, sourceTransform: Transform): void {
        const pHealth = player.getComponent(Health);
        const pStats = player.getComponent(PlayerStats);
        if (!pHealth || !pStats) return;

        // 1. Classical Shield Check
        if (pStats.hasClassicalShield) {
            pStats.hasClassicalShield = false;
            pStats.shieldCooldownFrames = pStats.maxShieldCooldownFrames;
            DamageTextSystem.addDamageText(pTransform.x, pTransform.y - 20, 0, '#00ffff', true, "免疫!");
            window.dispatchEvent(new CustomEvent('announce', { detail: { text: `厚涂护盾破裂！` } }));
            pHealth.invincibleFrames = 60; // Give some i-frames anyway to prevent instant multi-hit
            this.handlePlayerHit(player, pTransform, sourceTransform);
            return;
        }

        // 2. Origami Shield Check (defense_shield)
        const shieldLevel = pStats.getSkillLevel('defense_shield');
        if (shieldLevel > 0 && pStats.hasOrigamiShield) {
            pStats.hasOrigamiShield = false;
            const cooldowns = [3600, 2700, 1800]; // 60s, 45s, 30s
            pStats.origamiShieldCooldownFrames = cooldowns[shieldLevel - 1] || 3600;
            DamageTextSystem.addDamageText(pTransform.x, pTransform.y - 20, 0, '#ffffff', true, "折纸盾!");
            window.dispatchEvent(new CustomEvent('announce', { detail: { text: `折纸盾牌破裂！` } }));
            pHealth.invincibleFrames = 60;
            
            if (shieldLevel >= 3 && this.addEntityCallback) {
                // 护盾破裂时发射追踪纸屑
                for (let i = 0; i < 8; i++) {
                    const angle = (Math.PI * 2 / 8) * i;
                    const proj = new Entity();
                    proj.addComponent(new Transform(pTransform.x, pTransform.y));
                    proj.addComponent(new Renderable('#dddddd', 6, 6, 6, 'rect'));
                    proj.addComponent(new Velocity(Math.cos(angle) * 8, Math.sin(angle) * 8));
                    // 给予较高的伤害和较长的存活时间以追踪
                    proj.addComponent(new Projectile('standard', 30 * pStats.totalDamageMultiplier, player.id, 120, 1));
                    proj.tags.add('projectile');
                    this.addEntityCallback(proj);
                }
            }
            this.handlePlayerHit(player, pTransform, sourceTransform);
            return;
        }

        // 3. Apply base damage
        let actualDamage = amount;
        pHealth.current -= actualDamage;
        DamageTextSystem.addDamageText(pTransform.x, pTransform.y - 15, actualDamage, '#ff0000', false);
        pHealth.invincibleFrames = 60; // 1 second of i-frames

        // 4. Ink Dummy (defense_dummy) Fatal Damage Prevention
        const dummyLevel = pStats.getSkillLevel('defense_dummy');
        if (pHealth.current <= 0 && dummyLevel > 0 && pStats.dummyCooldownFrames <= 0) {
            pHealth.current = 1; // Prevent death
            const cooldowns = [3600, 2700, 1800];
            pStats.dummyCooldownFrames = cooldowns[dummyLevel - 1] || 3600;
            pHealth.invincibleFrames = 180; // 3 seconds invincible
            pStats.speedMultiplier += 0.5; // temporary speed up
            pStats.dummySpeedBuffFrames = 180; // 3 seconds speed up buff
            window.dispatchEvent(new CustomEvent('announce', { detail: { text: `墨水替身触发！隐身加速3秒！` } }));
            DamageTextSystem.addDamageText(pTransform.x, pTransform.y - 30, 0, '#888888', true, "替身!");
            
            if (this.addEntityCallback) {
                const dummy = new Entity();
                dummy.addComponent(new Transform(pTransform.x, pTransform.y));
                dummy.addComponent(new Renderable('#444444', 20, 0, 0, 'circle'));
                dummy.addComponent(new Health(100)); // Give dummy some health
                // Add a special tag or component so enemies target it
                dummy.tags.add('ink_dummy');
                // Store the dummy's level to know if it should explode on death/expire
                const dummyBehavior = new EnemyBehavior('ink_dummy');
                dummyBehavior.lifeTimer = 180; // 3 seconds life (reverted)
                dummyBehavior.damageFactor = dummyLevel; // Store level here temporarily to use in EnemySystem
                dummy.addComponent(dummyBehavior);
                this.addEntityCallback(dummy);
            }
        }

        // 5. Desperate Explosion (defense_desperate_explosion)
        const exploLevel = pStats.getSkillLevel('defense_desperate_explosion');
        // Add a debug log to track cooldowns
        if (pHealth.current / pStats.maxHp <= 0.20 && exploLevel > 0 && pStats.explosionCooldownFrames <= 0) {
            const cooldowns = [3600, 2700, 1800];
            pStats.explosionCooldownFrames = cooldowns[exploLevel - 1] || 3600;
            
            if (exploLevel >= 3) {
                const heal = Math.floor(pStats.maxHp * 0.1);
                pHealth.current = Math.min(pStats.maxHp, Math.max(0, pHealth.current) + heal);
                DamageTextSystem.addDamageText(pTransform.x, pTransform.y - 30, heal, '#00ff00', false, "+HP");
            }
            
            window.dispatchEvent(new CustomEvent('announce', { detail: { text: `绝境爆炸触发！` } }));
            if (this.addEntityCallback) {
                const explosion = new Entity();
                explosion.addComponent(new Transform(pTransform.x, pTransform.y));
                explosion.addComponent(new Renderable('rgba(255, 50, 50, 0.6)', 150, 0, 0, 'circle'));
                // Use a short-lived projectile that deals massive damage to surrounding enemies
                const proj = new Projectile('standard', 200 * pStats.totalDamageMultiplier, player.id, 10, 999);
                explosion.addComponent(proj);
                explosion.tags.add('projectile');
                this.addEntityCallback(explosion);
                
                // Particle effects
                const particles = ParticleFactory.createExplosion(pTransform.x, pTransform.y, '#ff3333', 40);
                for (const p of particles) this.addEntityCallback(p);
            }
        }

        this.handlePlayerHit(player, pTransform, sourceTransform);

        // Knockback
        const dx = pTransform.x - sourceTransform.x;
        const dy = pTransform.y - sourceTransform.y;
        const dist = Math.sqrt(dx*dx + dy*dy);
        if (dist > 0) {
            const nx = dx / dist;
            const ny = dy / dist;
            const kb = 22;
            pTransform.x += nx * kb;
            pTransform.y += ny * kb;
        }

        // Screen shake
        window.dispatchEvent(new CustomEvent('shake', { detail: { mag: isBoss ? 18 : 12, frames: isBoss ? 12 : 10 } }));

        if (pHealth.current <= 0) {
            console.log('GAME OVER! Player died.');
            player.active = false;
            const score = player.getComponent(Score)?.value || 0;
            window.dispatchEvent(new CustomEvent('game-over', { detail: { score } }));
        }
    }

    public update(dt: number): void {
        this.frame += 1;
        const projectiles: Entity[] = [];
        const enemies: Entity[] = [];
        const watermarks: Entity[] = [];
        const inkClouds: Entity[] = [];
        const xpOrbs: Entity[] = [];
        const puddles: Entity[] = [];
        const paperclips: Entity[] = [];
        let player: Entity | null = null;

        // 1. Filter entities into categories
        let canvasEye: Entity | null = null;
        for (const entity of this.entities) {
            if (entity.getComponent(Projectile)) {
                projectiles.push(entity);
            } else if (entity.getComponent(EnemyBehavior)) {
                enemies.push(entity);
            } else if (entity.getComponent(WaterMark)) {
                watermarks.push(entity);
            } else if (entity.getComponent(InkCloud)) {
                inkClouds.push(entity);
            } else if (entity.tags.has('xp_orb')) {
                xpOrbs.push(entity);
            } else if (entity.tags.has('player')) {
                player = entity;
                const pHealth = player.getComponent(Health);
                if (pHealth && pHealth.invincibleFrames > 0) {
                    pHealth.invincibleFrames -= 1;
                }
            } else if (entity.tags.has('canvas_eye')) {
                canvasEye = entity;
            } else if (entity.hasComponent(Puddle)) {
                puddles.push(entity);
            } else if (entity.hasComponent(Paperclip)) {
                paperclips.push(entity);
            }
        }

        // 2. Projectile vs Enemy
        for (const projectile of projectiles) {
            const pTransform = projectile.getComponent(Transform)!;
            const pRender = projectile.getComponent(Renderable)!;
            const pData = projectile.getComponent(Projectile)!;
            const pVel = projectile.getComponent(Velocity);

            if (!pTransform || !pRender) continue;

            // Team check: only player's子弹参与“子弹 vs 敌人”判定，避免敌人被友军或自身子弹误伤
            if (player && pData.ownerId !== player.id) {
                continue;
            }

            for (const enemy of enemies) {
                if (!enemy.active) continue;

                // 替身免疫玩家子弹伤害
                if (enemy.tags.has('ink_dummy')) continue;
                
                const eBeh = enemy.getComponent(EnemyBehavior);
                // 磁性黑洞免疫玩家子弹伤害 (但依然会被吸附逻辑影响，在EnemySystem处理)
                // if (eBeh && eBeh.type === 'blackhole') continue;

                const eTransform = enemy.getComponent(Transform)!;
                const eRender = enemy.getComponent(Renderable)!;
                const eHealth = enemy.getComponent(Health)!;

                if (!eTransform || !eRender || !eHealth) continue;

                // ===== 性能优化：快速AABB包围盒剔除 =====
                // 如果是范围较大的重力枪、激光或特殊的爆炸，我们稍微放宽AABB范围
                let aabbRange = 50; 
                if (pData.type === 'gravity') aabbRange = 300;
                else if (pRender.shape === 'line') aabbRange = 1500; // Sniper beam is very long
                else if (pData.type === 'rocket' || pData.type === 'mine') aabbRange = 200; // AoE weapons
                
                if (Math.abs(pTransform.x - eTransform.x) > aabbRange || Math.abs(pTransform.y - eTransform.y) > aabbRange) {
                    continue; // 距离太远直接跳过所有复杂计算
                }
                // =====================================

                // Check collision based on projectile shape
                let hit = false;

                // Gravity Gun: Check if enemy is in range of black hole
                if (pData.type === 'gravity') {
                    // Check if it's a deployed black hole (stationary)
                    // We can check if it has 'blackhole' tag or if life is set to 180 (initial life of deployed BH)
                    // Or just check velocity?
                    // In CollisionSystem we iterate projectiles.
                    // The deployed BH is a projectile.
                    
                    // Actually, let's check distance for pull effect regardless of hit
                    const dx = pTransform.x - eTransform.x;
                    const dy = pTransform.y - eTransform.y;
                    const dist = Math.sqrt(dx*dx + dy*dy);
                    const gravityRadius = 250; // Black hole range 增加到了250 (之前是150)
                    
                    if (dist < gravityRadius) {
                        // Suck enemy in!
                        // Simplest Fix: Modify Transform directly for "Suck" effect, 
                        // as it overrides movement logic.
                        const pullFactor = 3.0; // 稍微增加一点吸力强度以匹配更大的范围
                        eTransform.x += (dx / dist) * pullFactor;
                        eTransform.y += (dy / dist) * pullFactor;
                        
                        // Gravity also deals continuous damage near center
                        if (dist < 40) { // 中心伤害范围也相应略微扩大
                            if (this.frame % 10 === 0) { // Deal damage every 10 frames to avoid clutter
                                eHealth.current -= 5; 
                                DamageTextSystem.addDamageText(eTransform.x, eTransform.y - 15, 5, '#ffffff', false);
                            }
                            // Don't set hit = true here, or it will destroy the black hole (if not handled)
                            // We want continuous damage.
                            
                            // Check death here for gravity kill
                            if (eHealth.current <= 0) {
                                hit = true; // Trigger death logic
                            }
                        }
                    }
                } 
                else if (pRender.shape === 'line') {
                    // raycast logic for sniper beam
                    // In RenderSystem, beam end point is stored in pRender.width and pRender.height
                    hit = this.lineCircleCollision(
                        pTransform.x, pTransform.y, 
                        pRender.width, pRender.height, 
                        eTransform.x, eTransform.y, 
                        eRender.radius || 15 
                    );
                }  
                // Normal Collision Logic
                else {
                    const dx = pTransform.x - eTransform.x;
                    const dy = pTransform.y - eTransform.y;
                    const dist = Math.sqrt(dx*dx + dy*dy);
                    const minDist = (pRender.radius || 5) + (eRender.radius || 15);
                    
                    if (dist < minDist) {
                        hit = true;
                    }
                }

                if (hit) {
                    if (eBeh && eBeh.type === 'shield' && eBeh.shield > 0 && pData.type !== 'gravity') {
                        let vx = 0, vy = 0;
                        if (pRender.shape === 'line') {
                            vx = pRender.width - pTransform.x;
                            vy = pRender.height - pTransform.y;
                            const d = Math.hypot(vx, vy) || 1;
                            vx /= d; vy /= d;
                        } else if (pVel) {
                            const d = Math.hypot(pVel.x, pVel.y) || 1;
                            vx = pVel.x / d; vy = pVel.y / d;
                        }
                        const fx = Math.cos(eTransform.rotation);
                        const fy = Math.sin(eTransform.rotation);
                        const dot = vx * fx + vy * fy;
                        if (dot > Math.cos(Math.PI / 3)) {
                            eBeh.shield -= pData.damage;
                            const textColor = pData.isSuperCrit ? '#ff0000' : (pData.isCrit ? '#ff4444' : '#66ccff');
                            DamageTextSystem.addDamageText(eTransform.x, eTransform.y - 15, pData.damage, textColor, pData.isCrit || pData.isSuperCrit);
                            if (this.trailCtx) {
                                this.trailCtx.save();
                                this.trailCtx.globalAlpha = 0.6;
                                this.trailCtx.strokeStyle = '#66ccff';
                                this.trailCtx.beginPath();
                                this.trailCtx.arc(eTransform.x, eTransform.y, (eRender.radius || 20) + 6, eTransform.rotation - Math.PI/3, eTransform.rotation + Math.PI/3);
                                this.trailCtx.stroke();
                                this.trailCtx.restore();
                            }
                            if (pRender.shape !== 'line') {
                                if (pData.pierceCount && pData.pierceCount > 0) {
                                    pData.pierceCount -= 1;
                                } else {
                                    projectile.active = false;
                                }
                            }
                            continue;
                        }
                    }
                    // Special logic for Rocket and Mine (AOE)
                    if (pData.type === 'rocket' || pData.type === 'mine') {
                        // Explosion radius
                        const explosionRadius = Math.floor(100 * (pData.explosionRadiusScale || 1));
                        const explosionDamage = (pData.type === 'rocket' ? 50 : 40) + (pData.damage || 0);
                        
                        // Find all enemies in range
                        for (const otherEnemy of enemies) {
                            if (!otherEnemy.active) continue;
                            const t = otherEnemy.getComponent(Transform)!;
                            const h = otherEnemy.getComponent(Health)!;
                            
                            const ex = t.x - eTransform.x;
                            const ey = t.y - eTransform.y;
                            const edist = Math.sqrt(ex*ex + ey*ey);
                            
                            if (edist <= explosionRadius) {
                                h.current -= explosionDamage;
                                const textColor = pData.isSuperCrit ? '#ff0000' : (pData.isCrit ? '#ff4444' : '#ffffff');
                                DamageTextSystem.addDamageText(t.x, t.y - 15, explosionDamage, textColor, pData.isCrit || pData.isSuperCrit);
                                // Visuals handled below if dead
                                if (h.current <= 0) {
                                    if (otherEnemy.active) { // Check again to avoid double kill logic
                                        this.handleEnemyDeath(otherEnemy, player, t.x, t.y, otherEnemy.getComponent(Renderable)!.color);
                                        if (this.trailCtx) {
                                            this.drawSplash(this.trailCtx, t.x, t.y, otherEnemy.getComponent(Renderable)!.color, otherEnemy.getComponent(Renderable)!.radius * 2);
                                        }
                                    }
                                }
                            }
                        }
                        
                        // Create big explosion effect
                        if (this.addEntityCallback) {
                            const particles = ParticleFactory.createExplosion(eTransform.x, eTransform.y, pRender.color, 20);
                            for (const p of particles) this.addEntityCallback(p);
                            
                            // Mine leaves a puddle
                            if (pData.type === 'mine') {
                                const puddle = new Entity();
                                puddle.addComponent(new Transform(eTransform.x, eTransform.y));
                                puddle.addComponent(new WaterMark(0.5, explosionRadius, 300, 'rgba(34, 255, 34, 0.4)')); // Green swamp
                                this.addEntityCallback(puddle);
                            }
                        }
                        
                        // Rocket Splash on Trail
                        if (this.trailCtx) {
                             // Add extra splash for rocket
                             // User: "Rocket didn't leave explosion splash on enemy".
                             // This block runs when Rocket hits (AOE).
                             // We are looping through enemies.
                             // But this block is OUTSIDE the enemy loop. It uses `eTransform` which is the PRIMARY target.
                             // We want to splash on ALL enemies hit? Or just the center?
                             // "Rocket didn't make enemy leave splash".
                             // The splash should be at the explosion center.
                             // And maybe splashes for all victims?
                              
                             // Let's draw a BIG splash at the center of explosion.
                             this.drawSplash(this.trailCtx, eTransform.x, eTransform.y, pRender.color, 60);
                        }

                        projectile.active = false; // Rocket/Mine destroyed on impact
                        break; // Stop checking other enemies for this rocket/mine
                    }

                    // 记录已经命中过的敌人，防止穿透时重复计算
                    if (!pData.hitEnemies) {
                        pData.hitEnemies = new Set<string>();
                    }
                    if (pData.hitEnemies.has(enemy.id)) {
                        continue;
                    }
                    pData.hitEnemies.add(enemy.id);

                    // 书法家被动：每穿透一个敌人，子弹伤害增加50%
                    if (pData.calligrapherBonus) {
                        pData.damage *= 1.5;
                    }

                    let finalDamage = pData.damage;

                    // 元素附魔系处理
                    if (player && eBeh) {
                        const stats = player.getComponent(PlayerStats);
                        if (stats) {
                            // 腐蚀：计算额外伤害
                            if (eBeh.corrosiveStacks > 0) {
                                finalDamage *= (1 + eBeh.corrosiveStacks * eBeh.corrosiveFactor);
                            }
                            
                            // 冰霜：概率冻结
                            const iceLevel = stats.getSkillLevel('element_ice');
                            if (iceLevel > 0) {
                                const freezeProb = iceLevel === 1 ? 0.2 : (iceLevel === 2 ? 0.3 : 0.4);
                                const freezeFrames = iceLevel === 3 ? 90 : 60; // 1.5s or 1s
                                if (Math.random() < freezeProb) {
                                    eBeh.frozenFrames = freezeFrames;
                                }
                            }
                            
                            // 腐蚀：叠加新层数
                            const corrosiveLevel = stats.getSkillLevel('element_corrosive');
                            if (corrosiveLevel > 0) {
                                const maxStacks = 3;
                                const factor = corrosiveLevel === 1 ? 0.1 : (corrosiveLevel === 2 ? 0.15 : 0.2);
                                if (eBeh.corrosiveStacks < maxStacks) {
                                    eBeh.corrosiveStacks++;
                                }
                                eBeh.corrosiveFactor = factor;
                            }
                            
                            // 燃烧：附加状态
                            const fireLevel = stats.getSkillLevel('element_fire');
                            if (fireLevel > 0) {
                                eBeh.burnFrames = 180; // 3 seconds
                                const dmgScale = fireLevel === 1 ? 0.2 : (fireLevel === 2 ? 0.35 : 0.5);
                                let tickDamage = (finalDamage * dmgScale) / 2; // 每半秒(30帧)的伤害
                                if (tickDamage < 1) tickDamage = 1; // 最小伤害为1
                                eBeh.burnDamagePerFrame = tickDamage / 30; 
                                eBeh.burnSpread = (fireLevel === 3);
                            }
                            
                            // 导电：弹射
                            const electricLevel = stats.getSkillLevel('element_electric');
                            if (electricLevel > 0) {
                                const jumpCount = electricLevel;
                                const jumpDmgScale = electricLevel === 3 ? 0.75 : 0.5;
                                const jumpRadius = 150;
                                const candidates = [];
                                for (const other of enemies) {
                                    if (!other.active || other === enemy) continue;
                                    const t = other.getComponent(Transform);
                                    if (!t) continue;
                                    const d = Math.hypot(t.x - eTransform.x, t.y - eTransform.y);
                                    if (d <= jumpRadius) candidates.push({enemy: other, dist: d});
                                }
                                candidates.sort((a,b) => a.dist - b.dist);
                                for (let i = 0; i < Math.min(jumpCount, candidates.length); i++) {
                                    const target = candidates[i].enemy;
                                    const th = target.getComponent(Health);
                                    const tt = target.getComponent(Transform);
                                    if (th && tt) {
                                        const elecDamage = finalDamage * jumpDmgScale;
                                        th.current -= elecDamage;
                                        DamageTextSystem.addDamageText(tt.x, tt.y - 15, elecDamage, '#ffff00', false);
                                        // 绘制闪电连线
                                        if (this.trailCtx) {
                                            this.trailCtx.save();
                                            this.trailCtx.strokeStyle = '#ffff00';
                                            this.trailCtx.lineWidth = 2;
                                            this.trailCtx.beginPath();
                                            this.trailCtx.moveTo(eTransform.x, eTransform.y);
                                            this.trailCtx.lineTo(tt.x, tt.y);
                                            this.trailCtx.stroke();
                                            this.trailCtx.restore();
                                        }
                                        if (th.current <= 0) {
                                            this.handleEnemyDeath(target, player, tt.x, tt.y, target.getComponent(Renderable)?.color || '#ffffff');
                                        }
                                    }
                                }
                            }

                            // 双生·冰火两重天 (synergy_ice_fire)
                            if (stats.getSkillLevel('synergy_ice_fire') > 0) {
                                if (eBeh.frozenFrames > 0 && eBeh.burnFrames > 0) {
                                    const explodeRadius = 150;
                                    // 造成最大生命值 15% 真实伤害
                                    const maxHpDamage = Math.max(1, Math.floor(eHealth.max * 0.15));
                                    
                                    for (const other of enemies) {
                                        if (!other.active) continue;
                                        const tt = other.getComponent(Transform);
                                        const th = other.getComponent(Health);
                                        if (tt && th) {
                                            if (Math.hypot(tt.x - eTransform.x, tt.y - eTransform.y) <= explodeRadius) {
                                                th.current -= maxHpDamage;
                                                DamageTextSystem.addDamageText(tt.x, tt.y - 20, maxHpDamage, '#ff00ff', true); // 紫色真伤
                                                if (th.current <= 0) {
                                                    this.handleEnemyDeath(other, player, tt.x, tt.y, other.getComponent(Renderable)?.color || '#ffffff');
                                                }
                                            }
                                        }
                                    }
                                    
                                    // 解除冰冻
                                    eBeh.frozenFrames = 0;
                                    
                                    // 冰火爆破特效
                                    if (this.addEntityCallback) {
                                        const p1 = ParticleFactory.createExplosion(eTransform.x, eTransform.y, '#ff4444', 20);
                                        const p2 = ParticleFactory.createExplosion(eTransform.x, eTransform.y, '#00ffff', 20);
                                        for (const p of p1) this.addEntityCallback(p);
                                        for (const p of p2) this.addEntityCallback(p);
                                    }
                                    
                                    // 在地上留下粒子的痕迹 (Draw splash on trail canvas)
                                    if (this.trailCtx) {
                                        this.drawSplash(this.trailCtx, eTransform.x, eTransform.y, '#ff4444', explodeRadius * 0.8);
                                        this.drawSplash(this.trailCtx, eTransform.x, eTransform.y, '#00ffff', explodeRadius * 0.8);
                                    }
                                }
                            }
                        }
                    }

                    // Apply damage (for non-AOE or direct hit)
                    eHealth.current -= finalDamage;
                    const textColor = pData.isSuperCrit ? '#ff0000' : (pData.isCrit ? '#ff4444' : '#ffffff');
                    DamageTextSystem.addDamageText(eTransform.x, eTransform.y - 15, finalDamage, textColor, pData.isCrit || pData.isSuperCrit);
                    
                    // ================== 命中/暴击触发系 ==================
                    if (player) {
                        const stats = player.getComponent(PlayerStats);
                        if (stats) {
                            // 1. 命中触发：素描分身 (hit_sketch_clone)
                            const cloneLevel = stats.getSkillLevel('hit_sketch_clone');
                            if (cloneLevel > 0 && pData.type !== 'clone_bullet') { // 防止无限分裂
                                const cloneProb = pData.reaperStrike ? 1.0 : (cloneLevel === 1 ? 0.30 : (cloneLevel === 2 ? 0.40 : 0.50));
                                const cloneCount = cloneLevel >= 3 ? 4 : 2;
                                if (Math.random() < cloneProb && this.addEntityCallback) {
                                    const candidates = [];
                                    for (const other of enemies) {
                                        if (!other.active || other === enemy) continue;
                                        const tt = other.getComponent(Transform);
                                        if (tt) candidates.push({ enemy: other, dist: Math.hypot(tt.x - eTransform.x, tt.y - eTransform.y) });
                                    }
                                    candidates.sort((a,b) => a.dist - b.dist);
                                    
                                    for (let i = 0; i < Math.min(cloneCount, candidates.length); i++) {
                                        const target = candidates[i].enemy.getComponent(Transform)!;
                                        const cloneBullet = new Entity();
                                        cloneBullet.addComponent(new Transform(eTransform.x, eTransform.y));
                                        cloneBullet.addComponent(new Renderable(pRender.color, 4, 0, 0, 'circle'));
                                        const cProj = new Projectile('clone_bullet', pData.damage * 0.5, player.id, 0);
                                        cProj.isCrit = pData.isCrit;
                                        cloneBullet.addComponent(cProj);
                                        
                                        const angle = Math.atan2(target.y - eTransform.y, target.x - eTransform.x);
                                        const speed = 10;
                                        cloneBullet.addComponent(new Velocity(Math.cos(angle) * speed, Math.sin(angle) * speed));
                                        this.addEntityCallback(cloneBullet);
                                    }
                                }
                            }

                            if (pData.isCrit || pData.reaperStrike) {
                                // 2. 暴击触发：色彩爆炸 (hit_explosion)
                                const explosionLevel = stats.getSkillLevel('hit_explosion');
                                if (explosionLevel > 0) {
                                    const radius = explosionLevel >= 2 ? 120 : 80;
                                    const damageMultiplier = explosionLevel >= 3 ? 2 : 1;
                                    const explodeDamage = Math.floor(finalDamage * damageMultiplier * 0.5); 
                                    
                                    for (const other of enemies) {
                                        if (!other.active || other === enemy) continue;
                                        const tt = other.getComponent(Transform);
                                        const th = other.getComponent(Health);
                                        const tr = other.getComponent(Renderable);
                                        if (tt && th) {
                                            if (Math.hypot(tt.x - eTransform.x, tt.y - eTransform.y) <= radius) {
                                                th.current -= explodeDamage;
                                                DamageTextSystem.addDamageText(tt.x, tt.y - 15, explodeDamage, '#ffaa00', false);
                                                if (th.current <= 0) {
                                                    if (other.active) {
                                                        this.handleEnemyDeath(other, player, tt.x, tt.y, tr?.color || '#ffffff');
                                                        if (this.trailCtx) {
                                                            this.drawSplash(this.trailCtx, tt.x, tt.y, tr?.color || '#ffffff', (tr?.radius || 15) * 2);
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    if (this.addEntityCallback) {
                                        const particles = ParticleFactory.createExplosion(eTransform.x, eTransform.y, '#ffaa00', 30);
                                        for (const p of particles) this.addEntityCallback(p);
                                    }
                                    // 在爆炸中心留下专属画痕特效
                                    if (this.trailCtx) {
                                        this.drawSplash(this.trailCtx, eTransform.x, eTransform.y, '#ffaa00', radius * 0.8);
                                    }
                                }

                                // 3. 暴击触发：吸血鬼之触 (crit_vampire)
                                const vampireLevel = stats.getSkillLevel('crit_vampire');
                                if (vampireLevel > 0) {
                                    const vampProb = pData.reaperStrike ? 1.0 : (vampireLevel === 1 ? 0.30 : (vampireLevel === 2 ? 0.40 : 0.50));
                                    const healAmount = vampireLevel >= 3 ? 2 : 1;
                                    if (Math.random() < vampProb) {
                                        const php = player.getComponent(Health);
                                        if (php && php.current < php.max) {
                                            php.current = Math.min(php.max, php.current + healAmount);
                                            DamageTextSystem.addDamageText(player.getComponent(Transform)!.x, player.getComponent(Transform)!.y - 20, healAmount, '#00ff00', false);
                                        }
                                    }
                                }

                                // 4. 双生·军团降临 (synergy_legion)：火柴人暴击吸血
                                if (stats.getSkillLevel('synergy_legion') > 0 && projectile.tags.has('summon_bullet_stickman')) {
                                    const php = player.getComponent(Health);
                                    if (php && php.current < php.max) {
                                        php.current = Math.min(php.max, php.current + 1);
                                        DamageTextSystem.addDamageText(player.getComponent(Transform)!.x, player.getComponent(Transform)!.y - 20, 1, '#00ff00', false);
                                    }
                                }
                            }
                        }
                    }

                    if (pData.type === 'chain') {
                        const chainRadius = 220;
                        let remaining = pData.pierceCount || 0;
                        const candidates: { enemy: Entity, dist: number }[] = [];
                        for (const otherEnemy of enemies) {
                            if (!otherEnemy.active || otherEnemy === enemy) continue;
                            const t = otherEnemy.getComponent(Transform)!;
                            const dxx = t.x - eTransform.x;
                            const dyy = t.y - eTransform.y;
                            const dd = Math.sqrt(dxx*dxx + dyy*dyy);
                            if (dd <= chainRadius) {
                                candidates.push({ enemy: otherEnemy, dist: dd });
                            }
                        }
                        candidates.sort((a, b) => a.dist - b.dist);
                        for (let i = 0; i < Math.min(remaining, candidates.length); i++) {
                            const target = candidates[i].enemy;
                            const th = target.getComponent(Health)!;
                            const tt = target.getComponent(Transform)!;
                            const tr = target.getComponent(Renderable)!;
                            const chainDamage = Math.floor(pData.damage * 0.8);
                            th.current -= chainDamage;
                            const textColor = pData.isSuperCrit ? '#ff0000' : (pData.isCrit ? '#ff4444' : '#ffffff');
                            DamageTextSystem.addDamageText(tt.x, tt.y - 15, chainDamage, textColor, pData.isCrit || pData.isSuperCrit);
                            if (this.trailCtx) {
                                this.trailCtx.save();
                                this.trailCtx.strokeStyle = pRender.color;
                                this.trailCtx.globalAlpha = 0.7;
                                this.trailCtx.lineWidth = 2;
                                this.trailCtx.beginPath();
                                this.trailCtx.moveTo(eTransform.x, eTransform.y);
                                this.trailCtx.lineTo(tt.x, tt.y);
                                this.trailCtx.stroke();
                                this.trailCtx.restore();
                            }
                            if (th.current <= 0) {
                                this.handleEnemyDeath(target, player, tt.x, tt.y, tr.color);
                            }
                        }
                        projectile.active = false;
                    }
                    
                    // Shrink enemy if it's a chaser
                    if (enemy.getComponent(EnemyBehavior)?.type === 'chaser') {
                         if (eRender.shape === 'circle') {
                             eRender.radius = Math.max(5, eRender.radius - (pData.damage / 5));
                         }
                    }
                    
                    // ================== 暴击穿透判定 (crit_pierce) ==================
                    let isCritPiercing = false;
                    const infinitePierceTypes = ['sniper', 'ruler', 'flamethrower', 'gravity', 'compass', 'melee'];
                    if (player && pData.isCrit && !infinitePierceTypes.includes(pData.type)) {
                        const stats = player.getComponent(PlayerStats);
                        if (stats) {
                            const pierceLevel = stats.getSkillLevel('crit_pierce');
                            if (pierceLevel > 0) {
                                const prob = pData.reaperStrike ? 1.0 : (pierceLevel === 1 ? 0.3 : (pierceLevel === 2 ? 0.6 : 1.0));
                                if (Math.random() < prob) {
                                    isCritPiercing = true;
                                }
                            }
                        }
                    }

                    // Remove projectile unless piercing or special
                    if (!infinitePierceTypes.includes(pData.type)) {
                        if (isCritPiercing) {
                            // 触发暴击穿透，不消耗 pierceCount，也不销毁子弹
                        } else if (pData.pierceCount && pData.pierceCount > 0) {
                            pData.pierceCount -= 1;
                        } else {
                            projectile.active = false;
                        }
                    }

                    // Check enemy death
                    if (eHealth.current <= 0) {
                        this.handleEnemyDeath(enemy, player, eTransform.x, eTransform.y, eRender.color);

                        // Splash effect on death
                        if (this.trailCtx) {
                            // Only Gravity(Blackhole?) causes splash on death here
                            if (pData.type === 'gravity') {
                                // Draw Enemy Splash
                                this.drawSplash(this.trailCtx, eTransform.x, eTransform.y, eRender.color, eRender.radius * 2);
                            }
                        }
                    }
                    
                    // If projectile is not piercing, break loop (only hit one enemy)
                    if (!infinitePierceTypes.includes(pData.type)) {
                        if (isCritPiercing) {
                            // 触发暴击穿透，继续判定其他敌人
                        } else if (!(pData.pierceCount && pData.pierceCount > 0)) {
                            break;
                        }
                    }
                }
            }
        }

        // 2.5 Watermark vs Enemy
        for (const watermark of watermarks) {
            if (!watermark.active) continue;
            const wData = watermark.getComponent(WaterMark)!;
            const wTransform = watermark.getComponent(Transform)!;

            wData.durationFrames -= 1;
            if (wData.durationFrames <= 0) {
                watermark.active = false;
                continue;
            }

            for (const enemy of enemies) {
                if (!enemy.active) continue;
                const eTransform = enemy.getComponent(Transform)!;
                const eRender = enemy.getComponent(Renderable)!;
                const eHealth = enemy.getComponent(Health)!;
                const eBeh = enemy.getComponent(EnemyBehavior)!;

                const dx = wTransform.x - eTransform.x;
                const dy = wTransform.y - eTransform.y;
                const dist = Math.sqrt(dx * dx + dy * dy);
                const minDist = wData.radius + (eRender.radius || 15);

                if (dist < minDist) {
                    if (eBeh.type === 'eraser') {
                        // 橡皮擦可以擦掉接触部分的痕迹
                        // 避免每帧都添加过多的重叠圆，检查距离上一个记录点的距离
                        const eraseRadius = (eRender.radius || 15) + 5; // 稍微扩大一点擦除范围
                        let shouldAdd = true;
                        if (wData.erasedParts.length > 0) {
                            const last = wData.erasedParts[wData.erasedParts.length - 1];
                            const lx = last.x - eTransform.x;
                            const ly = last.y - eTransform.y;
                            if (lx * lx + ly * ly < eraseRadius * eraseRadius * 0.25) {
                                shouldAdd = false; // 距离太近，不重复添加
                            }
                        }
                        if (shouldAdd) {
                            wData.erasedParts.push({ x: eTransform.x, y: eTransform.y, radius: eraseRadius });
                        }
                        
                        // 如果被擦除的面积太大，可以直接销毁
                        if (wData.erasedParts.length > 30) {
                            watermark.active = false;
                            break;
                        }
                    } else {
                        // 普通敌人造成持续伤害 (每帧)
                        // 检查敌人是否在擦除区域内
                        let inErasedArea = false;
                        for (const part of wData.erasedParts) {
                            const px = part.x - eTransform.x;
                            const py = part.y - eTransform.y;
                            // 如果敌人的中心点在擦除区域内，就不受伤害
                            if (Math.sqrt(px * px + py * py) < part.radius) {
                                inErasedArea = true;
                                break;
                            }
                        }
                        
                        if (!inErasedArea) {
                            eHealth.current -= wData.damagePerFrame;
                            // 为了避免满屏伤害数字，可以降低伤害数字的频率，或者不显示持续伤害的数字
                            // 如果需要显示，可以用帧数取模
                            if (this.frame % 30 === 0) {
                                DamageTextSystem.addDamageText(eTransform.x, eTransform.y - 15, wData.damagePerFrame * 30, '#ffffff', false);
                            }
                            
                            if (eHealth.current <= 0) {
                                this.handleEnemyDeath(enemy, player, eTransform.x, eTransform.y, eRender.color);
                            }
                        }
                    }
                }
            }
        }

        // 2.6 InkCloud vs Enemy
        for (const ink of inkClouds) {
            if (!ink.active) continue;
            const inkData = ink.getComponent(InkCloud)!;
            const inkTransform = ink.getComponent(Transform)!;
            const inkRender = ink.getComponent(Renderable)!;

            inkData.durationFrames -= 1;
            if (inkData.durationFrames <= 0) {
                ink.active = false;
                continue;
            }

            // Fade out effect
            if (inkRender && inkData.durationFrames < 60) {
                const alpha = (inkData.durationFrames / 60) * 0.8;
                inkRender.color = `rgba(0, 0, 0, ${alpha})`;
            }

            for (const enemy of enemies) {
                if (!enemy.active) continue;
                const eTransform = enemy.getComponent(Transform)!;
                const eRender = enemy.getComponent(Renderable)!;
                const eBeh = enemy.getComponent(EnemyBehavior)!;

                const dx = inkTransform.x - eTransform.x;
                const dy = inkTransform.y - eTransform.y;
                const dist = Math.sqrt(dx * dx + dy * dy);
                const minDist = inkData.radius + (eRender.radius || 15);

                if (dist < minDist) {
                    // Enemy is inside ink cloud -> blind them
                    eBeh.blindFrames = 2; // Keep blinding them as long as they are inside, plus 1 extra frame
                }
            }
        }

        // 3. Enemy vs Canvas Eye
        for (const enemy of enemies) {
            if (!enemy.active) continue;
            const eTransform = enemy.getComponent(Transform)!;
            const eRender = enemy.getComponent(Renderable)!;
            if (canvasEye && canvasEye.active) {
                const cTransform = canvasEye.getComponent(Transform);
                const cRender = canvasEye.getComponent(Renderable);
                const cHealth = canvasEye.getComponent(Health);
                if (cTransform && cRender && cHealth) {
                    const dx = eTransform.x - cTransform.x;
                    const dy = eTransform.y - cTransform.y;
                    const dist = Math.sqrt(dx*dx + dy*dy);
                    const minDist = (eRender.radius || 15) + (cRender.radius || 40);
                    if (dist < minDist) {
                        if (this.frame % 30 === 0) { 
                            cHealth.current -= 5;
                            DamageTextSystem.addDamageText(cTransform.x, cTransform.y - 15, 5, '#ff0000', false);
                            const nx = dx / dist;
                            const ny = dy / dist;
                            eTransform.x += nx * 10;
                            eTransform.y += ny * 10;
                            cRender.color = 'rgba(255, 100, 100, 0.8)';
                            setTimeout(() => {
                                if (canvasEye && canvasEye.active && cRender) cRender.color = 'rgba(255, 255, 255, 0.8)';
                            }, 100);
                            if (cHealth.current <= 0) {
                                canvasEye.active = false;
                                window.dispatchEvent(new CustomEvent('announce', { detail: { text: '画眼被摧毁！防守失败。' } }));
                                const score = player ? (player.getComponent(Score)?.value || 0) : 0;
                                setTimeout(() => {
                                    window.dispatchEvent(new CustomEvent('game-over', { detail: { score } }));
                                }, 2000);
                            }
                        }
                    }
                }
            }
        }

        // 4. Enemy vs Player
        if (player && player.active) {
            const pTransform = player.getComponent(Transform)!;
            const pRender = player.getComponent(Renderable)!;
            const pSkill = player.getComponent(Skill);
            const pHealth = player.getComponent(Health);

            for (const enemy of enemies) {
                if (!enemy.active) continue;

                const eTransform = enemy.getComponent(Transform)!;
                const eRender = enemy.getComponent(Renderable)!;

                const dx = pTransform.x - eTransform.x;
                const dy = pTransform.y - eTransform.y;
                const dist = Math.sqrt(dx*dx + dy*dy);
                const minDist = (pRender.radius || 20) + (eRender.radius || 15);

                if (dist < minDist) {
                    if (pSkill && pSkill.eraserShieldFrames > 0) {
                        if (dist > 0) {
                            const nx = (pTransform.x - eTransform.x) / dist;
                            const ny = (pTransform.y - eTransform.y) / dist;
                            const kb = 14;
                            eTransform.x -= nx * kb;
                            eTransform.y -= ny * kb;
                        }
                        continue;
                    }
                    if (pHealth && pHealth.invincibleFrames > 0) {
                        continue;
                    }
                    const nextAllowed = this.enemyContactCooldown.get(enemy.id) || 0;
                    if (this.frame < nextAllowed) {
                        continue;
                    }
                    this.enemyContactCooldown.set(enemy.id, this.frame + 30);
                    
                    const pStats = player.getComponent(PlayerStats);
                    if (pStats && Date.now() < (pStats.invincibleUntil || 0)) {
                        continue;
                    }
                    if (pStats && Math.random() < pStats.totalDodgeChance) {
                        DamageTextSystem.addDamageText(pTransform.x, pTransform.y - 20, 0, '#88ccff', true, "闪避!");
                        continue;
                    }

                    if (pHealth) {
                        this.applyDamageToPlayer(player, 50, pTransform, enemy.getComponent(EnemyBehavior)?.type === 'boss', eTransform);
                    }
                }
            }

            for (const projectile of projectiles) {
                const pData2 = projectile.getComponent(Projectile)!;
                if (!pData2) continue;
                if (pData2.ownerId === player.id) continue;
                const t2 = projectile.getComponent(Transform)!;
                const r2 = projectile.getComponent(Renderable)!;
                if (!t2 || !r2) continue;
                const dx = t2.x - pTransform.x;
                const dy = t2.y - pTransform.y;
                const dist = Math.sqrt(dx*dx + dy*dy);
                const minDist = (r2.radius || 5) + (pRender.radius || 20);
                if (dist < minDist) {
                    if (pSkill && pSkill.eraserShieldFrames > 0) {
                        projectile.active = false;
                        continue;
                    }
                    if (pHealth && pHealth.invincibleFrames > 0) {
                        continue;
                    }
                    
                    const pStats = player.getComponent(PlayerStats);
                    if (pStats && Date.now() < (pStats.invincibleUntil || 0)) {
                        continue;
                    }
                    if (pStats && Math.random() < pStats.totalDodgeChance) {
                        DamageTextSystem.addDamageText(pTransform.x, pTransform.y - 20, 0, '#88ccff', true, "闪避!");
                        projectile.active = false;
                        continue;
                    }

                    if (pHealth) {
                        const ownerIsBoss = Array.from(this.entities).some(e => e.id === pData2.ownerId && e.getComponent(EnemyBehavior)?.type === 'boss');
                        this.applyDamageToPlayer(player, 50, pTransform, ownerIsBoss, t2);
                    }
                    projectile.active = false;
                }
            }
        }
        
        // 3. Enemy vs Enemy separation to avoid complete overlap
        if (enemies.length > 1) {
            for (let i = 0; i < enemies.length; i++) {
                const e1 = enemies[i];
                if (!e1.active) continue;
                
                // 【修改点】：如果 e1 是正在冲锋的巨型滚刷，则不参与与其他小怪的互相碰撞排斥
                const beh1 = e1.getComponent(EnemyBehavior);
                if (beh1 && beh1.type === 'boss_roller') {
                    const stateCycle = beh1.bossTimer % 360;
                    if (stateCycle >= 180 && stateCycle < 210) {
                        continue; // 冲锋阶段无视碰撞阻挡
                    }
                }

                const t1 = e1.getComponent(Transform);
                const r1 = e1.getComponent(Renderable);
                if (!t1 || !r1) continue;
                for (let j = i + 1; j < enemies.length; j++) {
                    const e2 = enemies[j];
                    if (!e2.active) continue;

                    // 【修改点】：同样检查 e2 是否为冲锋中的滚刷
                    const beh2 = e2.getComponent(EnemyBehavior);
                    if (beh2 && beh2.type === 'boss_roller') {
                        const stateCycle2 = beh2.bossTimer % 360;
                        if (stateCycle2 >= 180 && stateCycle2 < 210) {
                            continue;
                        }
                    }
                    if (!e2.active) continue;
                    const t2 = e2.getComponent(Transform);
                    const r2 = e2.getComponent(Renderable);
                    if (!t2 || !r2) continue;
                    const dx = t2.x - t1.x;
                    const dy = t2.y - t1.y;
                    let dist = Math.hypot(dx, dy);
                    const minDist = (r1.radius || 15) + (r2.radius || 15);
                    if (dist === 0) {
                        const angle = Math.random() * Math.PI * 2;
                        const push = minDist * 0.5;
                        t1.x -= Math.cos(angle) * push;
                        t1.y -= Math.sin(angle) * push;
                        t2.x += Math.cos(angle) * push;
                        t2.y += Math.sin(angle) * push;
                        continue;
                    }
                    if (dist < minDist) {
                        const overlap = minDist - dist;
                        const nx = dx / dist;
                        const ny = dy / dist;
                        const push = overlap * 0.5;
                        t1.x -= nx * push;
                        t1.y -= ny * push;
                        t2.x += nx * push;
                        t2.y += ny * push;
                    }
                }
            }
        }

        // 4. Player vs XP Orb
        if (player && player.active) {
            const pTransform = player.getComponent(Transform);
            const pRender = player.getComponent(Renderable);
            const pStats = player.getComponent(PlayerStats);
            if (pTransform && pRender) {
                const baseMagnetRange = pStats ? pStats.pickupRange : 30; // 初始磁吸范围较小
                const magnetRadius = (pRender.radius || 20) + baseMagnetRange;
                for (const orb of xpOrbs) {
                    if (!orb.active) continue;
                    const oTransform = orb.getComponent(Transform);
                    const oData = orb.getComponent(ExperienceOrb);
                    if (!oTransform || !oData) continue;
                    
                    const dx = pTransform.x - oTransform.x;
                    const dy = pTransform.y - oTransform.y;
                    const dist = Math.hypot(dx, dy);
                    
                    // Simple magnet effect
                    if (dist < magnetRadius) {
                        const speed = 10;
                        oTransform.x += (dx / dist) * speed;
                        oTransform.y += (dy / dist) * speed;
                    }
                    
                    // Actual pickup logic (touching the player)
                    if (dist < (pRender.radius || 20) + 10) {
                        orb.active = false;
                        const exp = player.getComponent(Experience);
                        if (exp) {
                            exp.xp += oData.amount;
                        }
                    }
                }
            }
        }

        // Puddle 处理 (持续伤害 + 减速)
        for (const puddle of puddles) {
            if (!puddle.active) continue;
            const pTransform = puddle.getComponent(Transform);
            const pData = puddle.getComponent(Puddle);
            if (!pTransform || !pData) continue;

            pData.durationFrames--;
            if (pData.durationFrames <= 0) {
                puddle.active = false;
                continue;
            }

            // Update alpha to fade out
            const pRender = puddle.getComponent(Renderable);
            if (pRender) {
                // Since Renderable color is a string, we might need to parse it, 
                // but actually we can just leave it or use global alpha if RenderSystem supports it.
                // However, Puddle uses 'rgba' string. We can re-generate the color string.
                // e.g. 'rgba(128, 0, 128, 0.4)'
                const baseAlpha = 0.4;
                const currentAlpha = (pData.durationFrames / pData.maxDuration) * baseAlpha;
                // replace the alpha part in rgba
                const rgbMatch = pData.color.match(/rgba\((\d+),\s*(\d+),\s*(\d+)/);
                if (rgbMatch) {
                    pRender.color = `rgba(${rgbMatch[1]}, ${rgbMatch[2]}, ${rgbMatch[3]}, ${currentAlpha.toFixed(2)})`;
                }
            }

            for (const enemy of enemies) {
                if (!enemy.active || enemy.tags.has('ink_dummy')) continue;
                const eTransform = enemy.getComponent(Transform);
                const eHealth = enemy.getComponent(Health);
                const eBeh = enemy.getComponent(EnemyBehavior);
                const eRender = enemy.getComponent(Renderable);
                if (!eTransform || !eHealth || !eBeh) continue;

                const dx = pTransform.x - eTransform.x;
                const dy = pTransform.y - eTransform.y;
                const dist = Math.hypot(dx, dy);

                if (dist <= pData.radius) {
                    // Apply slow
                    eBeh.slowFrames = 2;
                    eBeh.slowFactor = Math.min(eBeh.slowFactor, pData.slowFactor);

                    // Apply damage
                    if (pData.damagePerFrame > 0) {
                        eHealth.current -= pData.damagePerFrame;
                        if (this.frame % 30 === 0) {
                            DamageTextSystem.addDamageText(eTransform.x, eTransform.y - 15, Math.max(1, Math.floor(pData.damagePerFrame * 30)), '#8800ff', false);
                        }
                        if (eHealth.current <= 0) {
                            this.handleEnemyDeath(enemy, player, eTransform.x, eTransform.y, eRender?.color || '#ffffff');
                        }
                    }
                }
            }
        }

        // 5. 元素状态结算
        for (const enemy of enemies) {
            if (!enemy.active) continue;
            const eBeh = enemy.getComponent(EnemyBehavior);
            const eHealth = enemy.getComponent(Health);
            const eTransform = enemy.getComponent(Transform);
            const eRender = enemy.getComponent(Renderable);
            
            if (eBeh && eHealth && eTransform && eRender) {
                // Check if lifeTimer killed it
                if (eHealth.current <= 0) {
                    this.handleEnemyDeath(enemy, player, eTransform.x, eTransform.y, eRender.color);
                    continue;
                }

                // 燃烧结算
                if (eBeh.burnFrames > 0) {
                    eBeh.burnFrames--;
                    eHealth.current -= eBeh.burnDamagePerFrame;
                    if (this.frame % 30 === 0) {
                        DamageTextSystem.addDamageText(eTransform.x, eTransform.y - 15, Math.floor(eBeh.burnDamagePerFrame * 30), '#ff8800', false);
                    }
                    if (eHealth.current <= 0) {
                        this.handleEnemyDeath(enemy, player, eTransform.x, eTransform.y, eRender.color);
                    }
                    
                    // 燃烧蔓延
                    if (eBeh.burnSpread && eBeh.burnFrames % 30 === 0) {
                        for (const other of enemies) {
                            if (!other.active || other === enemy || other.tags.has('ink_dummy')) continue;
                            const otherT = other.getComponent(Transform);
                            if (otherT) {
                                const d = Math.hypot(otherT.x - eTransform.x, otherT.y - eTransform.y);
                                if (d < 100) {
                                    const otherBeh = other.getComponent(EnemyBehavior);
                                    if (otherBeh && otherBeh.burnFrames <= 0) {
                                        otherBeh.burnFrames = eBeh.burnFrames;
                                        otherBeh.burnDamagePerFrame = eBeh.burnDamagePerFrame;
                                        otherBeh.burnSpread = false; // 只蔓延一次
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // 9. Paperclip connections and damage
        if (player) {
            const pStats = player.getComponent(PlayerStats);
            if (pStats && pStats.getSkillLevel('gadget_paperclip') > 0) {
                const paperclipLevel = pStats.getSkillLevel('gadget_paperclip');
                const damage = paperclipLevel === 3 ? 40 * pStats.totalDamageMultiplier : 20 * pStats.totalDamageMultiplier;
                
                // Find unconnected paperclips to pair up
                const unconnected = paperclips.filter(c => !c.getComponent(Paperclip)!.isConnected);
                for (let i = 0; i < unconnected.length - 1; i += 2) {
                    const p1 = unconnected[i];
                    const p2 = unconnected[i+1];
                    const comp1 = p1.getComponent(Paperclip)!;
                    const comp2 = p2.getComponent(Paperclip)!;
                    comp1.isConnected = true;
                    comp1.connectedToId = p2.id;
                    comp2.isConnected = true;
                    comp2.connectedToId = p1.id;
                }

                // Check connected pairs for collision with enemies
                const handledPairs = new Set<string>();
                for (const clip of paperclips) {
                    if (!clip.active) continue;
                    const comp = clip.getComponent(Paperclip)!;
                    if (!comp.isConnected || !comp.connectedToId) continue;
                    
                    if (handledPairs.has(clip.id) || handledPairs.has(comp.connectedToId)) continue;
                    
                    const otherClip = paperclips.find(c => c.id === comp.connectedToId);
                    if (!otherClip || !otherClip.active) continue;
                    
                    handledPairs.add(clip.id);
                    handledPairs.add(otherClip.id);
                    
                    const t1 = clip.getComponent(Transform);
                    const t2 = otherClip.getComponent(Transform);
                    if (!t1 || !t2) continue;

                    // Draw electric line
                    if (this.trailCtx) {
                        this.trailCtx.save();
                        this.trailCtx.strokeStyle = '#00ffff';
                        this.trailCtx.lineWidth = 3;
                        this.trailCtx.setLineDash([5, 5]);
                        this.trailCtx.beginPath();
                        this.trailCtx.moveTo(t1.x, t1.y);
                        this.trailCtx.lineTo(t2.x, t2.y);
                        this.trailCtx.stroke();
                        this.trailCtx.restore();
                    }

                    // Check collision
                    let hitAny = false;
                    for (const enemy of enemies) {
                        if (!enemy.active || enemy.tags.has('ink_dummy')) continue;
                        const eT = enemy.getComponent(Transform);
                        const eR = enemy.getComponent(Renderable);
                        if (!eT || !eR) continue;

                        if (this.lineCircleCollision(t1.x, t1.y, t2.x, t2.y, eT.x, eT.y, eR.radius + 5)) {
                            // Damage enemy
                            const eH = enemy.getComponent(Health);
                            if (eH) {
                                eH.current -= damage;
                                DamageTextSystem.addDamageText(eT.x, eT.y - 15, damage, '#00ffff', false);
                                if (eH.current <= 0) {
                                    this.handleEnemyDeath(enemy, player, eT.x, eT.y, eR.color);
                                }
                            }
                            hitAny = true;
                        }
                    }

                    if (hitAny) {
                        clip.active = false;
                        otherClip.active = false;
                        if (this.addEntityCallback) {
                            const p1 = ParticleFactory.createExplosion(t1.x, t1.y, '#00ffff', 10);
                            const p2 = ParticleFactory.createExplosion(t2.x, t2.y, '#00ffff', 10);
                            for (const p of p1) this.addEntityCallback(p);
                            for (const p of p2) this.addEntityCallback(p);
                        }
                    }
                }
            }
        }
    }

    // Helper: Line Segment vs Circle collision
    private lineCircleCollision(x1: number, y1: number, x2: number, y2: number, cx: number, cy: number, r: number): boolean {
        // Vector from start to end
        const dx = x2 - x1;
        const dy = y2 - y1;
        
        // Vector from start to circle center
        const fx = cx - x1;
        const fy = cy - y1;
        
        const len2 = dx*dx + dy*dy;
        // Dot product to find projection of center onto line
        const dot = fx*dx + fy*dy;
        
        // Find closest point on line segment
        let t = dot / len2;
        
        // Clamp t to segment [0, 1]
        if (t < 0) t = 0;
        if (t > 1) t = 1;
        
        // Closest point coordinates
        const closestX = x1 + t * dx;
        const closestY = y1 + t * dy;
        
        // Distance from closest point to circle center
        const distX = closestX - cx;
        const distY = closestY - cy;
        const dist2 = distX*distX + distY*distY;
        
        return dist2 <= r*r;
    }
}
